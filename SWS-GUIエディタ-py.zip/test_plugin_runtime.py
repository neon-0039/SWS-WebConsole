import shutil
import struct
import tempfile
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch
import wave
from pathlib import Path
from tkinter import ttk

import sws_engine
from SWS_GUI import SWSEditor
from sws_plugin_runtime import (
    JavaScriptInputSession,
    find_node_runtime,
    render_output_plugin_to_wav,
    render_python_output_plugin_to_wav,
    run_plugins,
    run_javascript_plugins,
)


class JavaScriptPluginTests(unittest.TestCase):
    def test_plugin_data_matches_the_shared_api_shape(self):
        compiler = sws_engine.Compiler()
        compiler.tempo_map.set_tempo(4, 90)
        event = sws_engine.SoundEvent(
            "piano",
            0,
            1,
            [sws_engine.NoteData("C4", lyric="la")],
            3,
            class_name=None,
        )

        data = sws_engine.events_to_plugin_data([event], compiler)

        self.assertEqual(1, data["api_version"])
        self.assertEqual(
            {
                "tempo": 120.0,
                "key": "C",
                "pitch_mode": False,
                "tempo_map": [
                    {"beat": 0.0, "tempo": 120.0},
                    {"beat": 4, "tempo": 90},
                ],
            },
            data["project"],
        )
        self.assertEqual(
            {
                "instrument": "piano",
                "start": 0,
                "duration": 1,
                "notes": [
                    {
                        "pitch": "C4",
                        "slur": False,
                        "key_bypass": False,
                        "lyric": "la",
                        "key": "C",
                    }
                ],
                "line": 3,
                "class": "main",
                "volume": 100,
                "type": "note",
                "lyric": "la",
                "voice": False,
                "source_position": {"line": 3, "className": "main"},
            },
            data["events"][0],
        )

    def test_missing_plugin_reports_the_source_line(self):
        compiler = sws_engine.Compiler()
        with self.assertRaises(sws_engine.SWSError) as raised:
            run_javascript_plugins(
                [("missing", 8)],
                [],
                compiler,
                {},
            )

        self.assertEqual(
            (8, "FileNotFoundError", "plugin 'missing' has not been loaded"),
            raised.exception.args[0],
        )

    def test_missing_node_runtime_reports_an_error(self):
        compiler = sws_engine.Compiler()
        with patch("sws_plugin_runtime.find_node_runtime", return_value=None):
            with self.assertRaises(sws_engine.SWSError) as raised:
                run_javascript_plugins(
                    [("example", 2)],
                    [],
                    compiler,
                    {"example": ""},
                )

        self.assertEqual(2, raised.exception.args[0][0])
        self.assertEqual("RuntimeError", raised.exception.args[0][1])

    @unittest.skipUnless(
        find_node_runtime() or shutil.which("node"),
        "Node.js is required for JavaScript execution tests",
    )
    def test_javascript_plugin_executes_with_the_shared_data_object(self):
        compiler = sws_engine.Compiler()
        event = sws_engine.SoundEvent(
            "piano",
            0,
            1,
            [sws_engine.NoteData("C4")],
            1,
        )
        source = """
if (SWS.api_version !== 1) throw new Error("wrong API version");
if (SWS.events.length !== 1) throw new Error("wrong event count");
if (SWS.events[0].class !== "main") throw new Error("wrong class");
"""

        run_javascript_plugins(
            [("check", 1)],
            [event],
            compiler,
            {"check": source},
        )

    @unittest.skipUnless(
        find_node_runtime() or shutil.which("node"),
        "Node.js is required for JavaScript execution tests",
    )
    def test_javascript_errors_are_reported_with_the_plugin_line(self):
        compiler = sws_engine.Compiler()
        with self.assertRaises(sws_engine.SWSError) as raised:
            run_javascript_plugins(
                [("broken", 12)],
                [],
                compiler,
                {"broken": 'throw new Error("plugin failure");'},
            )

        error = raised.exception.args[0]
        self.assertEqual(12, error[0])
        self.assertEqual("RuntimeError", error[1])
        self.assertIn("plugin failure", error[2])

    @unittest.skipUnless(
        find_node_runtime() or shutil.which("node"),
        "Node.js is required for JavaScript execution tests",
    )
    def test_html_input_plugin_api_mounts_a_button_and_edits_source(self):
        source = """
return {
  name: "Insert note",
  mount(container, editor) {
    const button = document.createElement("button");
    button.textContent = "Insert note";
    button.addEventListener("click", () => {
      editor.insertText('snd("piano",4,C4);\\n');
    });
    container.appendChild(button);
  }
};
"""
        session = JavaScriptInputSession(
            "insert_note",
            source,
            {"text": "", "selection": {"start": 0, "end": 0}},
        )
        try:
            ready = session.responses.get(timeout=10)
            self.assertEqual("ready", ready["type"])
            self.assertEqual("Insert note", ready["displayName"])
            button = ready["tree"]["children"][0]
            self.assertEqual("button", button["tagName"])
            self.assertEqual(["click"], button["events"])

            session.dispatch(
                button["id"],
                "click",
                {"text": "", "selection": {"start": 0, "end": 0}},
            )
            updated = session.responses.get(timeout=10)
            self.assertEqual("update", updated["type"])
            self.assertEqual(
                [
                    {
                        "op": "replaceRange",
                        "start": 0,
                        "end": 0,
                        "text": 'snd("piano",4,C4);\n',
                    }
                ],
                updated["operations"],
            )
        finally:
            session.close()
            session._thread.join(timeout=3)

    @unittest.skipUnless(
        find_node_runtime() or shutil.which("node"),
        "Node.js is required for JavaScript execution tests",
    )
    def test_native_input_plugin_edits_utf16_ranges_and_supports_undo(self):
        try:
            root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root.withdraw()
        app = None
        try:
            app = SWSEditor(root)
            toolbar_children = app.plugins_button.master.pack_slaves()
            self.assertEqual(
                app.plugins_button.master,
                app.file_button.master,
            )
            self.assertEqual(0, toolbar_children.index(app.file_button))
            self.assertEqual(
                toolbar_children.index(app.plugins_button) + 1,
                toolbar_children.index(app.settings_button),
            )
            file_menu_labels = [
                app.file_menu.entrycget(index, "label")
                for index in range(app.file_menu.index(tk.END) + 1)
                if app.file_menu.type(index) != "separator"
            ]
            self.assertIn(app._t("new_project"), file_menu_labels)
            self.assertIn(app._t("save"), file_menu_labels)
            self.assertIn(app._t("save_as"), file_menu_labels)
            self.assertIn(
                app._t("open_ust_with_instrument"),
                file_menu_labels,
            )
            self.assertEqual(
                app._t("edit_undo"),
                app.edit_menu.entrycget(0, "label"),
            )
            self.assertEqual(
                app._t("edit_redo"),
                app.edit_menu.entrycget(1, "label"),
            )
            source = "A😀B"
            app._set_source(source)
            self.assertEqual(tk.DISABLED, app.edit_menu.entrycget(0, "state"))
            self.assertEqual(tk.DISABLED, app.edit_menu.entrycget(1, "state"))
            app.loaded_input_plugins["replace_text"] = """
return {
  mount(container, editor) {
    const button = document.createElement("button");
    button.textContent = "Replace";
    button.addEventListener("click", () => {
      editor.replaceRange(1, 3, "X");
    });
    container.appendChild(button);
  }
};
"""
            app.open_input_plugin("replace_text")
            view = app.input_plugin_views["replace_text"]
            deadline = time.monotonic() + 10
            while view.tree is None and time.monotonic() < deadline:
                root.update()
                time.sleep(0.01)
            self.assertIsNotNone(view.tree)

            button = next(
                widget
                for widget in view.widgets.values()
                if isinstance(widget, ttk.Button)
            )
            button.invoke()
            deadline = time.monotonic() + 10
            while (
                app.editor.get("1.0", "end-1c") == source
                and time.monotonic() < deadline
            ):
                root.update()
                time.sleep(0.01)
            self.assertEqual("AXB", app.editor.get("1.0", "end-1c"))
            self.assertTrue(app.modified)
            self.assertEqual(tk.NORMAL, app.edit_menu.entrycget(0, "state"))

            app.undo_edit()
            self.assertEqual(source, app.editor.get("1.0", "end-1c"))
            self.assertEqual(tk.DISABLED, app.edit_menu.entrycget(0, "state"))
            self.assertEqual(tk.NORMAL, app.edit_menu.entrycget(1, "state"))
            app.redo_edit()
            self.assertEqual("AXB", app.editor.get("1.0", "end-1c"))
            app.undo_edit()
            self.assertEqual(source, app.editor.get("1.0", "end-1c"))
        finally:
            if app is not None:
                for view in list(app.input_plugin_views.values()):
                    view.session.close()
                    view.session._thread.join(timeout=3)
            root.destroy()

    @unittest.skipUnless(
        find_node_runtime() or shutil.which("node"),
        "Node.js is required for JavaScript execution tests",
    )
    def test_output_plugin_renders_float32_channels_to_wav(self):
        source = """
return {
  render(song, sampleRate) {
    if (song.sample_rate !== sampleRate) {
      throw new Error("sample rate mismatch");
    }
    return {
      left: new Float32Array([0.5, -1]),
      right: new Float32Array([-0.5, 1])
    };
  }
};
"""
        with tempfile.TemporaryDirectory() as temp_dir:
            wav_path = Path(temp_dir) / "output.wav"
            render_output_plugin_to_wav(
                "test_output",
                source,
                [],
                sws_engine.Compiler(),
                wav_path,
                sample_rate=22050,
                master_volume=50,
            )

            with wave.open(str(wav_path), "rb") as wav_file:
                self.assertEqual(2, wav_file.getnchannels())
                self.assertEqual(22050, wav_file.getframerate())
                self.assertEqual(2, wav_file.getnframes())
                samples = struct.unpack("<hhhh", wav_file.readframes(2))

        self.assertEqual((8192, -8192, -16384, 16384), samples)

    def test_plugin_command_rejects_names_outside_html_rules(self):
        with self.assertRaises(sws_engine.SWSError) as raised:
            sws_engine.Compiler().compile_source('plugin("bad-name");')

        self.assertEqual("ValueError", raised.exception.args[0][1])

    def test_plugin_command_records_a_valid_name(self):
        compiler = sws_engine.Compiler()

        compiler.compile_source('plugin("valid_1");')

        self.assertEqual([("valid_1", 1)], compiler.plugins_to_run)

    def test_plugin_command_requires_exactly_one_name(self):
        with self.assertRaises(sws_engine.SWSError) as raised:
            sws_engine.Compiler().compile_source(
                'plugin("first", "second");'
            )

        self.assertEqual("SyntaxError", raised.exception.args[0][1])


class PythonPluginTests(unittest.TestCase):
    def test_python_data_plugin_runs_without_node(self):
        compiler = sws_engine.Compiler()
        event = sws_engine.SoundEvent(
            "piano",
            0,
            1,
            [sws_engine.NoteData("C4")],
            1,
        )
        source = """
assert SWS["api_version"] == 1
assert len(SWS["events"]) == 1

def run(data):
    assert data["events"][0]["notes"][0]["pitch"] == "C4"
"""

        with patch("sws_plugin_runtime.find_node_runtime", return_value=None):
            run_plugins(
                [("check", 1)],
                [event],
                compiler,
                {"check": source},
                {"check": "PY"},
            )

    def test_python_data_plugin_errors_are_reported_with_the_plugin_line(self):
        with self.assertRaises(sws_engine.SWSError) as raised:
            run_plugins(
                [("broken", 12)],
                [],
                sws_engine.Compiler(),
                {"broken": 'raise ValueError("plugin failure")'},
                {"broken": "PY"},
            )

        error = raised.exception.args[0]
        self.assertEqual(12, error[0])
        self.assertEqual("RuntimeError", error[1])
        self.assertIn("plugin failure", error[2])

    def test_python_output_plugin_renders_float_channels_without_node(self):
        source = """
def render(song, sample_rate):
    assert song["sample_rate"] == sample_rate
    return {
        "left": [0.5, -1.0],
        "right": [-0.5, 1.0],
    }
"""
        with tempfile.TemporaryDirectory() as temp_dir:
            wav_path = Path(temp_dir) / "python-output.wav"
            with patch(
                "sws_plugin_runtime.find_node_runtime",
                return_value=None,
            ) as find_node:
                render_python_output_plugin_to_wav(
                    "test_output",
                    source,
                    [],
                    sws_engine.Compiler(),
                    wav_path,
                    sample_rate=22050,
                    master_volume=50,
                )
                find_node.assert_not_called()

            with wave.open(str(wav_path), "rb") as wav_file:
                self.assertEqual(2, wav_file.getnchannels())
                self.assertEqual(22050, wav_file.getframerate())
                self.assertEqual(2, wav_file.getnframes())
                samples = struct.unpack("<hhhh", wav_file.readframes(2))

        self.assertEqual((8192, -8192, -16384, 16384), samples)

    def test_python_output_plugin_stops_when_cancelled(self):
        stop_event = threading.Event()
        timer = threading.Timer(0.2, stop_event.set)
        timer.start()
        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                wav_path = Path(temp_dir) / "cancelled.wav"
                with self.assertRaises(InterruptedError):
                    render_python_output_plugin_to_wav(
                        "slow_output",
                        "import time\n"
                        "def render(song, sample_rate):\n"
                        "    time.sleep(10)\n"
                        "    return [0.0]\n",
                        [],
                        sws_engine.Compiler(),
                        wav_path,
                        sample_rate=22050,
                        master_volume=100,
                        cancel_event=stop_event,
                    )
                self.assertFalse(wav_path.exists())
        finally:
            timer.cancel()

    def test_python_data_plugin_stops_when_cancelled(self):
        stop_event = threading.Event()
        timer = threading.Timer(0.2, stop_event.set)
        timer.start()
        try:
            with self.assertRaises(InterruptedError):
                run_plugins(
                    [("slow", 1)],
                    [],
                    sws_engine.Compiler(),
                    {
                        "slow": (
                            "import time\n"
                            "def run(data):\n"
                            "    time.sleep(10)\n"
                        )
                    },
                    {"slow": "PY"},
                    cancel_event=stop_event,
                )
        finally:
            timer.cancel()

    def test_python_output_plugin_rejects_mismatched_channels(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            with self.assertRaises(sws_engine.SWSError) as raised:
                render_python_output_plugin_to_wav(
                    "invalid_output",
                    "def render(song, sample_rate): return ([0.0], [])",
                    [],
                    sws_engine.Compiler(),
                    Path(temp_dir) / "invalid.wav",
                    sample_rate=22050,
                    master_volume=100,
                )

        self.assertEqual("OutputPluginError", raised.exception.args[0][1])
        self.assertIn("equal-length", raised.exception.args[0][2])

    def test_python_input_plugin_mounts_tk_widgets_and_edits_source(self):
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        try:
            root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root.withdraw()
        app = SWSEditor(root)
        self.addCleanup(root.destroy)
        app.draft_path = Path(temp_dir.name) / "draft.json"
        app._set_source("")
        app.loaded_input_plugins["python_insert"] = """
import tkinter as tk

def mount(parent, editor):
    tk.Button(parent, text="Insert").pack()
    editor.insert_text("python plugin")
"""
        app.loaded_input_plugin_syntaxes["python_insert"] = "PY"

        app.open_input_plugin("python_insert")

        view = app.input_plugin_views["python_insert"]
        self.assertEqual("", view.status.cget("text"))
        self.assertEqual("python plugin", app.editor.get("1.0", "end-1c"))

        def has_button(widget: tk.Misc) -> bool:
            return any(
                isinstance(child, tk.Button) or has_button(child)
                for child in widget.winfo_children()
            )

        self.assertTrue(has_button(view.window))


if __name__ == "__main__":
    unittest.main()
