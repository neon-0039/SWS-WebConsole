"""Tkinter-based native editor for Sound Wav Script."""

import copy
from dataclasses import dataclass, field
import json
import os
import re
import tempfile
import threading
import tkinter as tk
from pathlib import Path
from queue import Empty, SimpleQueue
from tkinter import filedialog, messagebox, simpledialog, ttk
from typing import Callable

import sws_engine
from sws_plugin_runtime import (
    JavaScriptInputSession,
    render_output_plugin_to_wav,
    render_python_output_plugin_to_wav,
    run_plugins,
)
from sws_ssp import parse_ssp_package
from track_editor import (
    GLOBAL_TRACK,
    SourceSegment,
    TrackKey,
    compose_source,
    filter_events_for_tracks,
    partition_source,
    remove_track_from_source,
)


APP_DIRECTORY = Path(__file__).resolve().parent
APP_NAME = "Sound Wav Script Studio Editor"
SETTINGS_PATH = (
    Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
    / "SWS-pyexe"
    / "settings.json"
)
DRAFT_PATH = SETTINGS_PATH.with_name("draft.json")
RECENT_FILES_PATH = SETTINGS_PATH.with_name("recent_files.json")
MAX_RECENT_FILES = 10
STARTER_SOURCE = 'snd("piano", 4, C4);\n'
DEFAULT_SETTINGS = {
    "editorFontSize": 14,
    "editorWrap": False,
    "autoIndent": True,
    "showLineNumbers": True,
    "autoSaveDraft": True,
    "warnUnsaved": True,
    "mixedFunctionTracksToGlobal": True,
    "masterVolume": 100,
    "useUtauToolsForPlayback": False,
    "utauWavtoolPath": "",
    "utauResamplerPath": "",
    "utauResamplerFlags": "",
    "language": "ja",
    "theme": "dark",
    "syntaxPreset": "standard",
}


@dataclass(frozen=True)
class PlaybackOptions:
    use_utau_tools: bool
    wavtool_path: str
    resampler_path: str
    master_volume: int
    resampler_flags: str = ""


def _partition_events_for_voicebank(
    events: list[sws_engine.SoundEvent],
    voicebank: sws_engine.UTAUVoicebank | None,
    force_utau: bool = False,
) -> tuple[list[sws_engine.SoundEvent], list[sws_engine.SoundEvent]]:
    if voicebank is None:
        return [], events.copy()
    if force_utau:
        return events.copy(), []

    instrument_name = voicebank.root.name.casefold()
    utau_events = [
        event
        for event in events
        if event.instrument.casefold() == instrument_name
    ]
    builtin_events = [
        event
        for event in events
        if event.instrument.casefold() != instrument_name
    ]
    return utau_events, builtin_events


LANGUAGE_NAMES = {
    "ja": "日本語",
    "en-US": "English (US)",
    "en-GB": "English (UK)",
    "de": "Deutsch",
    "fr": "Français",
    "it": "Italiano",
}
TRANSLATIONS = {
    "en-US": {
        "file": "File", "edit": "Edit", "settings": "Settings", "new": "New",
        "new_project": "New project",
        "open": "Open...", "save": "Save", "save_as": "Save As...", "exit": "Exit",
        "subtitle": "Sound Wav Script Studio Editor",
        "edit_undo": "Undo", "edit_redo": "Redo",
        "select_all": "Select All", "compile": "Compile", "source": "SOURCE",
        "output": "OUTPUT", "clear": "Clear", "ready": "Ready",
        "play": "Play", "stop": "Stop", "rendering": "Rendering audio...",
        "playing": "Playing...", "playback_started": "Playback started.",
        "utau_progress_sample": "Sample file: {detail}",
        "utau_progress_pitch": "Pitch generation: {detail}",
        "utau_progress_cache": "Using cached note: {detail}",
        "utau_progress_success": "Succeeded: {completed}/{total} {detail}",
        "utau_cache_cleanup_title": "UTAU cache cleanup failed",
        "utau_cache_cleanup_failed": (
            "Some temporary UTAU note caches could not be deleted: {errors}"
        ),
        "playback_complete": "Playback finished.", "playback_stopped": "Playback stopped.",
        "playback_failed_status": "Playback failed",
        "playback_failed": "Playback failed: {message}", "stop_requested": "Stopping playback...",
        "no_sound": "There are no sound events to play.",
        "new_document": "New document", "opened": "Opened", "saved": "Saved",
        "unsaved": "Unsaved changes", "compiling": "Compiling...",
        "compile_success": "Compile successful: {count} sound event(s).",
        "compile_failed_status": "Compile failed",
        "compile_failed": "Compile failed: {message}",
        "compile_error": "Error on line {line} ({kind}): {message}",
        "compiling_source": "Compiling editor contents...",
        "open_file": "Open file", "open_source": "Open SWS source",
        "save_source": "Save SWS source",
        "export_as": "Save in format",
        "export_midi": "Save as MIDI (.midi)...",
        "export_wav": "Save as WAV (.wav)...",
        "export_ust": "Save as UST (.ust)...",
        "save_selected_track": "Save selected track...",
        "save_track_source": "SWS source (.ss)",
        "save_track_ust": "UST (.ust)",
        "save_track_mid": "MIDI (.mid)",
        "save_track_midi": "MIDI (.midi)",
        "save_track_wav": "WAV (.wav)",
        "track_saved": 'Saved track "{track}" to {path}.',
        "midi_imported": "Imported MIDI: {path}",
        "midi_files": "MIDI files",
        "no_track_events": "The selected track has no sound events to export.",
        "exporting_wav": "Exporting WAV...",
        "export_success": "Exported {format}: {path}",
        "export_failed": "Export failed: {message}",
        "ust_export_unsupported": (
            "UTAU export requires non-overlapping events; tempo changes must "
            "not occur in the middle of a sounding note."
        ),
        "search": "Search...", "search_title": "Find in source",
        "find_previous": "Previous", "find_next": "Next",
        "search_not_found": "No matches found.",
        "replace_selected_text": "Replace selected text...",
        "replace_title": "Replace selected text",
        "replace_source": "Original text",
        "replace_target": "Replace with",
        "replace_no_selection": "Select text to replace first.",
        "recent_files": "Recent files",
        "recent_files_empty": "No recent files",
        "recent_files_load_failed": "Could not load recent files: {message}",
        "recent_files_invalid": "Recent files list is invalid.",
        "recent_files_save_failed": "Could not save recent files: {message}",
        "open_ust_with_instrument": "Open .ust with instrument...",
        "load_utau_voicebank": "Load UTAU voicebank...",
        "voicebank_loaded": 'Loaded "{name}" ({entries} oto entries, {warnings} warning(s)).',
        "voicebank_metadata": "character.txt metadata",
        "voicebank_warnings": "Voicebank parsing warnings",
        "voicebank_load_failed": "Could not load UTAU voicebank",
        "voicebank_info": "UTAU voicebank information",
        "voicebank_overview": "Overview",
        "voicebank_oto": "oto.ini",
        "voicebank_readme": "Readme",
        "voicebank_no_readme": "No readme.txt or linked readme file was found.",
        "voicebank_readme_unavailable": "The linked readme could not be loaded.",
        "voicebank_no_metadata": "No character.txt metadata was found.",
        "voicebank_no_oto": "No oto.ini entries were parsed.",
        "voicebank_folder": "Voicebank folder",
        "voicebank_oto_count": "oto.ini entries",
        "ust_instrument_title": "Open UST with instrument",
        "ust_instrument_prompt": "Select the instrument to use for this UST:",
        "ust_files": "UST files",
        "ust_imported": "Imported UST using {instrument}: {path}",
        "supported_files": "Supported files",
        "sws_files": "SWS source", "text_files": "Text files",
        "all_files": "All files", "unsaved_title": "Unsaved changes",
        "unsaved_prompt": "Save changes before continuing?",
        "restore_title": "Restore draft",
        "restore_prompt": "An auto-saved draft was found. Restore it?",
        "settings_title": "Settings", "editor": "Editor", "language": "Display language",
        "font_size": "Editor font size", "theme": "Theme", "dark": "Dark", "light": "Light",
        "syntax_preset": "Syntax color preset", "wrap": "Wrap long lines",
        "auto_indent": "Automatically indent after Enter",
        "playback": "Playback",
        "use_utau_tools": "Force UTAU playback for all instruments",
        "wavtool_path": "Wavtool",
        "resampler_path": "Sampler (resampler)",
        "resampler_flags": "Resampler flags (e.g. g+0)",
        "browse": "Browse...",
        "select_utau_tool": "Select UTAU tool",
        "utau_playback_setup_note": "UTAU playback requires a loaded voicebank and valid wavtool/resampler paths.",
        "utau_playback_not_ready": "Load a UTAU voicebank before using UTAU playback.",
        "utau_output_plugin_conflict": "UTAU playback cannot be combined with an output plugin.",
        "utau_filename_fallback": 'UTAU filename fallback for "{alias}" uses zero timing: {path}',
        "line_numbers": "Show line numbers", "auto_save": "Automatically save and restore draft",
        "warn_unsaved": "Warn about unsaved changes",
        "master_volume": "Master volume", "shortcuts": "Ctrl+O Open  |  Ctrl+S Save  |  F5 Compile  |  F6 Play  |  Esc Stop",
        "cancel": "Cancel", "apply": "Apply", "invalid_setting": "Invalid setting",
        "invalid_font": "Font size must be a whole number from 12 to 24.",
        "invalid_master_volume": "Master volume must be a whole number from 0 to 100.",
        "invalid_options": "Choose a supported language, theme, and syntax color preset.",
        "settings_save_failed": "Settings could not be saved",
        "open_failed": "Open failed", "save_failed": "Save failed",
        "settings_saved": "Settings saved.", "draft_saved": "Auto-saved draft.",
        "draft_restored": "Restored auto-saved draft.",
        "draft_read_failed": "Could not read auto-save draft: {message}",
        "draft_invalid": "Invalid auto-save draft; it was discarded.",
        "draft_clear_failed": "Could not clear auto-save draft: {message}",
        "draft_save_failed": "Could not auto-save draft: {message}",
        "preset_standard": "Standard", "preset_soft": "Soft", "preset_primary": "Primary",
        "preset_blue": "Blue", "preset_red": "Red", "preset_purple": "Purple",
        "preset_sunset": "Sunset", "preset_monochrome": "Monochrome",
        "preset_colorVision": "Color-vision friendly",
        "preset_colorVisionWarm": "Color-vision friendly (warm)",
        "preset_colorVisionContrast": "Color-vision friendly (high contrast)",
        "settings_invalid": "Invalid settings in {path}; using defaults.",
        "settings_load_failed": "Could not load settings from {path}: {message}",
        "settings_fallback": "Invalid settings ({items}) in {path}; defaults were used for those values.",
        "editor_font_size_set": "Editor font size set to {size} pt.",
        "mixed_function_tracks_global": "Put functions containing multiple tracks in Global",
        "global_track": "Global",
        "shared_track": "Shared",
        "default_track": "Default",
        "track_menu": "Track",
        "add_track_item": "Add track...",
        "delete_selected_track": "Delete selected track",
        "mute_selected_track": "Mute selected track",
        "solo_selected_track": "Solo selected track",
        "delete_track_prompt": 'Delete "{track}" and its source code? References to functions in this track may need cleanup.',
        "track_deleted": "Deleted track: {track}",
        "plugins_menu": "Plugins",
        "load_js_plugin": "Load plugin...",
        "load_ssp_plugin": "Load .ssp plugin package...",
        "plugin_filetypes": "Plugin files",
        "plugin_invalid_extension": "Plugin files must use the .js or .py extension.",
        "plugin_trust_title": "Load plugin",
        "plugin_trust_prompt": (
            "{name} contains executable code and can access files on this "
            "computer. Only load plugins from sources you trust. Continue?"
        ),
        "plugin_package_trust_title": "Load .ssp plugin package",
        "plugin_package_trust_prompt": (
            "{name}.ssp contains executable code and can access files "
            "on this computer. Only load plugins from sources you trust. Continue?"
        ),
        "plugin_invalid_name": (
            'Plugin filename "{name}" must contain only English letters, '
            "numbers, and underscores."
        ),
        "plugin_overwrite_prompt": "A plugin named {name} is already loaded. Replace it?",
        "plugin_load_failed": "Could not load plugin",
        "plugin_loaded": "Loaded plugin: {name}",
        "plugin_package_load_failed": "Could not load .ssp plugin package",
        "plugin_package_invalid_extension": "Plugin package must use the .ssp extension.",
        "plugin_package_loaded": "Loaded .ssp plugin package: {name}",
        "load_input_plugin": "Load input plugin...",
        "load_output_plugin": "Load output plugin...",
        "reset_output_plugin": "Use built-in output",
        "input_plugin_open": "Open input plugin: {name}",
        "plugin_input_loaded": "Loaded input plugin: {name}",
        "plugin_output_loaded": "Loaded output plugin: {name}",
        "plugin_output_reset": "Using built-in audio output.",
        "plugin_window_loading": "Loading plugin...",
        "plugin_window_failed": "Plugin error: {message}",
        "plugin_invalid_input_name": (
            'Plugin filename "{name}" must contain only English letters, '
            "numbers, underscores, and hyphens."
        ),
        "solo_on": "Enable Solo",
        "solo_off": "Disable Solo",
        "mute_on": "Enable Mute",
        "mute_off": "Disable Mute",
        "track_name_title": "Add track",
        "track_name_prompt": "Track/class name:",
        "invalid_track_name": "Enter a non-empty name without quotes or line breaks.",
        "track_exists": "A track with that name already exists.",
    },
    "en-GB": {
        "file": "File", "edit": "Edit", "settings": "Settings", "new": "New",
        "new_project": "New project",
        "open": "Open...", "save": "Save", "save_as": "Save As...", "exit": "Exit",
        "subtitle": "Sound Wav Script Studio Editor",
        "edit_undo": "Undo", "edit_redo": "Redo",
        "select_all": "Select All", "compile": "Compile", "source": "SOURCE",
        "output": "OUTPUT", "clear": "Clear", "ready": "Ready",
        "play": "Play", "stop": "Stop", "rendering": "Rendering audio...",
        "playing": "Playing...", "playback_started": "Playback started.",
        "utau_progress_sample": "Sample file: {detail}",
        "utau_progress_pitch": "Pitch generation: {detail}",
        "utau_progress_success": "Succeeded: {completed}/{total} {detail}",
        "playback_complete": "Playback finished.", "playback_stopped": "Playback stopped.",
        "playback_failed_status": "Playback failed",
        "playback_failed": "Playback failed: {message}", "stop_requested": "Stopping playback...",
        "no_sound": "There are no sound events to play.",
        "new_document": "New document", "opened": "Opened", "saved": "Saved",
        "unsaved": "Unsaved changes", "compiling": "Compiling...",
        "compile_success": "Compile successful: {count} sound event(s).",
        "compile_failed_status": "Compile failed",
        "compile_failed": "Compile failed: {message}",
        "compile_error": "Error on line {line} ({kind}): {message}",
        "compiling_source": "Compiling editor contents...",
        "open_file": "Open file", "open_source": "Open SWS source",
        "save_source": "Save SWS source",
        "export_as": "Save in format",
        "export_midi": "Save as MIDI (.midi)...",
        "export_wav": "Save as WAV (.wav)...",
        "export_ust": "Save as UST (.ust)...",
        "save_selected_track": "Save selected track...",
        "save_track_source": "SWS source (.ss)",
        "save_track_ust": "UST (.ust)",
        "save_track_mid": "MIDI (.mid)",
        "save_track_midi": "MIDI (.midi)",
        "save_track_wav": "WAV (.wav)",
        "track_saved": 'Saved track "{track}" to {path}.',
        "midi_imported": "Imported MIDI: {path}",
        "midi_files": "MIDI files",
        "no_track_events": "The selected track has no sound events to export.",
        "exporting_wav": "Exporting WAV...",
        "export_success": "Exported {format}: {path}",
        "export_failed": "Export failed: {message}",
        "search": "Search...", "search_title": "Find in source",
        "find_previous": "Previous", "find_next": "Next",
        "search_not_found": "No matches found.",
        "replace_selected_text": "Replace selected text...",
        "replace_title": "Replace selected text",
        "replace_source": "Original text",
        "replace_target": "Replace with",
        "replace_no_selection": "Select text to replace first.",
        "recent_files": "Recent files",
        "recent_files_empty": "No recent files",
        "recent_files_load_failed": "Could not load recent files: {message}",
        "recent_files_invalid": "Recent files list is invalid.",
        "recent_files_save_failed": "Could not save recent files: {message}",
        "open_ust_with_instrument": "Open .ust with instrument...",
        "load_utau_voicebank": "Load UTAU voicebank...",
        "voicebank_loaded": 'Loaded "{name}" ({entries} oto entries, {warnings} warning(s)).',
        "voicebank_metadata": "character.txt metadata",
        "voicebank_warnings": "Voicebank parsing warnings",
        "voicebank_load_failed": "Could not load UTAU voicebank",
        "voicebank_info": "UTAU voicebank information",
        "voicebank_overview": "Overview",
        "voicebank_oto": "oto.ini",
        "voicebank_readme": "Readme",
        "voicebank_no_readme": "No readme.txt or linked readme file was found.",
        "voicebank_readme_unavailable": "The linked readme could not be loaded.",
        "voicebank_no_metadata": "No character.txt metadata was found.",
        "voicebank_no_oto": "No oto.ini entries were parsed.",
        "voicebank_folder": "Voicebank folder",
        "voicebank_oto_count": "oto.ini entries",
        "ust_instrument_title": "Open UST with instrument",
        "ust_instrument_prompt": "Select the instrument to use for this UST:",
        "ust_files": "UST files",
        "ust_imported": "Imported UST using {instrument}: {path}",
        "supported_files": "Supported files",
        "sws_files": "SWS source", "text_files": "Text files",
        "all_files": "All files", "unsaved_title": "Unsaved changes",
        "unsaved_prompt": "Save changes before continuing?",
        "restore_title": "Restore draft",
        "restore_prompt": "An auto-saved draft was found. Restore it?",
        "settings_title": "Settings", "editor": "Editor", "language": "Display language",
        "font_size": "Editor font size", "theme": "Theme", "dark": "Dark", "light": "Light",
        "syntax_preset": "Syntax colour preset", "wrap": "Wrap long lines",
        "auto_indent": "Automatically indent after Enter",
        "playback": "Playback",
        "use_utau_tools": "Force UTAU playback for all instruments",
        "wavtool_path": "Wavtool",
        "resampler_path": "Sampler (resampler)",
        "resampler_flags": "Resampler flags (e.g. g+0)",
        "browse": "Browse...",
        "select_utau_tool": "Select UTAU tool",
        "utau_playback_setup_note": "UTAU playback requires a loaded voicebank and valid wavtool/resampler paths.",
        "utau_playback_not_ready": "Load a UTAU voicebank before using UTAU playback.",
        "utau_output_plugin_conflict": "UTAU playback cannot be combined with an output plugin.",
        "utau_filename_fallback": 'UTAU filename fallback for "{alias}" uses zero timing: {path}',
        "line_numbers": "Show line numbers", "auto_save": "Automatically save and restore draft",
        "warn_unsaved": "Warn about unsaved changes",
        "master_volume": "Master volume", "shortcuts": "Ctrl+O Open  |  Ctrl+S Save  |  F5 Compile  |  F6 Play  |  Esc Stop",
        "cancel": "Cancel", "apply": "Apply", "invalid_setting": "Invalid setting",
        "invalid_font": "Font size must be a whole number from 12 to 24.",
        "invalid_master_volume": "Master volume must be a whole number from 0 to 100.",
        "invalid_options": "Choose a supported language, theme and syntax colour preset.",
        "settings_save_failed": "Settings could not be saved",
        "open_failed": "Open failed", "save_failed": "Save failed",
        "settings_saved": "Settings saved.", "draft_saved": "Auto-saved draft.",
        "draft_restored": "Restored auto-saved draft.",
        "draft_read_failed": "Could not read auto-save draft: {message}",
        "draft_invalid": "Invalid auto-save draft; it was discarded.",
        "draft_clear_failed": "Could not clear auto-save draft: {message}",
        "draft_save_failed": "Could not auto-save draft: {message}",
        "preset_standard": "Standard", "preset_soft": "Soft", "preset_primary": "Primary",
        "preset_blue": "Blue", "preset_red": "Red", "preset_purple": "Purple",
        "preset_sunset": "Sunset", "preset_monochrome": "Monochrome",
        "preset_colorVision": "Colour-vision friendly",
        "preset_colorVisionWarm": "Colour-vision friendly (warm)",
        "preset_colorVisionContrast": "Colour-vision friendly (high contrast)",
        "settings_invalid": "Invalid settings in {path}; using defaults.",
        "settings_load_failed": "Could not load settings from {path}: {message}",
        "settings_fallback": "Invalid settings ({items}) in {path}; defaults were used for those values.",
        "editor_font_size_set": "Editor font size set to {size} pt.",
    },
    "ja": {
        "file": "ファイル", "edit": "編集", "settings": "設定", "new": "新規",
        "new_project": "新規プロジェクト",
        "open": "開く...", "save": "保存", "save_as": "名前を付けて保存...",
        "exit": "終了", "subtitle": "Sound Wav Script Studio Editor",
        "edit_undo": "操作を取り消す", "edit_redo": "やりなおす",
        "select_all": "すべて選択", "compile": "コンパイル",
        "source": "ソース", "output": "出力", "clear": "クリア", "ready": "準備完了",
        "play": "再生", "stop": "停止", "rendering": "音声を生成中...",
        "playing": "再生中...", "playback_started": "再生を開始しました。",
        "utau_progress_sample": "サンプルファイル: {detail}",
        "utau_progress_pitch": "音程生成: {detail}",
        "utau_progress_cache": "キャッシュ済み音符を再利用: {detail}",
        "utau_progress_success": "成功しました: {completed}/{total} {detail}",
        "utau_cache_cleanup_title": "UTAUキャッシュの削除に失敗しました",
        "utau_cache_cleanup_failed": (
            "一部の一時UTAU音符キャッシュを削除できませんでした: {errors}"
        ),
        "playback_complete": "再生が終了しました。", "playback_stopped": "再生を停止しました。",
        "playback_failed_status": "再生エラー",
        "playback_failed": "再生に失敗しました: {message}", "stop_requested": "停止しています...",
        "no_sound": "再生できる音イベントがありません。",
        "new_document": "新規ドキュメント", "opened": "開きました", "saved": "保存しました",
        "unsaved": "未保存の変更", "compiling": "コンパイル中...",
        "compile_success": "コンパイル成功: {count} 個の音イベント",
        "compile_failed_status": "コンパイル失敗",
        "compile_failed": "コンパイル失敗: {message}",
        "compile_error": "{line}行目 ({kind}): {message}",
        "compiling_source": "編集中の内容をコンパイルしています...",
        "open_file": "ファイルを開く",
        "open_source": "SWSソースを開く", "save_source": "SWSソースを保存",
        "export_as": "形式を指定して保存",
        "export_midi": "MIDI形式（.midi）で保存...",
        "export_wav": "WAV形式（.wav）で保存...",
        "export_ust": "UST形式（.ust）で保存...",
        "save_selected_track": "指定したトラックを保存...",
        "save_track_source": "SWSソース（.ss）",
        "save_track_ust": "UST形式（.ust）",
        "save_track_mid": "MIDI形式（.mid）",
        "save_track_midi": "MIDI形式（.midi）",
        "save_track_wav": "WAV形式（.wav）",
        "track_saved": "トラック「{track}」を保存しました: {path}",
        "midi_imported": "MIDIを読み込みました: {path}",
        "midi_files": "MIDIファイル",
        "no_track_events": "指定したトラックに書き出せる音イベントがありません。",
        "exporting_wav": "WAVを書き出しています...",
        "export_success": "{format}を書き出しました: {path}",
        "export_failed": "書き出しに失敗しました: {message}",
        "ust_export_unsupported": (
            "UST書き出しでは音符が重ならず、テンポ変更が発音中の音符の"
            "途中にない必要があります。"
        ),
        "search": "検索...", "search_title": "ソースを検索",
        "find_previous": "前へ", "find_next": "次へ",
        "search_not_found": "見つかりませんでした。",
        "replace_selected_text": "選択した文字列を変更...",
        "replace_title": "選択した文字列を変更",
        "replace_source": "変更前",
        "replace_target": "変更後",
        "replace_no_selection": "先に置き換える文字列を選択してください。",
        "recent_files": "最近開いたファイル",
        "recent_files_empty": "最近開いたファイルはありません",
        "recent_files_load_failed": "最近開いたファイルを読み込めませんでした: {message}",
        "recent_files_invalid": "最近開いたファイルの一覧が不正です。",
        "recent_files_save_failed": "最近開いたファイルを保存できませんでした: {message}",
        "open_ust_with_instrument": "楽器を指定して .ust を開く...",
        "load_utau_voicebank": "UTAU音源を読み込む...",
        "voicebank_loaded": "UTAU音源「{name}」を読み込みました（oto: {entries}件、警告: {warnings}件）",
        "voicebank_metadata": "character.txtの内容",
        "voicebank_warnings": "読み込み時の警告",
        "voicebank_load_failed": "UTAU音源を読み込めませんでした",
        "voicebank_info": "UTAU音源の情報",
        "voicebank_overview": "概要",
        "voicebank_oto": "oto.ini",
        "voicebank_readme": "Readme",
        "voicebank_no_readme": "Readmeファイルが見つかりません。",
        "voicebank_readme_unavailable": "指定されたReadmeを読み込めませんでした。",
        "voicebank_no_metadata": "character.txtの情報がありません。",
        "voicebank_no_oto": "読み込めるoto.iniエントリーがありません。",
        "voicebank_folder": "音源フォルダー",
        "voicebank_oto_count": "oto.iniエントリー数",
        "ust_instrument_title": "UST読み込み時の楽器指定",
        "ust_instrument_prompt": "読み込むUSTで使用する楽器を選択してください:",
        "ust_files": "USTファイル",
        "ust_imported": "USTを読み込みました（楽器: {instrument}）: {path}",
        "supported_files": "対応ファイル",
        "sws_files": "SWSソース", "text_files": "テキストファイル",
        "all_files": "すべてのファイル", "unsaved_title": "未保存の変更",
        "unsaved_prompt": "続行する前に変更を保存しますか？",
        "restore_title": "下書きの復元",
        "restore_prompt": "自動保存された下書きがあります。復元しますか？",
        "settings_title": "設定", "editor": "エディター", "language": "表示言語",
        "font_size": "文字サイズ", "theme": "テーマ", "dark": "ダーク", "light": "ライト",
        "syntax_preset": "構文色プリセット", "wrap": "長い行を折り返す",
        "auto_indent": "自動インデント",
        "playback": "再生",
        "use_utau_tools": "すべての楽器をUTAUツールで再生する（強制）",
        "wavtool_path": "wavtool",
        "resampler_path": "サンプラー（resampler）",
        "resampler_flags": "resamplerフラグ（例: g+0）",
        "browse": "参照...",
        "select_utau_tool": "UTAUツールを選択",
        "utau_playback_setup_note": "UTAU再生には、音源の読み込みとwavtool／resamplerの実行ファイル指定が必要です。",
        "utau_playback_not_ready": "UTAU再生を使う前にUTAU音源を読み込んでください。",
        "utau_output_plugin_conflict": "UTAU再生と出力プラグインは同時に使用できません。",
        "utau_filename_fallback": 'UTAU alias「{alias}」はOTO設定なしのため、タイミング0でWAVを使用: {path}',
        "line_numbers": "行番号を表示", "auto_save": "下書きを自動保存・復元する",
        "warn_unsaved": "未保存の変更を確認する",
        "master_volume": "マスター音量", "shortcuts": "Ctrl+O 開く | Ctrl+S 保存 | F5 コンパイル | F6 再生 | Esc 停止",
        "cancel": "キャンセル", "apply": "適用", "invalid_setting": "設定エラー",
        "invalid_font": "文字サイズは12〜24の整数で指定してください。",
        "invalid_master_volume": "マスター音量は0〜100の整数で指定してください。",
        "invalid_options": "対応している言語、テーマ、構文色を選択してください。",
        "settings_save_failed": "設定を保存できませんでした",
        "open_failed": "開けませんでした", "save_failed": "保存できませんでした",
        "settings_saved": "設定を保存しました。", "draft_saved": "下書きを自動保存しました。",
        "draft_restored": "自動保存された下書きを復元しました。",
        "draft_read_failed": "下書きを読み込めませんでした: {message}",
        "draft_invalid": "下書きが不正なため破棄しました。",
        "draft_clear_failed": "下書きを削除できませんでした: {message}",
        "draft_save_failed": "下書きを自動保存できませんでした: {message}",
        "preset_standard": "標準", "preset_soft": "ソフト", "preset_primary": "プライマリー",
        "preset_blue": "ブルー", "preset_red": "レッド", "preset_purple": "パープル",
        "preset_sunset": "サンセット", "preset_monochrome": "モノクロ",
        "preset_colorVision": "色覚サポート",
        "preset_colorVisionWarm": "色覚サポート（暖色系）",
        "preset_colorVisionContrast": "色覚サポート（高コントラスト）",
        "settings_invalid": "設定ファイル {path} が不正なため初期値を使います。",
        "settings_load_failed": "設定を読み込めませんでした ({path}): {message}",
        "settings_fallback": "設定値 ({items}) が不正なため初期値を使います: {path}",
        "editor_font_size_set": "文字サイズを{size} ptに設定しました。",
        "mixed_function_tracks_global": "複数トラックの音を含む関数をGlobalタブにまとめる",
        "global_track": "Global",
        "shared_track": "共有",
        "default_track": "既定",
        "track_menu": "トラック",
        "add_track_item": "トラックを追加...",
        "delete_selected_track": "選択中のトラックを削除",
        "mute_selected_track": "選択中のトラックをミュート",
        "solo_selected_track": "選択中のトラックをソロ",
        "delete_track_prompt": "「{track}」と所属コードを削除しますか？このトラックの関数を呼び出す箇所は、修正が必要になる場合があります。",
        "track_deleted": "トラックを削除しました: {track}",
        "plugins_menu": "プラグイン",
        "load_js_plugin": "プラグインを読み込む...",
        "load_ssp_plugin": ".ssp統合プラグインパッケージを読み込む...",
        "plugin_filetypes": "プラグインファイル",
        "plugin_invalid_extension": "プラグインの拡張子は.jsまたは.pyである必要があります。",
        "plugin_trust_title": "プラグインの読み込み",
        "plugin_trust_prompt": (
            "{name}は実行可能なコードで、このコンピューター上のファイルに "
            "アクセスできます。信頼できる入手元のプラグインだけを読み込んでください。続行しますか？"
        ),
        "plugin_package_trust_title": ".ssp統合プラグインパッケージの読み込み",
        "plugin_package_trust_prompt": (
            "{name}.sspは実行可能なコードで、このコンピューター上のファイルに "
            "アクセスできます。信頼できる入手元のプラグインだけを読み込んでください。続行しますか？"
        ),
        "plugin_invalid_name": (
            "プラグインのファイル名「{name}」には半角英数字とアンダースコアのみ使用できます。"
        ),
        "plugin_overwrite_prompt": "「{name}」は読み込み済みです。置き換えますか？",
        "plugin_load_failed": "プラグインを読み込めませんでした",
        "plugin_loaded": "プラグインを読み込みました: {name}",
        "plugin_package_load_failed": ".ssp統合プラグインパッケージを読み込めませんでした",
        "plugin_package_invalid_extension": "プラグインパッケージの拡張子は.sspである必要があります。",
        "plugin_package_loaded": ".ssp統合プラグインパッケージを読み込みました: {name}",
        "load_input_plugin": "入力プラグインを読み込む...",
        "load_output_plugin": "出力プラグインを読み込む...",
        "reset_output_plugin": "内蔵出力に戻す",
        "input_plugin_open": "入力プラグインを開く: {name}",
        "plugin_input_loaded": "入力プラグインを読み込みました: {name}",
        "plugin_output_loaded": "出力プラグインを読み込みました: {name}",
        "plugin_output_reset": "内蔵音声出力を使用します。",
        "plugin_window_loading": "プラグインを読み込み中...",
        "plugin_window_failed": "プラグインエラー: {message}",
        "plugin_invalid_input_name": (
            "プラグインのファイル名「{name}」には半角英数字、"
            "アンダースコア、ハイフンのみ使用できます。"
        ),
        "solo_on": "SoloをON",
        "solo_off": "SoloをOFF",
        "mute_on": "MuteをON",
        "mute_off": "MuteをOFF",
        "track_name_title": "トラックを追加",
        "track_name_prompt": "トラック／クラス名:",
        "invalid_track_name": "空欄、引用符、改行は使用できません。",
        "track_exists": "同じ名前のトラックが既にあります。",
    },
    "de": {
        "file": "Datei", "edit": "Bearbeiten", "settings": "Einstellungen", "new": "Neu",
        "new_project": "Neues Projekt",
        "open": "Öffnen...", "save": "Speichern", "save_as": "Speichern unter...",
        "exit": "Beenden", "subtitle": "Sound Wav Script Studio Editor",
        "edit_undo": "Rückgängig", "edit_redo": "Wiederholen",
        "select_all": "Alles auswählen", "compile": "Kompilieren",
        "source": "QUELLCODE", "output": "AUSGABE", "clear": "Leeren", "ready": "Bereit",
        "play": "Abspielen", "stop": "Stoppen", "rendering": "Audio wird gerendert...",
        "playing": "Wiedergabe...", "playback_started": "Wiedergabe gestartet.",
        "utau_progress_sample": "Sample-Datei: {detail}",
        "utau_progress_pitch": "Tonhöhenerzeugung: {detail}",
        "utau_progress_cache": "Zwischengespeicherte Note: {detail}",
        "utau_progress_success": "Erfolgreich: {completed}/{total} {detail}",
        "utau_cache_cleanup_title": "UTAU-Cache konnte nicht gelöscht werden",
        "utau_cache_cleanup_failed": (
            "Einige temporäre UTAU-Noten-Caches konnten nicht gelöscht werden: {errors}"
        ),
        "playback_complete": "Wiedergabe beendet.", "playback_stopped": "Wiedergabe gestoppt.",
        "playback_failed_status": "Wiedergabe fehlgeschlagen",
        "playback_failed": "Wiedergabe fehlgeschlagen: {message}",
        "stop_requested": "Wiedergabe wird gestoppt...",
        "no_sound": "Keine Soundereignisse zum Abspielen vorhanden.",
        "new_document": "Neues Dokument", "opened": "Geöffnet", "saved": "Gespeichert",
        "unsaved": "Ungespeicherte Änderungen", "compiling": "Kompiliere...",
        "compile_success": "Kompilierung erfolgreich: {count} Soundereignis(se).",
        "compile_failed_status": "Kompilierung fehlgeschlagen",
        "compile_failed": "Kompilierung fehlgeschlagen: {message}",
        "compile_error": "Fehler in Zeile {line} ({kind}): {message}",
        "compiling_source": "Editorinhalt wird kompiliert...",
        "open_file": "Datei öffnen",
        "open_source": "SWS-Quelltext öffnen", "save_source": "SWS-Quelltext speichern",
        "export_as": "In Format speichern",
        "export_midi": "Als MIDI (.midi) speichern...",
        "export_wav": "Als WAV (.wav) speichern...",
        "export_ust": "Als UST (.ust) speichern...",
        "save_selected_track": "Ausgewählten Track speichern...",
        "save_track_source": "SWS-Quelltext (.ss)",
        "save_track_ust": "UST (.ust)",
        "save_track_mid": "MIDI (.mid)",
        "save_track_midi": "MIDI (.midi)",
        "save_track_wav": "WAV (.wav)",
        "track_saved": 'Track "{track}" gespeichert unter {path}.',
        "midi_imported": "MIDI importiert: {path}",
        "midi_files": "MIDI-Dateien",
        "no_track_events": "Der ausgewählte Track enthält keine Soundereignisse zum Exportieren.",
        "exporting_wav": "WAV wird exportiert...",
        "export_success": "{format} exportiert: {path}",
        "export_failed": "Export fehlgeschlagen: {message}",
        "ust_export_unsupported": (
            "Der UST-Export erfordert nicht überlappende Ereignisse. "
            "Tempoänderungen dürfen nicht mitten in einem klingenden Ton liegen."
        ),
        "search": "Suchen...", "search_title": "Im Quelltext suchen",
        "find_previous": "Zurück", "find_next": "Weiter",
        "search_not_found": "Keine Übereinstimmung gefunden.",
        "replace_selected_text": "Ausgewählten Text ersetzen...",
        "replace_title": "Ausgewählten Text ersetzen",
        "replace_source": "Originaltext",
        "replace_target": "Ersetzen durch",
        "replace_no_selection": "Wählen Sie zuerst Text zum Ersetzen aus.",
        "recent_files": "Zuletzt geöffnet",
        "recent_files_empty": "Keine zuletzt geöffneten Dateien",
        "recent_files_load_failed": "Zuletzt geöffnete Dateien konnten nicht geladen werden: {message}",
        "recent_files_invalid": "Die Liste zuletzt geöffneter Dateien ist ungültig.",
        "recent_files_save_failed": "Zuletzt geöffnete Dateien konnten nicht gespeichert werden: {message}",
        "open_ust_with_instrument": ".ust mit Instrument öffnen...",
        "load_utau_voicebank": "UTAU-Voicebank laden...",
        "voicebank_loaded": '„{name}“ geladen ({entries} oto-Einträge, {warnings} Warnung(en)).',
        "voicebank_metadata": "character.txt-Metadaten",
        "voicebank_warnings": "Warnungen beim Einlesen",
        "voicebank_load_failed": "UTAU-Voicebank konnte nicht geladen werden",
        "voicebank_info": "UTAU-Voicebank-Informationen",
        "voicebank_overview": "Übersicht",
        "voicebank_oto": "oto.ini",
        "voicebank_readme": "Readme",
        "voicebank_no_readme": "Keine readme.txt oder verknüpfte Readme-Datei gefunden.",
        "voicebank_readme_unavailable": "Die angegebene Readme-Datei konnte nicht geladen werden.",
        "voicebank_no_metadata": "Keine Metadaten in character.txt gefunden.",
        "voicebank_no_oto": "Keine oto.ini-Einträge gelesen.",
        "voicebank_folder": "Voicebank-Ordner",
        "voicebank_oto_count": "oto.ini-Einträge",
        "ust_instrument_title": "UST mit Instrument öffnen",
        "ust_instrument_prompt": "Instrument für diese UST auswählen:",
        "ust_files": "UST-Dateien",
        "ust_imported": "UST mit {instrument} importiert: {path}",
        "supported_files": "Unterstützte Dateien",
        "sws_files": "SWS-Quelltext", "text_files": "Textdateien",
        "all_files": "Alle Dateien", "unsaved_title": "Ungespeicherte Änderungen",
        "unsaved_prompt": "Änderungen vor dem Fortfahren speichern?",
        "restore_title": "Entwurf wiederherstellen",
        "restore_prompt": "Ein automatisch gespeicherter Entwurf wurde gefunden. Wiederherstellen?",
        "settings_title": "Einstellungen", "editor": "Editor", "language": "Anzeigesprache",
        "font_size": "Editor-Schriftgröße", "theme": "Design", "dark": "Dunkel", "light": "Hell",
        "syntax_preset": "Farbschema für Syntax", "wrap": "Lange Zeilen umbrechen",
        "auto_indent": "Nach Enter automatisch einrücken",
        "playback": "Wiedergabe",
        "use_utau_tools": "UTAU-Wiedergabe für alle Instrumente erzwingen",
        "wavtool_path": "Wavtool",
        "resampler_path": "Sampler (Resampler)",
        "resampler_flags": "Resampler-Flags (z. B. g+0)",
        "browse": "Durchsuchen...",
        "select_utau_tool": "UTAU-Tool auswählen",
        "utau_playback_setup_note": "Für die UTAU-Wiedergabe sind eine geladene Voicebank und gültige wavtool/resampler-Pfade erforderlich.",
        "utau_playback_not_ready": "Lade vor der UTAU-Wiedergabe eine Voicebank.",
        "utau_output_plugin_conflict": "UTAU-Wiedergabe und Ausgabe-Plugin können nicht gleichzeitig verwendet werden.",
        "utau_filename_fallback": 'UTAU-Dateinamen-Fallback für "{alias}" verwendet Timing 0: {path}',
        "line_numbers": "Zeilennummern anzeigen", "auto_save": "Entwurf automatisch speichern und wiederherstellen",
        "warn_unsaved": "Vor ungespeicherten Änderungen warnen",
        "master_volume": "Gesamtlautstärke",
        "shortcuts": "Ctrl+O Öffnen | Ctrl+S Speichern | F5 Kompilieren | F6 Abspielen | Esc Stoppen",
        "cancel": "Abbrechen", "apply": "Übernehmen", "invalid_setting": "Ungültige Einstellung",
        "invalid_font": "Die Schriftgröße muss eine ganze Zahl zwischen 12 und 24 sein.",
        "invalid_master_volume": "Die Gesamtlautstärke muss eine ganze Zahl zwischen 0 und 100 sein.",
        "invalid_options": "Wähle eine unterstützte Sprache, ein Design und ein Syntaxfarbschema.",
        "settings_save_failed": "Einstellungen konnten nicht gespeichert werden",
        "open_failed": "Öffnen fehlgeschlagen", "save_failed": "Speichern fehlgeschlagen",
        "settings_saved": "Einstellungen gespeichert.", "draft_saved": "Entwurf automatisch gespeichert.",
        "draft_restored": "Automatisch gespeicherten Entwurf wiederhergestellt.",
        "draft_read_failed": "Entwurf konnte nicht gelesen werden: {message}",
        "draft_invalid": "Ungültiger Entwurf; er wurde verworfen.",
        "draft_clear_failed": "Entwurf konnte nicht gelöscht werden: {message}",
        "draft_save_failed": "Entwurf konnte nicht gespeichert werden: {message}",
        "preset_standard": "Standard", "preset_soft": "Sanft", "preset_primary": "Primär",
        "preset_blue": "Blau", "preset_red": "Rot", "preset_purple": "Lila",
        "preset_sunset": "Sonnenuntergang", "preset_monochrome": "Monochrom",
        "preset_colorVision": "Farbenblind-freundlich",
        "preset_colorVisionWarm": "Farbenblind-freundlich (warm)",
        "preset_colorVisionContrast": "Farbenblind-freundlich (hoher Kontrast)",
        "settings_invalid": "Ungültige Einstellungen in {path}; Standardwerte werden verwendet.",
        "settings_load_failed": "Einstellungen aus {path} konnten nicht geladen werden: {message}",
        "settings_fallback": "Ungültige Einstellungen ({items}) in {path}; Standardwerte verwendet.",
        "editor_font_size_set": "Editor-Schriftgröße auf {size} pt gesetzt.",
    },
    "fr": {
        "file": "Fichier", "edit": "Édition", "settings": "Paramètres", "new": "Nouveau",
        "new_project": "Nouveau projet",
        "open": "Ouvrir...", "save": "Enregistrer", "save_as": "Enregistrer sous...",
        "exit": "Quitter", "subtitle": "Sound Wav Script Studio Editor",
        "edit_undo": "Annuler", "edit_redo": "Rétablir",
        "select_all": "Tout sélectionner", "compile": "Compiler",
        "source": "SOURCE", "output": "SORTIE", "clear": "Effacer", "ready": "Prêt",
        "play": "Lire", "stop": "Arrêter", "rendering": "Génération audio...",
        "playing": "Lecture...", "playback_started": "Lecture démarrée.",
        "utau_progress_sample": "Fichier échantillon : {detail}",
        "utau_progress_pitch": "Génération de la hauteur : {detail}",
        "utau_progress_cache": "Note en cache réutilisée : {detail}",
        "utau_progress_success": "Réussi : {completed}/{total} {detail}",
        "utau_cache_cleanup_title": "Échec de suppression du cache UTAU",
        "utau_cache_cleanup_failed": (
            "Certains caches temporaires de notes UTAU n'ont pas pu être supprimés : {errors}"
        ),
        "playback_complete": "Lecture terminée.", "playback_stopped": "Lecture arrêtée.",
        "playback_failed_status": "Échec de la lecture",
        "playback_failed": "Échec de la lecture : {message}",
        "stop_requested": "Arrêt de la lecture...",
        "no_sound": "Aucun événement sonore à lire.",
        "new_document": "Nouveau document", "opened": "Ouvert", "saved": "Enregistré",
        "unsaved": "Modifications non enregistrées", "compiling": "Compilation...",
        "compile_success": "Compilation réussie : {count} événement(s) sonore(s).",
        "compile_failed_status": "Échec de la compilation",
        "compile_failed": "Échec de la compilation : {message}",
        "compile_error": "Erreur à la ligne {line} ({kind}) : {message}",
        "compiling_source": "Compilation du contenu de l’éditeur...",
        "open_file": "Ouvrir un fichier",
        "open_source": "Ouvrir un code source SWS", "save_source": "Enregistrer le code source SWS",
        "export_as": "Enregistrer au format",
        "export_midi": "Enregistrer en MIDI (.midi)...",
        "export_wav": "Enregistrer en WAV (.wav)...",
        "export_ust": "Enregistrer en UST (.ust)...",
        "save_selected_track": "Enregistrer la piste sélectionnée...",
        "save_track_source": "Code source SWS (.ss)",
        "save_track_ust": "UST (.ust)",
        "save_track_mid": "MIDI (.mid)",
        "save_track_midi": "MIDI (.midi)",
        "save_track_wav": "WAV (.wav)",
        "track_saved": 'Piste « {track} » enregistrée dans {path}.',
        "midi_imported": "MIDI importé : {path}",
        "midi_files": "Fichiers MIDI",
        "no_track_events": "La piste sélectionnée ne contient aucun événement sonore à exporter.",
        "exporting_wav": "Exportation WAV...",
        "export_success": "{format} exporté : {path}",
        "export_failed": "Échec de l’exportation : {message}",
        "ust_export_unsupported": (
            "L’export UST nécessite des événements sans chevauchement. "
            "Les changements de tempo ne doivent pas survenir au milieu d’une note."
        ),
        "search": "Rechercher...", "search_title": "Rechercher dans le code",
        "find_previous": "Précédent", "find_next": "Suivant",
        "search_not_found": "Aucun résultat trouvé.",
        "replace_selected_text": "Remplacer le texte sélectionné...",
        "replace_title": "Remplacer le texte sélectionné",
        "replace_source": "Texte d’origine",
        "replace_target": "Remplacer par",
        "replace_no_selection": "Sélectionnez d’abord le texte à remplacer.",
        "recent_files": "Fichiers récents",
        "recent_files_empty": "Aucun fichier récent",
        "recent_files_load_failed": "Impossible de charger les fichiers récents : {message}",
        "recent_files_invalid": "La liste des fichiers récents est invalide.",
        "recent_files_save_failed": "Impossible d’enregistrer les fichiers récents : {message}",
        "open_ust_with_instrument": "Ouvrir .ust avec un instrument...",
        "load_utau_voicebank": "Charger une banque de voix UTAU...",
        "voicebank_loaded": "« {name} » chargée ({entries} entrées oto, {warnings} avertissement(s)).",
        "voicebank_metadata": "Métadonnées de character.txt",
        "voicebank_warnings": "Avertissements de lecture",
        "voicebank_load_failed": "Impossible de charger la banque de voix UTAU",
        "voicebank_info": "Informations sur la banque de voix UTAU",
        "voicebank_overview": "Aperçu",
        "voicebank_oto": "oto.ini",
        "voicebank_readme": "Readme",
        "voicebank_no_readme": "Aucun fichier readme.txt ou fichier Readme indiqué n’a été trouvé.",
        "voicebank_readme_unavailable": "Le fichier Readme indiqué n’a pas pu être chargé.",
        "voicebank_no_metadata": "Aucune métadonnée character.txt trouvée.",
        "voicebank_no_oto": "Aucune entrée oto.ini n’a été lue.",
        "voicebank_folder": "Dossier de la banque",
        "voicebank_oto_count": "Entrées oto.ini",
        "ust_instrument_title": "Ouvrir UST avec un instrument",
        "ust_instrument_prompt": "Choisissez l’instrument à utiliser pour cet UST :",
        "ust_files": "Fichiers UST",
        "ust_imported": "UST importé avec {instrument} : {path}",
        "supported_files": "Fichiers pris en charge",
        "sws_files": "Code source SWS", "text_files": "Fichiers texte",
        "all_files": "Tous les fichiers", "unsaved_title": "Modifications non enregistrées",
        "unsaved_prompt": "Enregistrer les modifications avant de continuer ?",
        "restore_title": "Restaurer le brouillon",
        "restore_prompt": "Un brouillon enregistré automatiquement a été trouvé. Le restaurer ?",
        "settings_title": "Paramètres", "editor": "Éditeur", "language": "Langue d’affichage",
        "font_size": "Taille de la police de l’éditeur", "theme": "Thème",
        "dark": "Sombre", "light": "Clair", "syntax_preset": "Palette de syntaxe",
        "wrap": "Renvoyer les longues lignes à la ligne",
        "auto_indent": "Indenter automatiquement après Entrée",
        "playback": "Lecture",
        "use_utau_tools": "Forcer la lecture UTAU pour tous les instruments",
        "wavtool_path": "Wavtool",
        "resampler_path": "Échantillonneur (resampler)",
        "resampler_flags": "Drapeaux du resampler (ex. : g+0)",
        "browse": "Parcourir...",
        "select_utau_tool": "Sélectionner un outil UTAU",
        "utau_playback_setup_note": "La lecture UTAU nécessite une banque vocale chargée et des chemins wavtool/resampler valides.",
        "utau_playback_not_ready": "Chargez une banque vocale UTAU avant de lancer la lecture.",
        "utau_output_plugin_conflict": "La lecture UTAU ne peut pas être combinée à un plug-in de sortie.",
        "utau_filename_fallback": 'Le fichier WAV de remplacement UTAU pour "{alias}" utilise un timing nul : {path}',
        "line_numbers": "Afficher les numéros de ligne",
        "auto_save": "Enregistrer et restaurer automatiquement le brouillon",
        "warn_unsaved": "Avertir en cas de modifications non enregistrées",
        "master_volume": "Volume principal",
        "shortcuts": "Ctrl+O Ouvrir | Ctrl+S Enregistrer | F5 Compiler | F6 Lire | Échap Arrêter",
        "cancel": "Annuler", "apply": "Appliquer", "invalid_setting": "Paramètre non valide",
        "invalid_font": "La taille doit être un nombre entier compris entre 12 et 24.",
        "invalid_master_volume": "Le volume principal doit être un nombre entier compris entre 0 et 100.",
        "invalid_options": "Choisissez une langue, un thème et une palette de syntaxe pris en charge.",
        "settings_save_failed": "Impossible d’enregistrer les paramètres",
        "open_failed": "Échec de l’ouverture", "save_failed": "Échec de l’enregistrement",
        "settings_saved": "Paramètres enregistrés.", "draft_saved": "Brouillon enregistré automatiquement.",
        "draft_restored": "Brouillon enregistré automatiquement restauré.",
        "draft_read_failed": "Impossible de lire le brouillon : {message}",
        "draft_invalid": "Brouillon non valide ; il a été supprimé.",
        "draft_clear_failed": "Impossible de supprimer le brouillon : {message}",
        "draft_save_failed": "Impossible d’enregistrer le brouillon : {message}",
        "preset_standard": "Standard", "preset_soft": "Doux", "preset_primary": "Primaire",
        "preset_blue": "Bleu", "preset_red": "Rouge", "preset_purple": "Violet",
        "preset_sunset": "Coucher de soleil", "preset_monochrome": "Monochrome",
        "preset_colorVision": "Adapté aux personnes daltoniennes",
        "preset_colorVisionWarm": "Adapté aux personnes daltoniennes (tons chauds)",
        "preset_colorVisionContrast": "Adapté aux personnes daltoniennes (contraste élevé)",
        "settings_invalid": "Paramètres non valides dans {path} ; valeurs par défaut utilisées.",
        "settings_load_failed": "Impossible de charger les paramètres depuis {path} : {message}",
        "settings_fallback": "Paramètres non valides ({items}) dans {path} ; valeurs par défaut utilisées.",
        "editor_font_size_set": "Taille de la police réglée sur {size} pt.",
    },
    "it": {
        "file": "File", "edit": "Modifica", "settings": "Impostazioni", "new": "Nuovo",
        "new_project": "Nuovo progetto",
        "open": "Apri...", "save": "Salva", "save_as": "Salva con nome...",
        "exit": "Esci", "subtitle": "Sound Wav Script Studio Editor",
        "edit_undo": "Annulla", "edit_redo": "Ripeti",
        "select_all": "Seleziona tutto", "compile": "Compila",
        "source": "SORGENTE", "output": "OUTPUT", "clear": "Cancella", "ready": "Pronto",
        "play": "Riproduci", "stop": "Ferma", "rendering": "Generazione audio...",
        "playing": "Riproduzione...", "playback_started": "Riproduzione avviata.",
        "utau_progress_sample": "File campione: {detail}",
        "utau_progress_pitch": "Generazione dell'intonazione: {detail}",
        "utau_progress_cache": "Nota memorizzata nella cache riutilizzata: {detail}",
        "utau_progress_success": "Completato: {completed}/{total} {detail}",
        "utau_cache_cleanup_title": "Pulizia della cache UTAU non riuscita",
        "utau_cache_cleanup_failed": (
            "Impossibile eliminare alcune cache temporanee delle note UTAU: {errors}"
        ),
        "playback_complete": "Riproduzione terminata.", "playback_stopped": "Riproduzione interrotta.",
        "playback_failed_status": "Riproduzione non riuscita",
        "playback_failed": "Riproduzione non riuscita: {message}",
        "stop_requested": "Interruzione della riproduzione...",
        "no_sound": "Nessun evento sonoro da riprodurre.",
        "new_document": "Nuovo documento", "opened": "Aperto", "saved": "Salvato",
        "unsaved": "Modifiche non salvate", "compiling": "Compilazione...",
        "compile_success": "Compilazione riuscita: {count} evento/i sonoro/i.",
        "compile_failed_status": "Compilazione non riuscita",
        "compile_failed": "Compilazione non riuscita: {message}",
        "compile_error": "Errore alla riga {line} ({kind}): {message}",
        "compiling_source": "Compilazione del contenuto dell’editor...",
        "open_file": "Apri file",
        "open_source": "Apri sorgente SWS", "save_source": "Salva sorgente SWS",
        "export_as": "Salva nel formato",
        "export_midi": "Salva come MIDI (.midi)...",
        "export_wav": "Salva come WAV (.wav)...",
        "export_ust": "Salva come UST (.ust)...",
        "save_selected_track": "Salva la traccia selezionata...",
        "save_track_source": "Sorgente SWS (.ss)",
        "save_track_ust": "UST (.ust)",
        "save_track_mid": "MIDI (.mid)",
        "save_track_midi": "MIDI (.midi)",
        "save_track_wav": "WAV (.wav)",
        "track_saved": 'Traccia "{track}" salvata in {path}.',
        "midi_imported": "MIDI importato: {path}",
        "midi_files": "File MIDI",
        "no_track_events": "La traccia selezionata non contiene eventi audio da esportare.",
        "exporting_wav": "Esportazione WAV...",
        "export_success": "Esportato {format}: {path}",
        "export_failed": "Esportazione non riuscita: {message}",
        "ust_export_unsupported": (
            "L’esportazione UST richiede eventi non sovrapposti. "
            "I cambi di tempo non devono avvenire durante una nota."
        ),
        "search": "Cerca...", "search_title": "Cerca nel codice",
        "find_previous": "Precedente", "find_next": "Successivo",
        "search_not_found": "Nessuna corrispondenza trovata.",
        "replace_selected_text": "Sostituisci il testo selezionato...",
        "replace_title": "Sostituisci il testo selezionato",
        "replace_source": "Testo originale",
        "replace_target": "Sostituisci con",
        "replace_no_selection": "Seleziona prima il testo da sostituire.",
        "recent_files": "File recenti",
        "recent_files_empty": "Nessun file recente",
        "recent_files_load_failed": "Impossibile caricare i file recenti: {message}",
        "recent_files_invalid": "L’elenco dei file recenti non è valido.",
        "recent_files_save_failed": "Impossibile salvare i file recenti: {message}",
        "open_ust_with_instrument": "Apri .ust con uno strumento...",
        "load_utau_voicebank": "Carica voicebank UTAU...",
        "voicebank_loaded": 'Caricata "{name}" ({entries} voci oto, {warnings} avvisi).',
        "voicebank_metadata": "Metadati di character.txt",
        "voicebank_warnings": "Avvisi di lettura",
        "voicebank_load_failed": "Impossibile caricare la voicebank UTAU",
        "voicebank_info": "Informazioni voicebank UTAU",
        "voicebank_overview": "Panoramica",
        "voicebank_oto": "oto.ini",
        "voicebank_readme": "Readme",
        "voicebank_no_readme": "Nessun file readme.txt o Readme indicato trovato.",
        "voicebank_readme_unavailable": "Impossibile caricare il Readme indicato.",
        "voicebank_no_metadata": "Nessun metadato character.txt trovato.",
        "voicebank_no_oto": "Nessuna voce oto.ini letta.",
        "voicebank_folder": "Cartella voicebank",
        "voicebank_oto_count": "Voci oto.ini",
        "ust_instrument_title": "Apri UST con uno strumento",
        "ust_instrument_prompt": "Seleziona lo strumento da usare per questo UST:",
        "ust_files": "File UST",
        "ust_imported": "UST importato con {instrument}: {path}",
        "supported_files": "File supportati",
        "sws_files": "Sorgente SWS", "text_files": "File di testo",
        "all_files": "Tutti i file", "unsaved_title": "Modifiche non salvate",
        "unsaved_prompt": "Salvare le modifiche prima di continuare?",
        "restore_title": "Ripristina bozza",
        "restore_prompt": "È stata trovata una bozza salvata automaticamente. Ripristinarla?",
        "settings_title": "Impostazioni", "editor": "Editor", "language": "Lingua dell’interfaccia",
        "font_size": "Dimensione del carattere", "theme": "Tema",
        "dark": "Scuro", "light": "Chiaro", "syntax_preset": "Schema colori sintassi",
        "wrap": "Vai a capo nelle righe lunghe", "line_numbers": "Mostra i numeri di riga",
        "auto_indent": "Indenta automaticamente dopo Invio",
        "playback": "Riproduzione",
        "use_utau_tools": "Forza la riproduzione UTAU per tutti gli strumenti",
        "wavtool_path": "Wavtool",
        "resampler_path": "Campionatore (resampler)",
        "resampler_flags": "Flag del resampler (es. g+0)",
        "browse": "Sfoglia...",
        "select_utau_tool": "Seleziona uno strumento UTAU",
        "utau_playback_setup_note": "La riproduzione UTAU richiede una voicebank caricata e percorsi wavtool/resampler validi.",
        "utau_playback_not_ready": "Carica una voicebank UTAU prima della riproduzione.",
        "utau_output_plugin_conflict": "La riproduzione UTAU non può essere combinata con un plugin di output.",
        "utau_filename_fallback": 'Il WAV di fallback UTAU per "{alias}" usa timing zero: {path}',
        "auto_save": "Salva e ripristina automaticamente la bozza",
        "warn_unsaved": "Avvisa in caso di modifiche non salvate",
        "master_volume": "Volume principale",
        "shortcuts": "Ctrl+O Apri | Ctrl+S Salva | F5 Compila | F6 Riproduci | Esc Ferma",
        "cancel": "Annulla", "apply": "Applica", "invalid_setting": "Impostazione non valida",
        "invalid_font": "La dimensione deve essere un numero intero da 12 a 24.",
        "invalid_master_volume": "Il volume principale deve essere un numero intero da 0 a 100.",
        "invalid_options": "Scegli una lingua, un tema e uno schema colori supportati.",
        "settings_save_failed": "Impossibile salvare le impostazioni",
        "open_failed": "Apertura non riuscita", "save_failed": "Salvataggio non riuscito",
        "settings_saved": "Impostazioni salvate.", "draft_saved": "Bozza salvata automaticamente.",
        "draft_restored": "Bozza salvata automaticamente ripristinata.",
        "draft_read_failed": "Impossibile leggere la bozza: {message}",
        "draft_invalid": "Bozza non valida; è stata eliminata.",
        "draft_clear_failed": "Impossibile eliminare la bozza: {message}",
        "draft_save_failed": "Impossibile salvare la bozza: {message}",
        "preset_standard": "Standard", "preset_soft": "Tenue", "preset_primary": "Primario",
        "preset_blue": "Blu", "preset_red": "Rosso", "preset_purple": "Viola",
        "preset_sunset": "Tramonto", "preset_monochrome": "Monocromatico",
        "preset_colorVision": "Accessibile per daltonismo",
        "preset_colorVisionWarm": "Accessibile per daltonismo (toni caldi)",
        "preset_colorVisionContrast": "Accessibile per daltonismo (alto contrasto)",
        "settings_invalid": "Impostazioni non valide in {path}; uso dei valori predefiniti.",
        "settings_load_failed": "Impossibile caricare le impostazioni da {path}: {message}",
        "settings_fallback": "Impostazioni non valide ({items}) in {path}; usati i valori predefiniti.",
        "editor_font_size_set": "Dimensione del carattere impostata su {size} pt.",
    },
}
THEMES = {
    "dark": {
        "background": "#1e1e1e",
        "panel": "#252526",
        "editor": "#1e1e1e",
        "foreground": "#d4d4d4",
        "muted": "#858585",
        "accent": "#0e639c",
        "button": "#333333",
        "button_active": "#454545",
        "selection": "#264f78",
        "comment": "#84909c",
        "keyword": "#ffc107",
        "command": "#4db3ff",
    },
    "light": {
        "background": "#f4f6f8",
        "panel": "#ffffff",
        "editor": "#fbfcfe",
        "foreground": "#20262e",
        "muted": "#667085",
        "accent": "#1565c0",
        "button": "#e5e9ef",
        "button_active": "#d5dbe3",
        "selection": "#c6ddf7",
        "comment": "#7b8794",
        "keyword": "#996600",
        "command": "#1565c0",
    },
}
SYNTAX_PRESETS = {
    "standard": {
        "dark": (None, "#ff6b6b", "#90ee90", "#4dd0e1", "#ffb74d"),
        "light": (None, "#c62828", "#28752e", "#00838f", "#ef6c00"),
    },
    "soft": {
        "dark": (None, "#ff9e9e", "#a5d6a7", "#80deea", "#ffcc80"),
        "light": (None, "#ad1457", "#2e7d32", "#00838f", "#e65100"),
    },
    "primary": {
        "dark": ("#4040FF", "#FF4040", "#40FF40", "#40ffff", "#ff8040"),
        "light": ("#4040FF", "#FF4040", "#40FF40", "#40ffff", "#ff8040"),
    },
    "blue": {
        "dark": ("#5070ff", "#ff50aa", "#50ffb0", "#50ffff", "#50ff7f"),
        "light": ("#5070ff", "#ff50aa", "#50ffb0", "#50ffff", "#50ff7f"),
    },
    "red": {
        "dark": ("#bf10ff", "#FF1010", "#ffff10", "#ff10df", "#ff9f50"),
        "light": ("#bf10ff", "#FF1010", "#ffff10", "#ff10df", "#ff9f50"),
    },
    "purple": {
        "dark": ("#b388ff", "#ff80ab", "#a7ffeb", "#80d8ff", "#ffd180"),
        "light": ("#6200ea", "#c2185b", "#00796b", "#0277bd", "#e65100"),
    },
    "sunset": {
        "dark": ("#ffca80", "#ff7070", "#b4f08c", "#72e0df", "#ff9e57"),
        "light": ("#8d4b00", "#b71c1c", "#33691e", "#00695c", "#bf360c"),
    },
    "monochrome": {
        "dark": ("#b0bec5", "#ffffff", "#e0e0e0", "#90a4ae", "#cfd8dc"),
        "light": ("#546e7a", "#111111", "#424242", "#607d8b", "#37474f"),
    },
    "colorVision": {
        "dark": ("#56B4E9", "#E69F00", "#009E73", "#CC79A7", "#F0E442"),
        "light": ("#0072B2", "#A85B00", "#007A55", "#9C3F7A", "#806000"),
    },
    "colorVisionWarm": {
        "dark": ("#E69F00", "#CC79A7", "#009E73", "#D55E00", "#F0E442"),
        "light": ("#8A5700", "#9C3F7A", "#007A55", "#A33A00", "#705600"),
    },
    "colorVisionContrast": {
        "dark": ("#56B4E9", "#F0E442", "#009E73", "#CC79A7", "#FFFFFF"),
        "light": ("#005A8D", "#705500", "#005C43", "#7A315F", "#111111"),
    },
}
KEYWORDS = {
    "sws": (
        "if", "else", "for", "of", "frame", "let", "const", "number", "true",
        "false", "null",
    ),
    "js": (
        "if", "else", "for", "of", "let", "const", "var", "function", "return",
        "true", "false", "null", "break", "continue", "switch", "case", "default",
    ),
    "py": (
        "if", "elif", "else", "for", "while", "in", "and", "or", "not", "is",
        "True", "False", "None", "def", "return", "from", "import", "as", "pass",
        "break", "continue",
    ),
}
COMMANDS = (
    "snd", "lp", "chips", "tempoconst", "newtempo", "key", "index", "output",
    "plugin", "sleep",
)
HIGHLIGHT_TAGS = ("comment", "string", "keyword", "command", "function", "number", "pitch")


@dataclass
class InputPluginView:
    name: str
    window: tk.Toplevel
    content: ttk.Frame
    status: ttk.Label
    session: JavaScriptInputSession
    tree: dict[str, object] | None = None
    widgets: dict[int, tk.Misc] = field(default_factory=dict)
    variables: dict[int, tk.Variable] = field(default_factory=dict)


@dataclass
class PythonInputPluginView:
    name: str
    window: tk.Toplevel
    status: ttk.Label
    cleanup: Callable[[], object] | None = None


class PythonInputPluginEditor:
    def __init__(self, app: "SWSEditor") -> None:
        self._app = app

    @property
    def text(self) -> str:
        return self._app.editor.get("1.0", "end-1c")

    @property
    def selection(self) -> tuple[int, int]:
        state = self._app._input_plugin_editor_state()
        selection = state["selection"]
        if not isinstance(selection, dict):
            raise TypeError("editor selection is invalid")
        start = selection.get("start")
        end = selection.get("end")
        if not isinstance(start, int) or not isinstance(end, int):
            raise TypeError("editor selection is invalid")
        return start, end

    def insert_text(self, text: str) -> None:
        start, end = self.selection
        self.replace_range(start, end, text)

    def replace_selection(self, text: str) -> None:
        self.insert_text(text)

    def replace_range(self, start: int, end: int, text: str) -> None:
        self._app._apply_input_plugin_operations(
            [{"op": "replaceRange", "start": start, "end": end, "text": text}]
        )

    def replace_all(self, text: str) -> None:
        end = len(self.text.encode("utf-16-le")) // 2
        self.replace_range(0, end, text)

    def set_selection(self, start: int, end: int | None = None) -> None:
        self._app._apply_input_plugin_operations(
            [
                {
                    "op": "setSelection",
                    "start": start,
                    "end": start if end is None else end,
                }
            ]
        )


class SWSEditor:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.current_path: Path | None = None
        self.current_ust_path: Path | None = None
        self._utau_resample_caches: dict[
            Path,
            sws_engine.UTAUResampleCacheSession,
        ] = {}
        self.modified = False
        self.loading = False
        self.compiling = False
        self.active_task: str | None = None
        self.playback_phase = ""
        self.playback_stop_event = threading.Event()
        self._playback_input_locked = False
        self._playback_lock_tag = f"SWSPlaybackLock{id(self)}"
        self._playback_widget_states: list[tuple[tk.Misc, str]] = []
        self._playback_menu_states: list[tuple[tk.Menu, int, str]] = []
        self.closing = False
        self.compile_results: SimpleQueue[tuple[str, object]] = SimpleQueue()
        self._compile_result_after_id: str | None = None
        self.settings = DEFAULT_SETTINGS.copy()
        self.language = self.settings["language"]
        self.font_size = self.settings["editorFontSize"]
        self.theme_colors = THEMES[self.settings["theme"]]
        self.settings_path = SETTINGS_PATH
        self.draft_path = DRAFT_PATH
        self.recent_files_path = RECENT_FILES_PATH
        self.recent_files: list[Path] = []
        self.settings_dialog: tk.Toplevel | None = None
        self.search_dialog: tk.Toplevel | None = None
        self.search_entry: ttk.Entry | None = None
        self.search_query: tk.StringVar | None = None
        self.search_status: ttk.Label | None = None
        self.replace_dialog: tk.Toplevel | None = None
        self.replace_source: tk.Text | None = None
        self.replace_target: tk.Text | None = None
        self.replace_range: tuple[str, str] | None = None
        self.replace_original_text = ""
        self._highlight_after_id: str | None = None
        self._highlight_patterns: dict[str, re.Pattern[str]] = {}
        self._draft_after_id: str | None = None
        self.track_segments: list[SourceSegment] = []
        self.track_buffers: dict[TrackKey, str] = {None: ""}
        self.track_baseline: dict[TrackKey, str] = {None: ""}
        self.active_track: TrackKey = None
        self.track_tab_buttons: dict[TrackKey, ttk.Button] = {}
        self.muted_tracks: set[TrackKey] = set()
        self.solo_tracks: set[TrackKey] = set()
        self.loaded_js_plugins: dict[str, str] = {}
        self.loaded_plugin_syntaxes: dict[str, str] = {}
        self.loaded_input_plugins: dict[str, str] = {}
        self.loaded_input_plugin_syntaxes: dict[str, str] = {}
        self.output_plugin: tuple[str, str] | None = None
        self.output_plugin_syntax = "JS"
        self.utau_voicebank: sws_engine.UTAUVoicebank | None = None
        self.utau_voicebank_info_button: ttk.Button | None = None
        self.voicebank_info_dialog: tk.Toplevel | None = None
        self.input_plugin_views: dict[
            str,
            InputPluginView | PythonInputPluginView,
        ] = {}
        settings_warning = self._load_settings()
        self.language = self.settings["language"]
        self.recent_files, recent_files_warning = self._load_recent_files()

        self.root.title(APP_NAME)
        self.root.geometry("1100x760")
        self.root.minsize(720, 480)
        self.theme_colors = THEMES[self.settings["theme"]]
        self.root.configure(background=self.theme_colors["background"])
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self._configure_style()
        self._create_menu()
        self._create_widgets()
        self._apply_editor_preferences()
        self._apply_locale()
        self._set_source(STARTER_SOURCE)
        self._update_title()
        self._write_output(self._t("ready"))
        if settings_warning:
            self._write_output(settings_warning)
        if recent_files_warning:
            self._write_output(recent_files_warning)
        self._restore_draft()

        self.root.bind("<Control-n>", lambda _event: self.new_document())
        self.root.bind("<Control-o>", lambda _event: self.open_document())
        self.root.bind("<Control-s>", lambda _event: self.save_document())
        self.root.bind("<Control-Shift-s>", lambda _event: self.save_document_as())
        self.root.bind("<F5>", lambda _event: self.compile_document())
        self.root.bind("<F6>", lambda _event: self.play_document())
        self.root.bind("<Escape>", lambda _event: self.stop_playback())
        self.editor.bind("<Control-a>", self._select_all)
        self.editor.bind("<Control-z>", lambda _event: self._run_undo_shortcut())
        self.editor.bind("<Control-y>", lambda _event: self._run_redo_shortcut())
        self.editor.bind("<Control-f>", lambda _event: self._run_search_shortcut())
        self.root.bind("<Destroy>", self._handle_root_destroy, add="+")
        self._schedule_compile_result_poll()

    def _t(self, key: str, **values: object) -> str:
        text = TRANSLATIONS.get(self.language, TRANSLATIONS["en-US"]).get(
            key,
            TRANSLATIONS["en-US"].get(key, key),
        )
        return text.format(**values)

    def _load_recent_files(self) -> tuple[list[Path], str | None]:
        try:
            saved = json.loads(
                self.recent_files_path.read_text(encoding="utf-8")
            )
        except FileNotFoundError:
            return [], None
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            return [], self._t("recent_files_load_failed", message=error)

        if not isinstance(saved, list):
            return [], self._t("recent_files_invalid")

        recent_files: list[Path] = []
        invalid_entry = False
        for value in saved:
            if not isinstance(value, str):
                invalid_entry = True
                continue
            path = Path(value)
            if path.is_file() and path not in recent_files:
                recent_files.append(path)
        if invalid_entry:
            return recent_files[:MAX_RECENT_FILES], self._t("recent_files_invalid")
        return recent_files[:MAX_RECENT_FILES], None

    def _save_recent_files(self) -> None:
        try:
            self.recent_files_path.parent.mkdir(parents=True, exist_ok=True)
            self.recent_files_path.write_text(
                json.dumps([str(path) for path in self.recent_files], indent=2),
                encoding="utf-8",
            )
        except OSError as error:
            message = self._t("recent_files_save_failed", message=error)
            messagebox.showerror(
                self._t("save_failed"),
                message,
                parent=self.root,
            )
            self._write_output(message)

    def _remember_recent_file(self, path: Path) -> None:
        resolved_path = path.resolve()
        resolved_key = str(resolved_path).casefold()
        self.recent_files = [
            recent_path
            for recent_path in self.recent_files
            if str(recent_path.resolve()).casefold() != resolved_key
        ]
        self.recent_files.insert(0, resolved_path)
        del self.recent_files[MAX_RECENT_FILES:]
        self._refresh_recent_files_menu()
        self._save_recent_files()

    def _refresh_recent_files_menu(self) -> None:
        if not hasattr(self, "recent_menu"):
            return
        self.recent_menu.delete(0, tk.END)
        if not self.recent_files:
            self.recent_menu.add_command(
                label=self._t("recent_files_empty"),
                state=tk.DISABLED,
            )
            return

        name_counts: dict[str, int] = {}
        for path in self.recent_files:
            name_counts[path.name.casefold()] = (
                name_counts.get(path.name.casefold(), 0) + 1
            )
        for path in self.recent_files:
            label = path.name
            if name_counts[path.name.casefold()] > 1:
                label = f"{path.name} ({path.parent})"
            self.recent_menu.add_command(
                label=label,
                command=lambda recent_path=path: self.open_recent_file(
                    recent_path
                ),
            )

    def open_recent_file(self, path: Path) -> None:
        if not path.is_file():
            messagebox.showerror(
                self._t("open_failed"),
                str(path),
                parent=self.root,
            )
            self.recent_files = [item for item in self.recent_files if item != path]
            self._refresh_recent_files_menu()
            self._save_recent_files()
            return
        if path.suffix.lower() == ".ust":
            self.open_ust_with_instrument(str(path))
        else:
            self.open_document(str(path))

    def _configure_style(self) -> None:
        colors = self.theme_colors
        style = ttk.Style(self.root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background=colors["background"])
        style.configure("Panel.TFrame", background=colors["panel"])
        style.configure(
            "TLabel",
            background=colors["background"],
            foreground=colors["foreground"],
        )
        style.configure(
            "Muted.TLabel",
            background=colors["background"],
            foreground=colors["muted"],
            font=("Segoe UI", 9),
        )
        style.configure(
            "Title.TLabel",
            background=colors["background"],
            foreground=colors["foreground"],
            font=("Segoe UI Semibold", 14),
        )
        style.configure(
            "TButton",
            background=colors["button"],
            foreground=colors["foreground"],
            padding=(12, 6),
            borderwidth=0,
        )
        style.map(
            "TButton",
            background=[
                ("active", colors["button_active"]),
                ("disabled", colors["panel"]),
            ],
            foreground=[("disabled", colors["muted"])],
        )
        style.configure(
            "Accent.TButton",
            background=colors["accent"],
            foreground="#ffffff",
            padding=(14, 6),
            borderwidth=0,
        )
        style.map(
            "Accent.TButton",
            background=[
                ("active", colors["accent"]),
                ("disabled", colors["panel"]),
            ],
            foreground=[("disabled", "#a0a0a0")],
        )
        style.configure(
            "TrackTab.TButton",
            background=colors["button"],
            foreground=colors["muted"],
            padding=(10, 4),
            borderwidth=0,
        )
        style.configure(
            "ActiveTrack.TButton",
            background=colors["editor"],
            foreground=colors["foreground"],
            padding=(10, 4),
            borderwidth=0,
        )
        style.map(
            "TrackTab.TButton",
            background=[("active", colors["button_active"])],
        )
        style.map(
            "ActiveTrack.TButton",
            background=[("active", colors["editor"])],
        )

    def _create_menu(self) -> None:
        menu = tk.Menu(
            self.root,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
            activebackground=self.theme_colors["accent"],
            activeforeground="#ffffff",
            tearoff=False,
        )
        file_menu = tk.Menu(
            menu,
            tearoff=False,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
            activebackground=self.theme_colors["accent"],
            activeforeground="#ffffff",
        )
        file_menu.add_command(
            label=self._t("new_project"),
            accelerator="Ctrl+N",
            command=self.new_document,
        )
        file_menu.add_command(
            label=self._t("open"), accelerator="Ctrl+O", command=self.open_document
        )
        recent_menu = tk.Menu(
            file_menu,
            tearoff=False,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
            activebackground=self.theme_colors["accent"],
            activeforeground="#ffffff",
        )
        self.recent_menu = recent_menu
        file_menu.add_cascade(label=self._t("recent_files"), menu=recent_menu)
        file_menu.add_command(
            label=self._t("open_ust_with_instrument"),
            command=self.open_ust_with_instrument,
        )
        file_menu.add_separator()
        file_menu.add_command(
            label=self._t("save"), accelerator="Ctrl+S", command=self.save_document
        )
        file_menu.add_command(
            label=self._t("save_as"),
            accelerator="Ctrl+Shift+S",
            command=self.save_document_as,
        )
        export_menu = tk.Menu(
            file_menu,
            tearoff=False,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
            activebackground=self.theme_colors["accent"],
            activeforeground="#ffffff",
        )
        export_menu.add_command(
            label=self._t("export_midi"),
            command=self.export_midi,
        )
        export_menu.add_command(
            label=self._t("export_wav"),
            command=self.export_wav,
        )
        export_menu.add_command(
            label=self._t("export_ust"),
            command=self.export_ust,
        )
        self.export_menu = export_menu
        file_menu.add_cascade(label=self._t("export_as"), menu=export_menu)
        file_menu.add_separator()
        save_track_menu = tk.Menu(
            file_menu,
            tearoff=False,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
        )
        for translation_key, file_format in (
            ("save_track_source", "ss"),
            ("save_track_ust", "ust"),
            ("save_track_mid", "mid"),
            ("save_track_midi", "midi"),
            ("save_track_wav", "wav"),
        ):
            save_track_menu.add_command(
                label=self._t(translation_key),
                command=lambda selected_format=file_format: (
                    self.save_selected_track(selected_format)
                ),
            )
        self.save_track_menu = save_track_menu
        file_menu.add_cascade(
            label=self._t("save_selected_track"),
            menu=save_track_menu,
        )
        file_menu.add_separator()
        file_menu.add_command(
            label=self._t("load_utau_voicebank"),
            command=self.load_utau_voicebank,
        )
        file_menu.add_separator()
        file_menu.add_command(label=self._t("exit"), command=self.close)
        menu.add_cascade(label=self._t("file"), menu=file_menu)
        self.file_menu = file_menu
        self._refresh_recent_files_menu()

        edit_menu = tk.Menu(
            menu,
            tearoff=False,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
            activebackground=self.theme_colors["accent"],
            activeforeground="#ffffff",
        )
        edit_menu.add_command(
            label=self._t("edit_undo"),
            accelerator="Ctrl+Z",
            command=self.undo_edit,
        )
        edit_menu.add_command(
            label=self._t("edit_redo"),
            accelerator="Ctrl+Y",
            command=self.redo_edit,
        )
        edit_menu.add_separator()
        edit_menu.add_command(
            label=self._t("search"),
            accelerator="Ctrl+F",
            command=self.open_search,
        )
        edit_menu.add_command(
            label=self._t("replace_selected_text"),
            command=self.open_selection_replacement,
            state=tk.DISABLED,
        )
        edit_menu.add_separator()
        edit_menu.add_command(
            label=self._t("select_all"),
            accelerator="Ctrl+A",
            command=lambda: self.editor.event_generate("<<SelectAll>>"),
        )
        edit_menu.configure(postcommand=self._update_edit_menu_state)
        self.edit_menu = edit_menu
        menu.add_cascade(label=self._t("edit"), menu=edit_menu)
        track_menu = tk.Menu(
            menu,
            tearoff=False,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
            activebackground=self.theme_colors["accent"],
            activeforeground="#ffffff",
        )
        track_menu.add_command(
            label=self._t("add_track_item"),
            command=self.add_track,
        )
        track_menu.add_command(
            label=self._t("delete_selected_track"),
            command=self.delete_selected_track,
        )
        track_menu.add_separator()
        self.track_menu_mute_var = tk.BooleanVar(master=self.root, value=False)
        self.track_menu_solo_var = tk.BooleanVar(master=self.root, value=False)
        track_menu.add_checkbutton(
            label=self._t("mute_selected_track"),
            variable=self.track_menu_mute_var,
            command=lambda: self._toggle_selected_track_mix("mute"),
        )
        track_menu.add_checkbutton(
            label=self._t("solo_selected_track"),
            variable=self.track_menu_solo_var,
            command=lambda: self._toggle_selected_track_mix("solo"),
        )
        menu.add_cascade(label=self._t("track_menu"), menu=track_menu)
        self.track_menu = track_menu
        plugin_menu = tk.Menu(
            menu,
            tearoff=False,
            background=self.theme_colors["panel"],
            foreground=self.theme_colors["foreground"],
            activebackground=self.theme_colors["accent"],
            activeforeground="#ffffff",
        )
        plugin_menu.add_command(
            label=self._t("load_js_plugin"),
            command=self.load_js_plugin,
        )
        plugin_menu.add_command(
            label=self._t("load_input_plugin"),
            command=self.load_input_plugin,
        )
        plugin_menu.add_command(
            label=self._t("load_output_plugin"),
            command=self.load_output_plugin,
        )
        plugin_menu.add_command(
            label=self._t("load_ssp_plugin"),
            command=self.load_ssp_plugin,
        )
        plugin_menu.add_command(
            label=self._t("reset_output_plugin"),
            command=self.reset_output_plugin,
        )
        plugin_menu.add_separator()
        menu.add_cascade(label=self._t("plugins_menu"), menu=plugin_menu)
        self.plugin_menu = plugin_menu
        menu.add_command(label=self._t("settings"), command=self.open_settings)
        self.root.configure(menu=menu)
        self.menus = (
            menu,
            file_menu,
            edit_menu,
            track_menu,
            plugin_menu,
            recent_menu,
            export_menu,
        )

    def _plugin_syntax_for_path(self, path: Path) -> str | None:
        return {".js": "JS", ".py": "PY"}.get(path.suffix.lower())

    def _validate_python_plugin(
        self,
        source: str,
        filename: str,
        *,
        error_title_key: str = "plugin_load_failed",
    ) -> bool:
        try:
            compile(source, filename, "exec")
        except SyntaxError as error:
            message = f"{error.msg} (line {error.lineno})"
            messagebox.showerror(
                self._t(error_title_key),
                message,
                parent=self.root,
            )
            self._write_output(f"{self._t(error_title_key)}: {message}")
            return False
        return True

    def load_js_plugin(self) -> None:
        plugin_path = filedialog.askopenfilename(
            parent=self.root,
            title=self._t("load_js_plugin"),
            filetypes=[
                (self._t("plugin_filetypes"), "*.js *.py"),
                (self._t("all_files"), "*.*"),
            ],
        )
        if not plugin_path:
            return

        path = Path(plugin_path)
        syntax = self._plugin_syntax_for_path(path)
        if syntax is None:
            messagebox.showerror(
                self._t("plugin_load_failed"),
                self._t("plugin_invalid_extension"),
                parent=self.root,
            )
            return
        name = path.stem
        if not re.fullmatch(r"[A-Za-z0-9_]+", name):
            messagebox.showerror(
                self._t("plugin_load_failed"),
                self._t("plugin_invalid_name", name=name),
                parent=self.root,
            )
            return
        if not self._confirm_plugin_load(
            name,
            name in self.loaded_js_plugins,
        ):
            return

        source = self._read_plugin_source(path)
        if source is None:
            return
        if syntax == "PY" and not self._validate_python_plugin(
            source,
            str(path),
        ):
            return

        self.loaded_js_plugins[name] = source
        self.loaded_plugin_syntaxes[name] = syntax
        self._refresh_plugin_menu()
        self._write_output(self._t("plugin_loaded", name=name))

    def load_input_plugin(self) -> None:
        plugin_path = filedialog.askopenfilename(
            parent=self.root,
            title=self._t("load_input_plugin"),
            filetypes=[
                (self._t("plugin_filetypes"), "*.js *.py"),
                (self._t("all_files"), "*.*"),
            ],
        )
        if not plugin_path:
            return

        path = Path(plugin_path)
        syntax = self._plugin_syntax_for_path(path)
        if syntax is None:
            messagebox.showerror(
                self._t("plugin_load_failed"),
                self._t("plugin_invalid_extension"),
                parent=self.root,
            )
            return
        name = path.stem
        if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
            messagebox.showerror(
                self._t("plugin_load_failed"),
                self._t("plugin_invalid_input_name", name=name),
                parent=self.root,
            )
            return
        if not self._confirm_plugin_load(
            name,
            name in self.loaded_input_plugins,
        ):
            return

        source = self._read_plugin_source(path)
        if source is None:
            return
        if syntax == "PY" and not self._validate_python_plugin(
            source,
            str(path),
        ):
            return
        self._close_input_plugin(name)
        self.loaded_input_plugins[name] = source
        self.loaded_input_plugin_syntaxes[name] = syntax
        self._refresh_plugin_menu()
        self._write_output(self._t("plugin_input_loaded", name=name))

    def load_output_plugin(self) -> None:
        plugin_path = filedialog.askopenfilename(
            parent=self.root,
            title=self._t("load_output_plugin"),
            filetypes=[
                (self._t("plugin_filetypes"), "*.js *.py"),
                (self._t("all_files"), "*.*"),
            ],
        )
        if not plugin_path:
            return

        path = Path(plugin_path)
        syntax = self._plugin_syntax_for_path(path)
        if syntax is None:
            messagebox.showerror(
                self._t("plugin_load_failed"),
                self._t("plugin_invalid_extension"),
                parent=self.root,
            )
            return
        name = path.stem
        if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
            messagebox.showerror(
                self._t("plugin_load_failed"),
                self._t("plugin_invalid_input_name", name=name),
                parent=self.root,
            )
            return
        if not self._confirm_plugin_load(
            name,
            self.output_plugin is not None,
        ):
            return

        source = self._read_plugin_source(path)
        if source is None:
            return
        if syntax == "PY" and not self._validate_python_plugin(
            source,
            str(path),
        ):
            return
        self.output_plugin = (name, source)
        self.output_plugin_syntax = syntax
        self._refresh_plugin_menu()
        self._write_output(self._t("plugin_output_loaded", name=name))

    def load_ssp_plugin(self) -> None:
        plugin_path = filedialog.askopenfilename(
            parent=self.root,
            title=self._t("load_ssp_plugin"),
            filetypes=[
                ("SWS plugin packages", "*.ssp"),
                (self._t("all_files"), "*.*"),
            ],
        )
        if not plugin_path:
            return

        path = Path(plugin_path)
        name = path.stem
        if path.suffix.lower() != ".ssp":
            messagebox.showerror(
                self._t("plugin_package_load_failed"),
                self._t("plugin_package_invalid_extension"),
                parent=self.root,
            )
            return
        if not re.fullmatch(r"[A-Za-z0-9_]+", name):
            messagebox.showerror(
                self._t("plugin_package_load_failed"),
                self._t("plugin_invalid_name", name=name),
                parent=self.root,
            )
            return

        overwrite = (
            name in self.loaded_js_plugins
            or name in self.loaded_input_plugins
            or self.output_plugin is not None
        )
        if not self._confirm_plugin_load(name, overwrite, package=True):
            return

        source = self._read_plugin_source(
            path,
            error_title_key="plugin_package_load_failed",
        )
        if source is None:
            return
        try:
            package = parse_ssp_package(source)
        except ValueError as error:
            message = str(error)
            messagebox.showerror(
                self._t("plugin_package_load_failed"),
                message,
                parent=self.root,
            )
            self._write_output(
                f'{self._t("plugin_package_load_failed")}: {message}'
            )
            return

        python_sections = (
            ("dataplugin", package.data_syntax, package.data_source, package.data_is_default),
            ("inputplugin", package.input_syntax, package.input_source, package.input_is_default),
            ("outputplugin", package.output_syntax, package.output_source, package.output_is_default),
        )
        for section_name, syntax, section_source, is_default in python_sections:
            if (
                syntax == "PY"
                and not is_default
                and not self._validate_python_plugin(
                    section_source,
                    f"{name}.{section_name}.py",
                    error_title_key="plugin_package_load_failed",
                )
            ):
                return

        self._close_input_plugin(name)
        self.loaded_js_plugins[name] = (
            "" if package.data_is_default else package.data_source
        )
        self.loaded_plugin_syntaxes[name] = package.data_syntax
        if package.input_is_default:
            self.loaded_input_plugins.pop(name, None)
            self.loaded_input_plugin_syntaxes.pop(name, None)
        else:
            self.loaded_input_plugins[name] = package.input_source
            self.loaded_input_plugin_syntaxes[name] = package.input_syntax
        self.output_plugin = (
            None
            if package.output_is_default
            else (name, package.output_source)
        )
        self.output_plugin_syntax = package.output_syntax
        self._refresh_plugin_menu()
        self._write_output(self._t("plugin_package_loaded", name=name))

    def reset_output_plugin(self) -> None:
        self.output_plugin = None
        self.output_plugin_syntax = "JS"
        self._refresh_plugin_menu()
        self._write_output(self._t("plugin_output_reset"))

    def _confirm_plugin_load(
        self,
        name: str,
        overwrite: bool,
        *,
        package: bool = False,
    ) -> bool:
        title_key = (
            "plugin_package_trust_title" if package else "plugin_trust_title"
        )
        prompt_key = (
            "plugin_package_trust_prompt" if package else "plugin_trust_prompt"
        )
        if not messagebox.askyesno(
            self._t(title_key),
            self._t(prompt_key, name=name),
            parent=self.root,
            icon="warning",
        ):
            return False
        return not overwrite or messagebox.askyesno(
            self._t(title_key),
            self._t("plugin_overwrite_prompt", name=name),
            parent=self.root,
        )

    def _read_plugin_source(
        self,
        path: Path,
        *,
        error_title_key: str = "plugin_load_failed",
    ) -> str | None:
        try:
            return path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError) as error:
            message = str(error)
            messagebox.showerror(
                self._t(error_title_key),
                message,
                parent=self.root,
            )
            self._write_output(f'{self._t(error_title_key)}: {message}')
            return None

    def _refresh_plugin_menu(self) -> None:
        if not hasattr(self, "plugin_menu"):
            return
        last_entry = self.plugin_menu.index(tk.END)
        if last_entry is not None and last_entry >= 6:
            self.plugin_menu.delete(6, last_entry)
        for name in sorted(self.loaded_js_plugins):
            self.plugin_menu.add_command(
                label=(
                    f"Data: {name} "
                    f"({self.loaded_plugin_syntaxes.get(name, 'JS')})"
                ),
                state=tk.DISABLED,
            )
        for name in sorted(self.loaded_input_plugins):
            self.plugin_menu.add_command(
                label=self._t("input_plugin_open", name=name),
                command=lambda plugin_name=name: self.open_input_plugin(
                    plugin_name
                ),
            )
        if self.output_plugin is not None:
            self.plugin_menu.add_command(
                label=(
                    f"Output: {self.output_plugin[0]} "
                    f"({self.output_plugin_syntax})"
                ),
                state=tk.DISABLED,
            )

    def open_input_plugin(self, name: str) -> None:
        existing = self.input_plugin_views.get(name)
        if existing is not None and existing.window.winfo_exists():
            existing.window.deiconify()
            existing.window.lift()
            existing.window.focus_force()
            return

        source = self.loaded_input_plugins.get(name)
        if source is None:
            return

        window = tk.Toplevel(self.root)
        window.title(self._t("input_plugin_open", name=name))
        window.geometry("440x320")
        window.minsize(280, 180)
        window.transient(self.root)
        content = ttk.Frame(window, padding=12)
        content.pack(fill=tk.BOTH, expand=True)
        status = ttk.Label(content, text=self._t("plugin_window_loading"))
        status.pack(side=tk.BOTTOM, fill=tk.X, pady=(8, 0))
        plugin_area = ttk.Frame(content)
        plugin_area.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        if self.loaded_input_plugin_syntaxes.get(name, "JS") == "PY":
            view = PythonInputPluginView(name, window, status)
            self.input_plugin_views[name] = view
            window.protocol(
                "WM_DELETE_WINDOW",
                lambda plugin_name=name: self._close_input_plugin(plugin_name),
            )
            namespace: dict[str, object] = {
                "__name__": f"sws_input_plugin_{name}",
                "__file__": f"{name}.py",
            }
            try:
                exec(
                    compile(source, f"{name}.py", "exec"),
                    namespace,
                    namespace,
                )
                mount = namespace.get("mount")
                if not callable(mount):
                    raise TypeError(
                        "input plugin must define mount(parent, editor)"
                    )
                cleanup = mount(plugin_area, PythonInputPluginEditor(self))
                if cleanup is not None and not callable(cleanup):
                    raise TypeError("input plugin mount() must return a cleanup function or None")
                view.cleanup = cleanup
                display_name = namespace.get("name")
                if isinstance(display_name, str) and display_name.strip():
                    window.title(display_name.strip())
                status.configure(text="")
            except Exception as error:
                message = str(error) or type(error).__name__
                status.configure(
                    text=self._t("plugin_window_failed", message=message)
                )
                self._write_output(
                    self._t("plugin_window_failed", message=message)
                )
            return

        session = JavaScriptInputSession(
            name,
            source,
            self._input_plugin_editor_state(),
        )
        view = InputPluginView(name, window, plugin_area, status, session)
        self.input_plugin_views[name] = view
        window.protocol(
            "WM_DELETE_WINDOW",
            lambda plugin_name=name: self._close_input_plugin(plugin_name),
        )
        self.root.after(25, lambda plugin_name=name: self._poll_input_plugin(plugin_name))

    def _close_input_plugin(self, name: str) -> None:
        view = self.input_plugin_views.pop(name, None)
        if view is None:
            return
        if isinstance(view, PythonInputPluginView):
            if view.cleanup is not None:
                try:
                    view.cleanup()
                except Exception as error:
                    self._write_output(
                        self._t(
                            "plugin_window_failed",
                            message=str(error) or type(error).__name__,
                        )
                    )
        else:
            view.session.close()
        if view.window.winfo_exists():
            view.window.destroy()

    def _poll_input_plugin(self, name: str) -> None:
        view = self.input_plugin_views.get(name)
        if (
            view is None
            or isinstance(view, PythonInputPluginView)
            or not view.window.winfo_exists()
        ):
            return

        responses: list[dict[str, object]] = []
        while True:
            try:
                responses.append(view.session.responses.get_nowait())
            except Empty:
                break

        for response in responses:
            response_type = response.get("type")
            if response_type == "error":
                message = str(response.get("message", "Unknown input plugin error"))
                view.status.configure(
                    text=self._t("plugin_window_failed", message=message)
                )
                self._write_output(
                    self._t("plugin_window_failed", message=message)
                )
                view.session.close()
                return
            if response_type not in {"ready", "update"}:
                continue
            try:
                operations = response.get("operations", [])
                tree = response.get("tree")
                if not isinstance(tree, dict):
                    raise ValueError("input plugin returned an invalid UI tree")
                self._apply_input_plugin_operations(operations)
                if tree != view.tree:
                    self._render_input_plugin_tree(view, tree)
                    view.tree = tree
                if response_type == "ready":
                    display_name = response.get("displayName")
                    if isinstance(display_name, str) and display_name:
                        view.window.title(display_name)
                    view.status.configure(text="")
            except (KeyError, TypeError, ValueError, tk.TclError) as error:
                message = str(error)
                view.status.configure(
                    text=self._t("plugin_window_failed", message=message)
                )
                self._write_output(
                    self._t("plugin_window_failed", message=message)
                )
                view.session.close()
                return

        self.root.after(25, lambda plugin_name=name: self._poll_input_plugin(plugin_name))

    def _input_plugin_editor_state(self) -> dict[str, object]:
        source = self.editor.get("1.0", "end-1c")
        selection = self.editor.tag_ranges(tk.SEL)
        if len(selection) >= 2:
            start_index, end_index = selection[:2]
        else:
            start_index = end_index = self.editor.index(tk.INSERT)
        start = self._tk_index_to_js_offset(str(start_index))
        end = self._tk_index_to_js_offset(str(end_index))
        return {
            "text": source,
            "selection": {"start": start, "end": end},
        }

    def _tk_index_to_js_offset(self, index: str) -> int:
        prefix = self.editor.get("1.0", index)
        return len(prefix.encode("utf-16-le")) // 2

    def _js_offset_to_tk_index(self, source: str, offset: object) -> str:
        if not isinstance(offset, int) or isinstance(offset, bool) or offset < 0:
            raise ValueError("input plugin returned an invalid editor offset")
        utf16_offset = 0
        character_offset = 0
        for character in source:
            if utf16_offset == offset:
                break
            utf16_offset += 2 if ord(character) > 0xFFFF else 1
            character_offset += 1
            if utf16_offset > offset:
                raise ValueError("editor offset splits a UTF-16 surrogate pair")
        if utf16_offset != offset:
            if utf16_offset > offset:
                raise ValueError("editor offset splits a UTF-16 surrogate pair")
            if offset > utf16_offset:
                raise ValueError("input plugin returned an out-of-range editor offset")
        return self.editor.index(f"1.0 + {character_offset} chars")

    def _apply_input_plugin_operations(self, operations: object) -> None:
        if not isinstance(operations, list):
            raise ValueError("input plugin returned invalid editor operations")
        if operations:
            self.editor.edit_separator()
        for operation in operations:
            if not isinstance(operation, dict):
                raise ValueError("input plugin returned an invalid editor operation")
            op = operation.get("op")
            source = self.editor.get("1.0", "end-1c")
            if op == "replaceRange":
                start = self._js_offset_to_tk_index(
                    source,
                    operation.get("start"),
                )
                end = self._js_offset_to_tk_index(
                    source,
                    operation.get("end"),
                )
                text = operation.get("text")
                if not isinstance(text, str):
                    raise ValueError("input plugin editor text must be a string")
                self.editor.replace(start, end, text)
                self.editor.mark_set(
                    tk.INSERT,
                    self.editor.index(f"{start} + {len(text)} chars"),
                )
            elif op == "setSelection":
                start = self._js_offset_to_tk_index(
                    source,
                    operation.get("start"),
                )
                end = self._js_offset_to_tk_index(
                    source,
                    operation.get("end"),
                )
                self.editor.tag_remove(tk.SEL, "1.0", tk.END)
                if self.editor.compare(start, "<", end):
                    self.editor.tag_add(tk.SEL, start, end)
                self.editor.mark_set(tk.INSERT, end)
            else:
                raise ValueError(f"unsupported input plugin editor operation: {op}")
        if operations:
            self.editor.edit_separator()
            self._capture_active_track()
            self._update_edit_menu_state()
            self._update_title()
            self._update_cursor_status()

    def _render_input_plugin_tree(
        self,
        view: InputPluginView,
        tree: dict[str, object],
    ) -> None:
        for child in view.content.winfo_children():
            child.destroy()
        view.widgets.clear()
        view.variables.clear()
        children = tree.get("children", [])
        if not isinstance(children, list):
            raise ValueError("input plugin returned invalid UI children")
        for child in children:
            if not isinstance(child, dict):
                raise ValueError("input plugin returned an invalid UI element")
            self._render_input_plugin_node(view, view.content, child)

    def _render_input_plugin_node(
        self,
        view: InputPluginView,
        parent: tk.Misc,
        node: dict[str, object],
    ) -> None:
        tag_name = node.get("tagName")
        node_id = node.get("id")
        if not isinstance(tag_name, str):
            raise ValueError("input plugin UI element has no tag name")
        if not isinstance(node_id, int) or isinstance(node_id, bool):
            raise ValueError("input plugin UI element has an invalid ID")

        tag = tag_name.lower()
        text = node.get("textContent", "")
        label = text if isinstance(text, str) else str(text)
        value = node.get("value", "")
        value_text = value if isinstance(value, str) else str(value)
        disabled = bool(node.get("disabled", False))
        events_value = node.get("events", [])
        if not isinstance(events_value, list):
            raise ValueError("input plugin UI element has invalid event handlers")
        events = {event for event in events_value if isinstance(event, str)}
        children_value = node.get("children", [])
        if not isinstance(children_value, list):
            raise ValueError("input plugin UI element has invalid children")
        children = [
            child for child in children_value if isinstance(child, dict)
        ]
        if len(children) != len(children_value):
            raise ValueError("input plugin returned an invalid child element")

        if tag == "button" or (tag == "input" and node.get("type") in {"button", "submit"}):
            widget = ttk.Button(
                parent,
                text=label or "Button",
                state=tk.DISABLED if disabled else tk.NORMAL,
                command=lambda element_id=node_id: self._dispatch_input_plugin_event(
                    view.name,
                    element_id,
                    "click",
                ),
            )
            widget.pack(anchor=tk.W, fill=tk.X, pady=3)
            view.widgets[node_id] = widget
            return

        if tag == "input" and node.get("type") == "checkbox":
            variable = tk.BooleanVar(
                master=view.window,
                value=bool(node.get("checked", False)),
            )
            widget = ttk.Checkbutton(
                parent,
                text=label,
                variable=variable,
                state=tk.DISABLED if disabled else tk.NORMAL,
                command=lambda element_id=node_id, selected=variable: self._dispatch_input_plugin_event(
                    view.name,
                    element_id,
                    "change" if "change" in events else "click",
                    checked=bool(selected.get()),
                ),
            )
            widget.pack(anchor=tk.W, pady=3)
            view.widgets[node_id] = widget
            view.variables[node_id] = variable
            return

        if tag == "input" or tag == "textarea":
            variable = tk.StringVar(master=view.window, value=value_text)
            if tag == "textarea":
                widget = tk.Text(parent, height=5, wrap=tk.WORD)
                widget.insert("1.0", value_text)
                if disabled:
                    widget.configure(state=tk.DISABLED)
                if "input" in events:
                    widget.bind(
                        "<KeyRelease>",
                        lambda _event, element_id=node_id, target=widget: self._dispatch_input_plugin_event(
                            view.name,
                            element_id,
                            "input",
                            value=target.get("1.0", "end-1c"),
                        ),
                    )
                if "change" in events:
                    widget.bind(
                        "<FocusOut>",
                        lambda _event, element_id=node_id, target=widget: self._dispatch_input_plugin_event(
                            view.name,
                            element_id,
                            "change",
                            value=target.get("1.0", "end-1c"),
                        ),
                    )
            else:
                widget = ttk.Entry(
                    parent,
                    textvariable=variable,
                    state=tk.DISABLED if disabled else tk.NORMAL,
                )
                placeholder = node.get("placeholder")
                if isinstance(placeholder, str) and placeholder:
                    widget.configure(width=max(20, min(60, len(placeholder) + 4)))
                if "input" in events:
                    widget.bind(
                        "<KeyRelease>",
                        lambda _event, element_id=node_id, target=variable: self._dispatch_input_plugin_event(
                            view.name,
                            element_id,
                            "input",
                            value=str(target.get()),
                        ),
                    )
                if "change" in events:
                    widget.bind(
                        "<FocusOut>",
                        lambda _event, element_id=node_id, target=variable: self._dispatch_input_plugin_event(
                            view.name,
                            element_id,
                            "change",
                            value=str(target.get()),
                        ),
                    )
            widget.pack(anchor=tk.W, fill=tk.X, pady=3)
            view.widgets[node_id] = widget
            view.variables[node_id] = variable
            return

        if tag == "select":
            options = [
                str(child.get("value") or child.get("textContent") or "")
                for child in children
                if child.get("tagName") == "option"
            ]
            variable = tk.StringVar(master=view.window, value=value_text)
            widget = ttk.Combobox(
                parent,
                textvariable=variable,
                values=options,
                state="disabled" if disabled else "readonly",
            )
            if not value_text and options:
                variable.set(options[0])
            if "change" in events:
                widget.bind(
                    "<<ComboboxSelected>>",
                    lambda _event, element_id=node_id, target=variable: self._dispatch_input_plugin_event(
                        view.name,
                        element_id,
                        "change",
                        value=str(target.get()),
                    ),
                )
            widget.pack(anchor=tk.W, fill=tk.X, pady=3)
            view.widgets[node_id] = widget
            view.variables[node_id] = variable
            return

        if tag in {"#text", "span", "p", "h1", "h2", "h3", "h4"}:
            if label:
                widget = ttk.Label(parent, text=label)
                widget.pack(anchor=tk.W, pady=2)
                view.widgets[node_id] = widget
            for child in children:
                self._render_input_plugin_node(view, parent, child)
            return

        if tag == "hr":
            widget = ttk.Separator(parent, orient=tk.HORIZONTAL)
            widget.pack(fill=tk.X, pady=5)
            view.widgets[node_id] = widget
            return

        container = ttk.Frame(parent)
        container.pack(anchor=tk.W, fill=tk.X, pady=2)
        view.widgets[node_id] = container
        if label:
            ttk.Label(container, text=label).pack(anchor=tk.W)
        for child in children:
            self._render_input_plugin_node(view, container, child)

    def _dispatch_input_plugin_event(
        self,
        plugin_name: str,
        element_id: int,
        event_type: str,
        value: str | None = None,
        checked: bool | None = None,
    ) -> None:
        view = self.input_plugin_views.get(plugin_name)
        if view is None or isinstance(view, PythonInputPluginView):
            return
        try:
            view.session.dispatch(
                element_id,
                event_type,
                self._input_plugin_editor_state(),
                value=value,
                checked=checked,
            )
        except (OSError, RuntimeError, tk.TclError) as error:
            message = str(error)
            view.status.configure(
                text=self._t("plugin_window_failed", message=message)
            )
            self._write_output(self._t("plugin_window_failed", message=message))
            view.session.close()

    def _load_settings(self) -> str | None:
        try:
            saved = json.loads(self.settings_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            self.settings = DEFAULT_SETTINGS.copy()
            return None
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            return self._t(
                "settings_load_failed", path=self.settings_path, message=error
            )
        if not isinstance(saved, dict):
            self.settings = DEFAULT_SETTINGS.copy()
            return self._t("settings_invalid", path=self.settings_path)

        settings = DEFAULT_SETTINGS.copy()
        warnings = []
        font_size = saved.get("editorFontSize", saved.get("font_size", settings["editorFontSize"]))
        if type(font_size) is int and 12 <= font_size <= 24:
            settings["editorFontSize"] = font_size
        else:
            warnings.append("editor font size")

        for key in (
            "editorWrap",
            "autoIndent",
            "showLineNumbers",
            "autoSaveDraft",
            "warnUnsaved",
            "mixedFunctionTracksToGlobal",
            "useUtauToolsForPlayback",
        ):
            value = saved.get(key, settings[key])
            if type(value) is bool:
                settings[key] = value
            else:
                warnings.append(key)

        for key in (
            "utauWavtoolPath",
            "utauResamplerPath",
            "utauResamplerFlags",
        ):
            value = saved.get(key, settings[key])
            if isinstance(value, str):
                settings[key] = value
            else:
                warnings.append(key)

        master_volume = saved.get("masterVolume", settings["masterVolume"])
        if type(master_volume) is int and 0 <= master_volume <= 100:
            settings["masterVolume"] = master_volume
        else:
            warnings.append("master volume")

        language = saved.get("language", settings["language"])
        if isinstance(language, str) and language in LANGUAGE_NAMES:
            settings["language"] = language
        else:
            warnings.append("language")

        theme = saved.get("theme", settings["theme"])
        if isinstance(theme, str) and theme in THEMES:
            settings["theme"] = theme
        else:
            warnings.append("theme")

        syntax_preset = saved.get("syntaxPreset", settings["syntaxPreset"])
        if syntax_preset == "highContrast":
            syntax_preset = "primary"
        if isinstance(syntax_preset, str) and syntax_preset in SYNTAX_PRESETS:
            settings["syntaxPreset"] = syntax_preset
        else:
            warnings.append("syntax color preset")

        self.settings = settings
        self.language = settings["language"]
        self.font_size = settings["editorFontSize"]
        if warnings:
            return self._t(
                "settings_fallback",
                items=", ".join(warnings),
                path=self.settings_path,
            )
        return None

    def open_settings(self) -> None:
        if self.settings_dialog is not None and self.settings_dialog.winfo_exists():
            self.settings_dialog.focus_set()
            return

        dialog = tk.Toplevel(self.root)
        self.settings_dialog = dialog
        dialog.title(self._t("settings_title"))
        dialog.transient(self.root)
        dialog.resizable(True, True)
        width = max(480, min(720, dialog.winfo_screenwidth() - 80))
        height = max(400, min(720, dialog.winfo_screenheight() - 100))
        dialog.geometry(f"{width}x{height}")
        dialog.minsize(min(520, width), min(420, height))
        dialog.configure(background=self.theme_colors["background"])

        container = ttk.Frame(dialog, padding=12)
        container.pack(fill=tk.BOTH, expand=True)
        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)

        settings_frame = ttk.Frame(container)
        settings_frame.grid(row=0, column=0, sticky=tk.NSEW)
        settings_frame.rowconfigure(0, weight=1)
        settings_frame.columnconfigure(0, weight=1)

        canvas = tk.Canvas(
            settings_frame,
            background=self.theme_colors["background"],
            borderwidth=0,
            highlightthickness=0,
        )
        canvas.grid(row=0, column=0, sticky=tk.NSEW)
        scrollbar = ttk.Scrollbar(
            settings_frame,
            orient=tk.VERTICAL,
            command=canvas.yview,
        )
        scrollbar.grid(row=0, column=1, sticky=tk.NS)
        canvas.configure(yscrollcommand=scrollbar.set)

        content = ttk.Frame(canvas, padding=18)
        content_window = canvas.create_window(
            (0, 0),
            window=content,
            anchor=tk.NW,
        )
        content.columnconfigure(0, weight=1)
        content.columnconfigure(1, weight=2)
        content.bind(
            "<Configure>",
            lambda _event: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.bind(
            "<Configure>",
            lambda event: canvas.itemconfigure(
                content_window,
                width=event.width,
            ),
        )

        def scroll_settings(event: tk.Event) -> str:
            button = getattr(event, "num", None)
            if button == 4:
                canvas.yview_scroll(-1, "units")
            elif button == 5:
                canvas.yview_scroll(1, "units")
            else:
                canvas.yview_scroll(-int(event.delta / 120), "units")
            return "break"

        dialog.bind("<MouseWheel>", scroll_settings)
        dialog.bind("<Button-4>", scroll_settings)
        dialog.bind("<Button-5>", scroll_settings)

        ttk.Label(content, text=self._t("editor"), style="Title.TLabel").grid(
            row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 10)
        )
        ttk.Label(content, text=self._t("language")).grid(
            row=1, column=0, sticky=tk.W, pady=4
        )
        language = tk.StringVar(value=LANGUAGE_NAMES[self.settings["language"]])
        ttk.Combobox(
            content,
            textvariable=language,
            values=tuple(LANGUAGE_NAMES.values()),
            state="readonly",
            width=28,
        ).grid(row=1, column=1, sticky=tk.EW, pady=4)

        ttk.Label(content, text=self._t("font_size")).grid(
            row=2, column=0, sticky=tk.W, pady=4
        )
        size = tk.StringVar(value=str(self.settings["editorFontSize"]))
        ttk.Spinbox(
            content,
            from_=12,
            to=24,
            increment=1,
            textvariable=size,
            width=6,
        ).grid(row=2, column=1, sticky=tk.EW, padx=(24, 0), pady=4)

        ttk.Label(content, text=self._t("theme")).grid(
            row=3, column=0, sticky=tk.W, pady=4
        )
        theme_names = {"dark": self._t("dark"), "light": self._t("light")}
        theme = tk.StringVar(value=theme_names[self.settings["theme"]])
        ttk.Combobox(
            content,
            textvariable=theme,
            values=tuple(theme_names.values()),
            state="readonly",
            width=28,
        ).grid(row=3, column=1, sticky=tk.EW, pady=4)

        ttk.Label(content, text=self._t("syntax_preset")).grid(
            row=4, column=0, sticky=tk.W, pady=4
        )
        preset_names = {
            name: self._t(f"preset_{name}") for name in SYNTAX_PRESETS
        }
        preset = tk.StringVar(
            value=preset_names[self.settings["syntaxPreset"]]
        )
        ttk.Combobox(
            content,
            textvariable=preset,
            values=tuple(preset_names.values()),
            state="readonly",
            width=28,
        ).grid(row=4, column=1, sticky=tk.EW, pady=4)

        ttk.Label(content, text=self._t("master_volume")).grid(
            row=5, column=0, sticky=tk.W, pady=4
        )
        master_volume = tk.DoubleVar(value=self.settings["masterVolume"])
        volume_display = tk.StringVar(value=f"{self.settings['masterVolume']}%")
        volume_controls = ttk.Frame(content)
        volume_controls.grid(row=5, column=1, sticky=tk.EW, pady=4)
        ttk.Scale(
            volume_controls,
            from_=0,
            to=100,
            variable=master_volume,
            command=lambda value: volume_display.set(f"{round(float(value))}%"),
            length=170,
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        ttk.Label(volume_controls, textvariable=volume_display, width=5).pack(
            side=tk.LEFT
        )

        wrap = tk.BooleanVar(value=self.settings["editorWrap"])
        auto_indent = tk.BooleanVar(value=self.settings["autoIndent"])
        line_numbers = tk.BooleanVar(value=self.settings["showLineNumbers"])
        auto_save = tk.BooleanVar(value=self.settings["autoSaveDraft"])
        warn_unsaved = tk.BooleanVar(value=self.settings["warnUnsaved"])
        mixed_functions_global = tk.BooleanVar(
            value=self.settings["mixedFunctionTracksToGlobal"]
        )
        checkboxes = (
            (6, "wrap", wrap),
            (7, "auto_indent", auto_indent),
            (8, "line_numbers", line_numbers),
            (9, "auto_save", auto_save),
            (10, "warn_unsaved", warn_unsaved),
            (11, "mixed_function_tracks_global", mixed_functions_global),
        )
        for row, key, variable in checkboxes:
            ttk.Checkbutton(content, text=self._t(key), variable=variable).grid(
                row=row, column=0, columnspan=2, sticky=tk.W, pady=3
            )

        ttk.Label(content, text=self._t("playback"), style="Title.TLabel").grid(
            row=13, column=0, columnspan=2, sticky=tk.W, pady=(12, 6)
        )
        use_utau_tools = tk.BooleanVar(
            value=self.settings["useUtauToolsForPlayback"]
        )
        ttk.Checkbutton(
            content,
            text=self._t("use_utau_tools"),
            variable=use_utau_tools,
        ).grid(row=14, column=0, columnspan=2, sticky=tk.W, pady=3)

        wavtool_path = tk.StringVar(value=self.settings["utauWavtoolPath"])
        resampler_path = tk.StringVar(
            value=self.settings["utauResamplerPath"]
        )
        resampler_flags = tk.StringVar(
            value=self.settings["utauResamplerFlags"]
        )

        def choose_utau_tool(variable: tk.StringVar) -> None:
            path = filedialog.askopenfilename(
                parent=dialog,
                title=self._t("select_utau_tool"),
                filetypes=(
                    ("Executable files", "*.exe"),
                    (self._t("all_files"), "*.*"),
                ),
            )
            if path:
                variable.set(path)

        for row, label_key, variable in (
            (15, "wavtool_path", wavtool_path),
            (16, "resampler_path", resampler_path),
        ):
            ttk.Label(content, text=self._t(label_key)).grid(
                row=row, column=0, sticky=tk.W, pady=4
            )
            tool_controls = ttk.Frame(content)
            tool_controls.grid(row=row, column=1, sticky=tk.EW, pady=4)
            ttk.Entry(
                tool_controls,
                textvariable=variable,
                width=38,
            ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
            ttk.Button(
                tool_controls,
                text=self._t("browse"),
                command=lambda selected=variable: choose_utau_tool(selected),
            ).pack(side=tk.RIGHT)

        ttk.Label(content, text=self._t("resampler_flags")).grid(
            row=17, column=0, sticky=tk.W, pady=4
        )
        ttk.Entry(
            content,
            textvariable=resampler_flags,
        ).grid(row=17, column=1, sticky=tk.EW, pady=4)

        self.utau_voicebank_info_button = ttk.Button(
            content,
            text=self._t("voicebank_info"),
            command=lambda: self.open_utau_voicebank_info(dialog),
            state=tk.NORMAL if self.utau_voicebank is not None else tk.DISABLED,
        )
        self.utau_voicebank_info_button.grid(
            row=18,
            column=0,
            columnspan=2,
            sticky=tk.W,
            pady=(8, 4),
        )

        ttk.Label(
            content,
            text=self._t("utau_playback_setup_note"),
            style="Muted.TLabel",
            wraplength=440,
        ).grid(row=19, column=0, columnspan=2, sticky=tk.W, pady=(4, 10))

        ttk.Label(
            content,
            text=self._t("shortcuts"),
            style="Muted.TLabel",
            wraplength=420,
        ).grid(row=12, column=0, columnspan=2, sticky=tk.W, pady=(8, 12))

        buttons = ttk.Frame(container)
        buttons.grid(row=1, column=0, sticky=tk.E, pady=(8, 0))
        ttk.Button(
            buttons,
            text=self._t("cancel"),
            command=lambda: self._close_settings(dialog),
        ).pack(side=tk.RIGHT, padx=(6, 0))
        ttk.Button(
            buttons,
            text=self._t("apply"),
            style="Accent.TButton",
            command=lambda: self._apply_settings(
                dialog,
                {
                    "editorFontSize": size,
                    "language": language,
                    "masterVolume": master_volume,
                    "theme": theme,
                    "syntaxPreset": preset,
                    "editorWrap": wrap,
                    "autoIndent": auto_indent,
                    "showLineNumbers": line_numbers,
                    "autoSaveDraft": auto_save,
                    "warnUnsaved": warn_unsaved,
                    "mixedFunctionTracksToGlobal": mixed_functions_global,
                    "useUtauToolsForPlayback": use_utau_tools,
                    "utauWavtoolPath": wavtool_path,
                    "utauResamplerPath": resampler_path,
                    "utauResamplerFlags": resampler_flags,
                },
            ),
        ).pack(side=tk.RIGHT)

        dialog.protocol("WM_DELETE_WINDOW", lambda: self._close_settings(dialog))
        dialog.bind("<Escape>", lambda _event: self._close_settings(dialog))
        dialog.grab_set()
        dialog.focus_set()

    def _close_settings(self, dialog: tk.Toplevel) -> None:
        if self.settings_dialog is dialog:
            self.settings_dialog = None
            self.utau_voicebank_info_button = None
        dialog.destroy()

    def _apply_settings(
        self,
        dialog: tk.Toplevel,
        variables: dict[str, tk.Variable],
    ) -> None:
        try:
            font_size = int(variables["editorFontSize"].get())
        except ValueError:
            messagebox.showerror(
                self._t("invalid_setting"),
                self._t("invalid_font"),
                parent=dialog,
            )
            return
        if not 12 <= font_size <= 24:
            messagebox.showerror(
                self._t("invalid_setting"),
                self._t("invalid_font"),
                parent=dialog,
            )
            return

        try:
            volume_value = float(variables["masterVolume"].get())
        except (TypeError, ValueError, tk.TclError):
            messagebox.showerror(
                self._t("invalid_setting"),
                self._t("invalid_master_volume"),
                parent=dialog,
            )
            return
        if not 0 <= volume_value <= 100:
            messagebox.showerror(
                self._t("invalid_setting"),
                self._t("invalid_master_volume"),
                parent=dialog,
            )
            return
        master_volume = round(volume_value)

        selected_language = next(
            (
                code
                for code, name in LANGUAGE_NAMES.items()
                if name == str(variables["language"].get())
            ),
            None,
        )
        selected_theme = next(
            (
                name
                for name in THEMES
                if self._t(name) == str(variables["theme"].get())
            ),
            None,
        )
        selected_preset = next(
            (
                name
                for name in SYNTAX_PRESETS
                if self._t(f"preset_{name}")
                == str(variables["syntaxPreset"].get())
            ),
            None,
        )
        if (
            selected_language not in LANGUAGE_NAMES
            or selected_theme not in THEMES
            or selected_preset not in SYNTAX_PRESETS
        ):
            messagebox.showerror(
                self._t("invalid_setting"),
                self._t("invalid_options"),
                parent=dialog,
            )
            return

        settings = {
            "editorFontSize": font_size,
            "masterVolume": master_volume,
            "editorWrap": bool(variables["editorWrap"].get()),
            "autoIndent": bool(variables["autoIndent"].get()),
            "showLineNumbers": bool(variables["showLineNumbers"].get()),
            "autoSaveDraft": bool(variables["autoSaveDraft"].get()),
            "warnUnsaved": bool(variables["warnUnsaved"].get()),
            "mixedFunctionTracksToGlobal": bool(
                variables["mixedFunctionTracksToGlobal"].get()
            ),
            "useUtauToolsForPlayback": bool(
                variables["useUtauToolsForPlayback"].get()
            ),
            "utauWavtoolPath": str(variables["utauWavtoolPath"].get()),
            "utauResamplerPath": str(
                variables["utauResamplerPath"].get()
            ),
            "utauResamplerFlags": str(
                variables["utauResamplerFlags"].get()
            ),
            "language": selected_language,
            "theme": selected_theme,
            "syntaxPreset": selected_preset,
        }
        try:
            self.settings_path.parent.mkdir(parents=True, exist_ok=True)
            self.settings_path.write_text(
                json.dumps(settings, indent=2),
                encoding="utf-8",
            )
        except OSError as error:
            messagebox.showerror(
                self._t("settings_save_failed"),
                str(error),
                parent=dialog,
            )
            return

        auto_save_was_enabled = self.settings["autoSaveDraft"]
        mixed_functions_were_global = self.settings[
            "mixedFunctionTracksToGlobal"
        ]
        self.settings = settings
        self.language = selected_language
        self.font_size = font_size
        self.theme_colors = THEMES[self.settings["theme"]]
        self._apply_editor_preferences()
        self._apply_locale()
        if (
            mixed_functions_were_global
            != self.settings["mixedFunctionTracksToGlobal"]
        ):
            previous_track = self.active_track
            self._synchronize_track_source()
            if previous_track in self.track_buffers:
                self.active_track = previous_track
            else:
                self.active_track = next(
                    (name for name in self.track_buffers if name is not None),
                    None,
                )
            self._show_active_track()
        if auto_save_was_enabled and not self.settings["autoSaveDraft"]:
            self._cancel_draft_save()
            self._clear_draft()
        elif self.settings["autoSaveDraft"] and self.modified:
            self._schedule_draft_save()
        self.document_status.set(self._t("settings_saved"))
        self._write_output(self._t("settings_saved"))
        self._close_settings(dialog)

    def _schedule_draft_save(self) -> None:
        if not self.settings["autoSaveDraft"] or not self.modified:
            return
        self._cancel_draft_save()
        self._draft_after_id = self.root.after(500, self._save_draft)

    def _cancel_draft_save(self) -> None:
        if self._draft_after_id is not None:
            self.root.after_cancel(self._draft_after_id)
            self._draft_after_id = None

    def _save_draft(self) -> None:
        self._draft_after_id = None
        if not self.settings["autoSaveDraft"] or not self.modified:
            return
        source = self._document_source()
        if not source:
            self._clear_draft()
            return
        draft = {
            "source": source,
            "path": str(self.current_path) if self.current_path else None,
        }
        try:
            self.draft_path.parent.mkdir(parents=True, exist_ok=True)
            self.draft_path.write_text(
                json.dumps(draft, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError as error:
            self._write_output(self._t("draft_save_failed", message=error))

    def _clear_draft(self) -> None:
        try:
            self.draft_path.unlink(missing_ok=True)
        except OSError as error:
            self._write_output(self._t("draft_clear_failed", message=error))

    def _restore_draft(self) -> None:
        if not self.settings["autoSaveDraft"]:
            return
        try:
            draft = json.loads(self.draft_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            self._write_output(self._t("draft_read_failed", message=error))
            self._clear_draft()
            return

        if not isinstance(draft, dict) or not isinstance(draft.get("source"), str):
            self._write_output(self._t("draft_invalid"))
            self._clear_draft()
            return
        if not draft["source"]:
            self._clear_draft()
            return

        if not messagebox.askyesno(
            self._t("restore_title"),
            self._t("restore_prompt"),
            parent=self.root,
        ):
            self._clear_draft()
            return

        saved_path = draft.get("path")
        self.current_path = Path(saved_path) if isinstance(saved_path, str) else None
        self._set_source(draft["source"])
        self.modified = True
        self._update_title()
        self.document_status.set(self._t("draft_restored"))
        self._write_output(self._t("draft_restored"))
        self._schedule_draft_save()

    def _create_widgets(self) -> None:
        header = ttk.Frame(self.root, padding=(18, 12, 18, 10))
        header.pack(fill=tk.X)

        heading = ttk.Frame(header)
        heading.pack(side=tk.LEFT, fill=tk.Y)
        ttk.Label(heading, text="SWS STUDIO", style="Title.TLabel").pack(anchor=tk.W)
        self.subtitle_label = ttk.Label(
            heading,
            text=APP_NAME,
            style="Muted.TLabel",
        )
        self.subtitle_label.pack(anchor=tk.W, pady=(2, 0))

        toolbar = ttk.Frame(header)
        toolbar.pack(side=tk.RIGHT, fill=tk.Y, pady=4)
        self.file_button = ttk.Button(
            toolbar,
            text=self._t("file"),
            command=self._post_file_menu,
        )
        self.file_button.pack(side=tk.LEFT, padx=(0, 6))
        self.compile_button = ttk.Button(
            toolbar,
            text=self._t("compile"),
            style="Accent.TButton",
            command=self.compile_document,
        )
        self.compile_button.pack(side=tk.LEFT, padx=(6, 0))
        self.play_button = ttk.Button(
            toolbar,
            text=self._t("play"),
            command=self.play_document,
        )
        self.play_button.pack(side=tk.LEFT, padx=(6, 0))
        self.stop_button = ttk.Button(
            toolbar,
            text=self._t("stop"),
            command=self.stop_playback,
            state=tk.DISABLED,
        )
        self.stop_button.pack(side=tk.LEFT, padx=(6, 0))
        self.plugins_button = ttk.Button(
            toolbar,
            text=self._t("plugins_menu"),
            command=self._post_plugins_menu,
        )
        self.plugins_button.pack(side=tk.LEFT, padx=(12, 0))
        self.settings_button = ttk.Button(
            toolbar,
            text=self._t("settings"),
            command=self.open_settings,
        )
        self.settings_button.pack(side=tk.LEFT, padx=(6, 0))

        separator = ttk.Separator(self.root)
        separator.pack(fill=tk.X)

        content = ttk.Panedwindow(self.root, orient=tk.VERTICAL)
        content.pack(fill=tk.BOTH, expand=True, padx=14, pady=(12, 8))

        editor_panel = ttk.Frame(content, style="Panel.TFrame")
        editor_header = ttk.Frame(editor_panel, style="Panel.TFrame", padding=(10, 7))
        editor_header.pack(fill=tk.X)
        self.source_header_label = ttk.Label(
            editor_header,
            text=self._t("source"),
            style="Muted.TLabel",
        )
        self.source_header_label.pack(side=tk.LEFT)
        self.path_label = ttk.Label(
            editor_header,
            text="Untitled.ss",
            style="Muted.TLabel",
        )
        self.path_label.pack(side=tk.RIGHT)

        track_bar = ttk.Frame(editor_panel, style="Panel.TFrame", padding=(8, 0, 8, 6))
        track_bar.pack(fill=tk.X)
        self.track_tabs = ttk.Frame(track_bar, style="Panel.TFrame")
        self.track_tabs.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.add_track_button = ttk.Button(
            track_bar,
            text="+",
            width=3,
            command=self.add_track,
        )
        self.add_track_button.pack(side=tk.RIGHT, padx=(6, 0))

        editor_area = ttk.Frame(editor_panel, style="Panel.TFrame")
        editor_area.pack(fill=tk.BOTH, expand=True)
        colors = self.theme_colors
        self.line_numbers = tk.Text(
            editor_area,
            width=5,
            padx=10,
            pady=10,
            takefocus=False,
            state=tk.DISABLED,
            wrap=tk.NONE,
            background=colors["panel"],
            foreground=colors["muted"],
            insertbackground=colors["foreground"],
            font=("Consolas", self.font_size),
            borderwidth=0,
            highlightthickness=0,
            selectbackground=colors["panel"],
        )
        if self.settings["showLineNumbers"]:
            self.line_numbers.pack(side=tk.LEFT, fill=tk.Y)

        self.editor = tk.Text(
            editor_area,
            undo=True,
            maxundo=-1,
            wrap=tk.WORD if self.settings["editorWrap"] else tk.NONE,
            padx=8,
            pady=10,
            background=colors["editor"],
            foreground=colors["foreground"],
            insertbackground=colors["foreground"],
            selectbackground=colors["selection"],
            font=("Consolas", self.font_size),
            borderwidth=0,
            highlightthickness=0,
            tabs=("4c",),
        )
        self.editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        editor_scroll = ttk.Scrollbar(
            editor_area,
            orient=tk.VERTICAL,
            command=self._scroll_editor,
        )
        editor_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.horizontal_scroll = ttk.Scrollbar(
            editor_panel,
            orient=tk.HORIZONTAL,
            command=self.editor.xview,
        )
        if not self.settings["editorWrap"]:
            self.horizontal_scroll.pack(fill=tk.X)
        self.editor.configure(
            yscrollcommand=self._editor_scrolled,
            xscrollcommand=self.horizontal_scroll.set,
        )
        for tag in HIGHLIGHT_TAGS:
            self.editor.tag_configure(tag)
        self.editor.bind("<<Modified>>", self._on_modified)
        self.editor.bind("<KeyRelease>", self._update_cursor_status)
        self.editor.bind("<ButtonRelease-1>", self._update_cursor_status)
        self.editor.bind("<MouseWheel>", self._on_mousewheel)
        self.editor.bind("<Return>", self._handle_return)
        self.editor.tag_configure(
            "search_match",
            background=self.theme_colors["accent"],
            foreground="#ffffff",
        )

        output_panel = ttk.Frame(content, style="Panel.TFrame")
        output_header = ttk.Frame(output_panel, style="Panel.TFrame", padding=(10, 7))
        output_header.pack(fill=tk.X)
        self.output_header_label = ttk.Label(
            output_header, text=self._t("output"), style="Muted.TLabel"
        )
        self.output_header_label.pack(side=tk.LEFT)
        self.clear_output_button = ttk.Button(
            output_header,
            text=self._t("clear"),
            command=self._clear_output,
        )
        self.clear_output_button.pack(side=tk.RIGHT)
        self.output = tk.Text(
            output_panel,
            height=8,
            state=tk.DISABLED,
            wrap=tk.WORD,
            padx=10,
            pady=8,
            background=colors["panel"],
            foreground=colors["foreground"],
            font=("Consolas", 10),
            borderwidth=0,
            highlightthickness=0,
        )
        self.output.pack(fill=tk.BOTH, expand=True)

        content.add(editor_panel, weight=4)
        content.add(output_panel, weight=1)

        status = ttk.Frame(self.root, padding=(14, 5))
        status.pack(fill=tk.X)
        self.document_status = tk.StringVar(value=self._t("ready"))
        self.cursor_status = tk.StringVar(value="Ln 1, Col 1")
        ttk.Label(status, textvariable=self.document_status, style="Muted.TLabel").pack(
            side=tk.LEFT
        )
        ttk.Label(status, textvariable=self.cursor_status, style="Muted.TLabel").pack(
            side=tk.RIGHT
        )

        self._update_line_numbers()
        self._refresh_track_tabs()

    def _apply_editor_preferences(self) -> None:
        colors = self.theme_colors
        self.root.configure(background=colors["background"])
        self._configure_style()
        for menu in self.menus:
            menu.configure(
                background=colors["panel"],
                foreground=colors["foreground"],
                activebackground=colors["accent"],
                activeforeground="#ffffff",
            )

        self.editor.configure(
            font=("Consolas", self.settings["editorFontSize"]),
            wrap=tk.WORD if self.settings["editorWrap"] else tk.NONE,
            background=colors["editor"],
            foreground=colors["foreground"],
            insertbackground=colors["foreground"],
            selectbackground=colors["selection"],
        )
        self.editor.tag_configure(
            "search_match",
            background=colors["accent"],
            foreground="#ffffff",
        )
        self.line_numbers.configure(
            font=("Consolas", self.settings["editorFontSize"]),
            background=colors["panel"],
            foreground=colors["muted"],
            insertbackground=colors["foreground"],
            selectbackground=colors["panel"],
        )
        self.output.configure(
            background=colors["panel"],
            foreground=colors["foreground"],
        )

        if self.settings["showLineNumbers"]:
            if not self.line_numbers.winfo_manager():
                self.line_numbers.pack(
                    side=tk.LEFT,
                    fill=tk.Y,
                    before=self.editor,
                )
        else:
            self.line_numbers.pack_forget()

        if self.settings["editorWrap"]:
            self.horizontal_scroll.pack_forget()
        elif not self.horizontal_scroll.winfo_manager():
            self.horizontal_scroll.pack(fill=tk.X)

        self._apply_syntax_colors()
        self._highlight_source()

    def _apply_locale(self) -> None:
        if not hasattr(self, "menus"):
            return
        menu, file_menu, edit_menu, track_menu, plugin_menu = self.menus[:5]
        menu.entryconfigure(0, label=self._t("file"))
        menu.entryconfigure(1, label=self._t("edit"))
        menu.entryconfigure(2, label=self._t("track_menu"))
        menu.entryconfigure(3, label=self._t("plugins_menu"))
        menu.entryconfigure(4, label=self._t("settings"))
        file_menu.entryconfigure(0, label=self._t("new_project"))
        file_menu.entryconfigure(1, label=self._t("open"))
        file_menu.entryconfigure(2, label=self._t("recent_files"))
        file_menu.entryconfigure(3, label=self._t("open_ust_with_instrument"))
        file_menu.entryconfigure(5, label=self._t("save"))
        file_menu.entryconfigure(6, label=self._t("save_as"))
        file_menu.entryconfigure(7, label=self._t("export_as"))
        file_menu.entryconfigure(9, label=self._t("save_selected_track"))
        file_menu.entryconfigure(11, label=self._t("load_utau_voicebank"))
        file_menu.entryconfigure(13, label=self._t("exit"))
        self.export_menu.entryconfigure(0, label=self._t("export_midi"))
        self.export_menu.entryconfigure(1, label=self._t("export_wav"))
        self.export_menu.entryconfigure(2, label=self._t("export_ust"))
        for index, translation_key in enumerate(
            (
                "save_track_source",
                "save_track_ust",
                "save_track_mid",
                "save_track_midi",
                "save_track_wav",
            )
        ):
            self.save_track_menu.entryconfigure(
                index,
                label=self._t(translation_key),
            )
        edit_menu.entryconfigure(0, label=self._t("edit_undo"))
        edit_menu.entryconfigure(1, label=self._t("edit_redo"))
        edit_menu.entryconfigure(3, label=self._t("search"))
        edit_menu.entryconfigure(4, label=self._t("replace_selected_text"))
        edit_menu.entryconfigure(6, label=self._t("select_all"))
        track_menu.entryconfigure(0, label=self._t("add_track_item"))
        track_menu.entryconfigure(1, label=self._t("delete_selected_track"))
        track_menu.entryconfigure(3, label=self._t("mute_selected_track"))
        track_menu.entryconfigure(4, label=self._t("solo_selected_track"))
        plugin_menu.entryconfigure(0, label=self._t("load_js_plugin"))
        plugin_menu.entryconfigure(1, label=self._t("load_input_plugin"))
        plugin_menu.entryconfigure(2, label=self._t("load_output_plugin"))
        plugin_menu.entryconfigure(3, label=self._t("load_ssp_plugin"))
        plugin_menu.entryconfigure(4, label=self._t("reset_output_plugin"))
        self.plugins_button.configure(text=self._t("plugins_menu"))
        self.settings_button.configure(text=self._t("settings"))
        if self.utau_voicebank_info_button is not None:
            self.utau_voicebank_info_button.configure(
                text=self._t("voicebank_info")
            )
        self.file_button.configure(text=self._t("file"))
        self.compile_button.configure(text=self._t("compile"))
        self.play_button.configure(text=self._t("play"))
        self.stop_button.configure(text=self._t("stop"))
        self.subtitle_label.configure(text=self._t("subtitle"))
        self.source_header_label.configure(text=self._t("source"))
        self.output_header_label.configure(text=self._t("output"))
        self.clear_output_button.configure(text=self._t("clear"))
        self._refresh_track_tabs()
        self._refresh_plugin_menu()
        self._refresh_recent_files_menu()
        self._update_edit_menu_state()
        self._update_cursor_status()
        self._update_title()

    def _post_file_menu(self) -> None:
        self.file_menu.tk_popup(
            self.file_button.winfo_rootx(),
            self.file_button.winfo_rooty() + self.file_button.winfo_height(),
        )
        self.file_menu.grab_release()

    def _post_plugins_menu(self) -> None:
        self.plugin_menu.tk_popup(
            self.plugins_button.winfo_rootx(),
            self.plugins_button.winfo_rooty() + self.plugins_button.winfo_height(),
        )
        self.plugin_menu.grab_release()

    def _apply_syntax_colors(self) -> None:
        colors = self.theme_colors
        command, definition, number, _display, string = SYNTAX_PRESETS[
            self.settings["syntaxPreset"]
        ][self.settings["theme"]]
        tag_colors = {
            "comment": colors["comment"],
            "string": string,
            "keyword": colors["keyword"],
            "command": command or colors["command"],
            "function": definition,
            "number": number,
            "pitch": number,
        }
        for tag, color in tag_colors.items():
            self.editor.tag_configure(tag, foreground=color)

    def _set_source(self, source: str, single_view: bool = False) -> None:
        if single_view:
            self.track_segments = (
                [SourceSegment(None, source)] if source else []
            )
            self.track_buffers = {None: source}
        else:
            self.track_segments, self.track_buffers = partition_source(
                source,
                self.settings["mixedFunctionTracksToGlobal"],
            )
        self.track_baseline = self.track_buffers.copy()
        self.muted_tracks.clear()
        self.solo_tracks.clear()
        self.active_track = next(
            (name for name in self.track_buffers if name is not None),
            None,
        )
        self._show_active_track()
        self.modified = False

    def _show_active_track(self) -> None:
        source = self.track_buffers.get(self.active_track, "")
        self.loading = True
        self.editor.delete("1.0", tk.END)
        self.editor.insert("1.0", source)
        self.editor.edit_reset()
        self.editor.edit_modified(False)
        self.loading = False
        self._update_line_numbers()
        self._update_cursor_status()
        self._highlight_source()
        self._refresh_track_tabs()
        self._update_edit_menu_state()

    def _capture_active_track(self) -> None:
        self.track_buffers[self.active_track] = self.editor.get("1.0", "end-1c")

    def _document_source(self) -> str:
        self._capture_active_track()
        return compose_source(
            self.track_segments,
            self.track_buffers,
            self.track_baseline,
        )

    def _synchronize_track_source(self) -> None:
        source = self._document_source()
        self.track_segments, self.track_buffers = partition_source(
            source,
            self.settings["mixedFunctionTracksToGlobal"],
        )
        self.track_baseline = self.track_buffers.copy()

    def _select_track(self, track_name: TrackKey) -> None:
        if track_name == self.active_track:
            return
        self._capture_active_track()
        self._synchronize_track_source()
        self.active_track = (
            track_name if track_name in self.track_buffers else None
        )
        self._show_active_track()

    def _refresh_track_tabs(self) -> None:
        if not hasattr(self, "track_tabs"):
            return
        for button in self.track_tab_buttons.values():
            button.destroy()
        self.track_tab_buttons.clear()

        tracks = [None]
        tracks.extend(name for name in self.track_buffers if name is not None)
        for track_name in tracks:
            style = (
                "ActiveTrack.TButton"
                if track_name == self.active_track
                else "TrackTab.TButton"
            )
            button = ttk.Button(
                self.track_tabs,
                text=self._track_label(track_name),
                style=style,
                command=lambda name=track_name: self._select_track(name),
            )
            button.pack(side=tk.LEFT, padx=(0, 4))
            button.bind(
                "<Button-3>",
                lambda event, name=track_name: self._show_track_context_menu(
                    event,
                    name,
                ),
            )
            self.track_tab_buttons[track_name] = button
        self._refresh_track_menu()

    def _track_label(self, track_name: TrackKey) -> str:
        if track_name is None:
            return self._t("shared_track")
        if track_name == "":
            return self._t("default_track")
        if track_name == GLOBAL_TRACK:
            return self._t("global_track")
        return track_name

    def _refresh_track_menu(self) -> None:
        if not hasattr(self, "track_menu"):
            return
        self.track_menu_mute_var.set(self.active_track in self.muted_tracks)
        self.track_menu_solo_var.set(self.active_track in self.solo_tracks)
        self.track_menu.entryconfigure(
            1,
            state=(
                tk.NORMAL
                if isinstance(self.active_track, str)
                else tk.DISABLED
            ),
        )

    def _toggle_selected_track_mix(self, mode: str) -> None:
        self._toggle_track_mix(mode, self.active_track)

    def delete_selected_track(self) -> None:
        track_name = self.active_track
        if not isinstance(track_name, str):
            return
        if not messagebox.askyesno(
            self._t("delete_selected_track"),
            self._t(
                "delete_track_prompt",
                track=self._track_label(track_name),
            ),
            parent=self.root,
        ):
            return

        source = self._document_source()
        remaining_source = remove_track_from_source(
            source,
            track_name,
            self.settings["mixedFunctionTracksToGlobal"],
        )
        muted_tracks = self.muted_tracks - {track_name}
        solo_tracks = self.solo_tracks - {track_name}
        self._set_source(remaining_source)
        self.muted_tracks = {
            name for name in muted_tracks if name in self.track_buffers
        }
        self.solo_tracks = {
            name for name in solo_tracks if name in self.track_buffers
        }
        self.modified = True
        self._update_title()
        self.document_status.set(self._t("unsaved"))
        self._write_output(
            self._t("track_deleted", track=self._track_label(track_name))
        )
        self._refresh_track_tabs()
        self._schedule_draft_save()

    def _show_track_context_menu(
        self,
        event: tk.Event,
        track_name: TrackKey,
    ) -> str:
        menu = tk.Menu(self.root, tearoff=False)
        menu.add_command(
            label=self._t(
                "solo_off" if track_name in self.solo_tracks else "solo_on"
            ),
            command=lambda: self._toggle_track_mix("solo", track_name),
        )
        menu.add_command(
            label=self._t(
                "mute_off" if track_name in self.muted_tracks else "mute_on"
            ),
            command=lambda: self._toggle_track_mix("mute", track_name),
        )
        try:
            menu.bind(
                "<Unmap>",
                lambda _event, context_menu=menu: context_menu.destroy(),
            )
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    def open_search(self) -> None:
        if self.search_dialog is not None and self.search_dialog.winfo_exists():
            self.search_dialog.deiconify()
            self.search_dialog.lift()
            if self.search_entry is not None:
                self.search_entry.focus_set()
                self.search_entry.selection_range(0, tk.END)
            return

        self.search_dialog = tk.Toplevel(self.root)
        self.search_dialog.title(self._t("search_title"))
        self.search_dialog.transient(self.root)
        self.search_dialog.resizable(False, False)
        self.search_dialog.protocol("WM_DELETE_WINDOW", self._close_search)
        frame = ttk.Frame(self.search_dialog, padding=12, style="Panel.TFrame")
        frame.grid(row=0, column=0, sticky="nsew")
        self.search_query = tk.StringVar()
        try:
            selected_text = self.editor.get(tk.SEL_FIRST, tk.SEL_LAST)
        except tk.TclError:
            selected_text = ""
        if selected_text and "\n" not in selected_text:
            self.search_query.set(selected_text)
            self.editor.mark_set(tk.INSERT, tk.SEL_FIRST)

        self.search_entry = ttk.Entry(
            frame,
            textvariable=self.search_query,
            width=32,
        )
        self.search_entry.grid(row=0, column=0, columnspan=2, sticky="ew")
        self.search_status = ttk.Label(
            frame,
            text="",
            style="Muted.TLabel",
        )
        self.search_status.grid(
            row=1,
            column=0,
            columnspan=2,
            sticky="w",
            pady=(6, 8),
        )
        ttk.Button(
            frame,
            text=self._t("find_previous"),
            command=lambda: self._find_text(backwards=True),
        ).grid(row=2, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(
            frame,
            text=self._t("find_next"),
            command=lambda: self._find_text(backwards=False),
        ).grid(row=2, column=1, sticky="ew", padx=(4, 0))
        self.search_entry.bind(
            "<Return>",
            lambda _event: self._find_text(backwards=False),
        )
        self.search_entry.bind(
            "<Shift-Return>",
            lambda _event: self._find_text(backwards=True),
        )
        self.search_dialog.bind("<Escape>", lambda _event: self._close_search())
        self.search_entry.focus_set()
        self.search_entry.selection_range(0, tk.END)
        self._find_text(backwards=False)

    def _find_text(self, backwards: bool) -> str:
        query = self.search_query.get() if self.search_query is not None else ""
        try:
            previous_start = self.editor.index("search_match.first")
            previous_end = self.editor.index("search_match.last")
        except tk.TclError:
            previous_start = None
            previous_end = None
        self.editor.tag_remove("search_match", "1.0", tk.END)
        if not query:
            if self.search_status is not None:
                self.search_status.configure(text="")
            return "break"

        if backwards:
            start = (
                self.editor.index(f"{previous_start} - 1 chars")
                if previous_start is not None
                else self.editor.index(f"{tk.INSERT} - 1 chars")
            )
            match = self.editor.search(
                query,
                start,
                stopindex="0.0",
                backwards=True,
                nocase=True,
            )
            if not match:
                match = self.editor.search(
                    query,
                    self.editor.index("end-1c"),
                    stopindex="0.0",
                    backwards=True,
                    nocase=True,
                )
        else:
            start = (
                previous_end
                if previous_end is not None
                else self.editor.index(tk.INSERT)
            )
            match = self.editor.search(
                query,
                start,
                stopindex=tk.END,
                nocase=True,
            )
            if not match:
                match = self.editor.search(
                    query,
                    "1.0",
                    stopindex=tk.END,
                    nocase=True,
                )

        if not match:
            if self.search_status is not None:
                self.search_status.configure(text=self._t("search_not_found"))
            return "break"
        match_end = f"{match}+{len(query)}c"
        self.editor.tag_add("search_match", match, match_end)
        self.editor.mark_set(tk.INSERT, match if backwards else match_end)
        self.editor.see(match)
        if self.search_status is not None:
            self.search_status.configure(text="")
        return "break"

    def _close_search(self) -> None:
        if self.search_dialog is not None and self.search_dialog.winfo_exists():
            self.search_dialog.destroy()
        self.search_dialog = None
        self.search_entry = None
        self.search_query = None
        self.search_status = None
        self.editor.tag_remove("search_match", "1.0", tk.END)

    def _run_search_shortcut(self) -> str:
        self.open_search()
        return "break"

    def _handle_return(self, _event: tk.Event) -> str | None:
        if not self.settings["autoIndent"]:
            return None

        line_start = self.editor.index("insert linestart")
        prefix = self.editor.get(line_start, tk.INSERT)
        indentation = re.match(r"[ \t]*", prefix).group(0)
        extra_indent = "    " if prefix.rstrip().endswith(("{", ":")) else ""
        self.editor.insert(tk.INSERT, "\n" + indentation + extra_indent)
        return "break"

    def _toggle_track_mix(self, mode: str, track_name: TrackKey) -> None:
        tracks = self.solo_tracks if mode == "solo" else self.muted_tracks
        if track_name in tracks:
            tracks.remove(track_name)
        else:
            tracks.add(track_name)
        self._refresh_track_tabs()

    def add_track(self) -> None:
        track_name = simpledialog.askstring(
            self._t("track_name_title"),
            self._t("track_name_prompt"),
            parent=self.root,
        )
        if track_name is None:
            return
        if not track_name.strip() or any(
            char in track_name for char in ('"', "\r", "\n")
        ):
            messagebox.showerror(
                self._t("track_name_title"),
                self._t("invalid_track_name"),
                parent=self.root,
            )
            return

        self._capture_active_track()
        self._synchronize_track_source()
        if track_name in self.track_buffers:
            messagebox.showerror(
                self._t("track_name_title"),
                self._t("track_exists"),
                parent=self.root,
            )
            return

        self.track_buffers[track_name] = (
            f'snd("piano", 4, C4, class="{track_name}");\n'
        )
        self.track_baseline[track_name] = ""
        self.active_track = track_name
        self.modified = True
        self._show_active_track()
        self._update_title()
        self._schedule_draft_save()

    def _on_modified(self, _event: tk.Event) -> None:
        if self.editor.edit_modified():
            self.editor.edit_modified(False)
            self._update_edit_menu_state()
            if not self.loading:
                self.modified = True
                self._update_title()
                self._update_line_numbers()
                self._schedule_highlighting()
                self._schedule_draft_save()

    def _schedule_highlighting(self) -> None:
        if self._highlight_after_id is not None:
            self.root.after_cancel(self._highlight_after_id)
        self._highlight_after_id = self.root.after(120, self._highlight_source)

    def _get_highlight_pattern(self, syntax: str) -> re.Pattern[str]:
        if syntax in self._highlight_patterns:
            return self._highlight_patterns[syntax]

        keywords = "|".join(
            re.escape(word) for word in sorted(KEYWORDS[syntax], key=len, reverse=True)
        )
        if syntax == "py":
            comments = r"\#[^\n]*"
        elif syntax == "js":
            comments = r"//[^\n]*|/\*[\s\S]*?\*/"
        else:
            comments = r"<[^>\n]*>"

        token_patterns = (
            ("string", r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`'),
            ("comment", comments),
            ("command", rf"\b(?:{'|'.join(COMMANDS)})\b"),
            ("keyword", rf"\b(?:{keywords})\b"),
            ("function", r"\b[A-Za-z_]\w*(?=\s*\()"),
            ("pitch", r"(?<![A-Za-z0-9_])[A-Ga-g](?:#|b)?-?\d+[~!]?(?![A-Za-z0-9_])"),
            ("number", r"(?<![\w.])(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?![\w.])"),
        )
        pattern = re.compile(
            "|".join(f"(?P<{name}>{expression})" for name, expression in token_patterns),
            re.IGNORECASE if syntax == "sws" else 0,
        )
        self._highlight_patterns[syntax] = pattern
        return pattern

    def _highlight_source(self) -> None:
        self._highlight_after_id = None
        source = self.editor.get("1.0", "end-1c")
        document_source = self._document_source()
        syntax_match = re.search(
            r'(?im)^\s*syntax\s*=\s*["\'](sws|soundwavscript|js|javascript|py|python)["\']',
            document_source,
        )
        syntax = "sws"
        if syntax_match:
            syntax_name = syntax_match.group(1).lower()
            if syntax_name in ("py", "python"):
                syntax = "py"
            elif syntax_name in ("js", "javascript"):
                syntax = "js"

        for tag in HIGHLIGHT_TAGS:
            self.editor.tag_remove(tag, "1.0", tk.END)
        pattern = self._get_highlight_pattern(syntax)
        for match in pattern.finditer(source):
            tag = match.lastgroup
            if tag is not None:
                start = f"1.0+{match.start()}c"
                end = f"1.0+{match.end()}c"
                self.editor.tag_add(tag, start, end)

    def _on_mousewheel(self, event: tk.Event) -> None:
        self.root.after_idle(self._update_line_numbers)
        return None

    def _editor_scrolled(self, first: str, last: str) -> None:
        self.line_numbers.yview_moveto(first)
        self.root.after_idle(self._update_line_numbers)

    def _scroll_editor(self, *args: str) -> None:
        self.editor.yview(*args)
        self.line_numbers.yview(*args)

    def _update_line_numbers(self) -> None:
        if not hasattr(self, "editor"):
            return
        line_count = int(self.editor.index("end-1c").split(".")[0])
        content = "\n".join(str(line) for line in range(1, line_count + 1))
        self.line_numbers.configure(state=tk.NORMAL)
        self.line_numbers.delete("1.0", tk.END)
        self.line_numbers.insert("1.0", content)
        self.line_numbers.configure(state=tk.DISABLED)
        self.line_numbers.yview_moveto(self.editor.yview()[0])

    def _update_cursor_status(self, _event: tk.Event | None = None) -> None:
        row, column = self.editor.index(tk.INSERT).split(".")
        column_number = int(column) + 1
        formats = {
            "ja": f"{row}行, {column_number}列",
            "de": f"Zeile {row}, Sp. {column_number}",
            "fr": f"Ligne {row}, col. {column_number}",
            "it": f"Riga {row}, col. {column_number}",
        }
        self.cursor_status.set(
            formats.get(self.language, f"Ln {row}, Col {column_number}")
        )
        self._update_edit_menu_state()

    def _select_all(self, _event: tk.Event) -> str:
        self.editor.tag_add(tk.SEL, "1.0", tk.END)
        self.editor.mark_set(tk.INSERT, "1.0")
        self.editor.see(tk.INSERT)
        return "break"

    def open_selection_replacement(self) -> None:
        if self.replace_dialog is not None and self.replace_dialog.winfo_exists():
            self.replace_dialog.deiconify()
            self.replace_dialog.lift()
            if self.replace_target is not None:
                self.replace_target.focus_set()
            return

        try:
            start = self.editor.index(tk.SEL_FIRST)
            end = self.editor.index(tk.SEL_LAST)
        except tk.TclError:
            messagebox.showinfo(
                self._t("replace_title"),
                self._t("replace_no_selection"),
                parent=self.root,
            )
            return

        self.replace_original_text = self.editor.get(start, end)
        self.replace_range = (start, end)
        self.replace_dialog = tk.Toplevel(self.root)
        self.replace_dialog.title(self._t("replace_title"))
        self.replace_dialog.transient(self.root)
        self.replace_dialog.resizable(False, False)
        self.replace_dialog.protocol(
            "WM_DELETE_WINDOW",
            self._close_selection_replacement,
        )

        frame = ttk.Frame(self.replace_dialog, padding=12, style="Panel.TFrame")
        frame.grid(row=0, column=0, sticky="nsew")
        ttk.Label(frame, text=self._t("replace_source")).grid(
            row=0,
            column=0,
            sticky="w",
            padx=(0, 8),
        )
        ttk.Label(frame, text=self._t("replace_target")).grid(
            row=0,
            column=2,
            sticky="w",
            padx=(8, 0),
        )

        text_options = {
            "width": 32,
            "height": 5,
            "wrap": tk.WORD,
            "font": ("Consolas", self.settings["editorFontSize"]),
            "background": self.theme_colors["editor"],
            "foreground": self.theme_colors["foreground"],
            "insertbackground": self.theme_colors["foreground"],
            "selectbackground": self.theme_colors["selection"],
        }
        source_box = tk.Text(frame, **text_options)
        source_box.insert("1.0", self.replace_original_text)
        source_box.configure(state=tk.DISABLED)
        source_box.grid(row=1, column=0, sticky="nsew", pady=(5, 10))
        self.replace_source = source_box
        ttk.Label(frame, text="→", style="Muted.TLabel").grid(
            row=1,
            column=1,
            padx=8,
        )
        self.replace_target = tk.Text(frame, **text_options)
        self.replace_target.grid(row=1, column=2, sticky="nsew", pady=(5, 10))

        buttons = ttk.Frame(frame, style="Panel.TFrame")
        buttons.grid(row=2, column=0, columnspan=3, sticky="e")
        ttk.Button(
            buttons,
            text=self._t("cancel"),
            command=self._close_selection_replacement,
        ).pack(side=tk.RIGHT, padx=(8, 0))
        ttk.Button(
            buttons,
            text=self._t("apply"),
            command=self._apply_selection_replacement,
        ).pack(side=tk.RIGHT)

        self.replace_dialog.bind(
            "<Escape>",
            lambda _event: self._close_selection_replacement(),
        )
        self.replace_dialog.grab_set()
        self.replace_target.focus_set()

    def _apply_selection_replacement(self) -> None:
        if self.replace_target is None or self.replace_range is None:
            return

        replacement = self.replace_target.get("1.0", "end-1c")
        start, end = self.replace_range
        if replacement != self.replace_original_text:
            self.editor.replace(start, end, replacement)
            self.editor.tag_remove(tk.SEL, "1.0", tk.END)
            self.editor.mark_set(tk.INSERT, f"{start}+{len(replacement)}c")
            self.editor.see(tk.INSERT)
            self._update_edit_menu_state()
        self._close_selection_replacement()
        self.editor.focus_set()

    def _close_selection_replacement(self) -> None:
        if self.replace_dialog is not None and self.replace_dialog.winfo_exists():
            self.replace_dialog.destroy()
        self.replace_dialog = None
        self.replace_source = None
        self.replace_target = None
        self.replace_range = None
        self.replace_original_text = ""

    def undo_edit(self) -> None:
        if not self.editor.tk.call(self.editor._w, "edit", "canundo"):
            return
        self.editor.edit_undo()
        self._update_edit_menu_state()

    def redo_edit(self) -> None:
        if not self.editor.tk.call(self.editor._w, "edit", "canredo"):
            return
        self.editor.edit_redo()
        self._update_edit_menu_state()

    def _run_undo_shortcut(self) -> str:
        self.undo_edit()
        return "break"

    def _run_redo_shortcut(self) -> str:
        self.redo_edit()
        return "break"

    def _update_edit_menu_state(self) -> None:
        if not hasattr(self, "edit_menu") or not hasattr(self, "editor"):
            return
        can_undo = bool(self.editor.tk.call(self.editor._w, "edit", "canundo"))
        can_redo = bool(self.editor.tk.call(self.editor._w, "edit", "canredo"))
        self.edit_menu.entryconfigure(
            0,
            state=tk.NORMAL if can_undo else tk.DISABLED,
        )
        self.edit_menu.entryconfigure(
            1,
            state=tk.NORMAL if can_redo else tk.DISABLED,
        )
        has_selection = bool(self.editor.tag_ranges(tk.SEL))
        self.edit_menu.entryconfigure(
            4,
            state=tk.NORMAL if has_selection else tk.DISABLED,
        )

    def _write_output(self, message: str) -> None:
        self.output.configure(state=tk.NORMAL)
        self.output.insert(tk.END, message.rstrip() + "\n")
        self.output.see(tk.END)
        self.output.configure(state=tk.DISABLED)

    def _clear_output(self) -> None:
        self.output.configure(state=tk.NORMAL)
        self.output.delete("1.0", tk.END)
        self.output.configure(state=tk.DISABLED)

    def _update_title(self) -> None:
        name = self.current_path.name if self.current_path else "Untitled.ss"
        marker = " *" if self.modified else ""
        self.root.title(f"{name}{marker} - {APP_NAME}")
        if hasattr(self, "path_label"):
            self.path_label.configure(
                text=str(self.current_path) if self.current_path else "Untitled.ss"
            )
        if hasattr(self, "document_status"):
            if self.active_task == "play":
                status_key = {
                    "rendering": "rendering",
                    "playing": "playing",
                    "stopping": "stop_requested",
                }.get(self.playback_phase, "rendering")
                self.document_status.set(self._t(status_key))
            elif self.compiling:
                self.document_status.set(self._t("compiling"))
            elif self.modified:
                self.document_status.set(self._t("unsaved"))
            else:
                self.document_status.set(self._t("ready"))

    def _confirm_discard_changes(self) -> bool:
        if not self.modified or not self.settings["warnUnsaved"]:
            return True
        answer = messagebox.askyesnocancel(
            self._t("unsaved_title"),
            self._t("unsaved_prompt"),
            parent=self.root,
        )
        if answer is None:
            return False
        if answer:
            return self.save_document()
        return True

    def new_document(self) -> None:
        if not self._confirm_discard_changes():
            return
        self._cancel_draft_save()
        self._clear_draft()
        self.current_path = None
        self.current_ust_path = None
        self._set_source("")
        self._update_title()
        self.document_status.set(self._t("new_document"))

    def open_document(self, filename: str | None = None) -> None:
        if filename is None:
            filename = filedialog.askopenfilename(
                parent=self.root,
                title=self._t("open_file"),
                filetypes=[
                    (
                        self._t("supported_files"),
                        "*.ss *.txt *.ust *.mid *.midi",
                    ),
                    (self._t("sws_files"), "*.ss"),
                    (self._t("text_files"), "*.txt"),
                    (self._t("ust_files"), "*.ust"),
                    (self._t("midi_files"), "*.mid *.midi"),
                    (self._t("all_files"), "*.*"),
                ],
                initialdir=str(
                    self.current_path.parent
                    if self.current_path
                    else APP_DIRECTORY
                ),
            )
        if not filename:
            return
        path = Path(filename)
        if path.suffix.lower() == ".ust":
            self.open_ust_with_instrument(str(path))
            return
        if not self._confirm_discard_changes():
            return

        is_midi = path.suffix.lower() in {".mid", ".midi"}
        try:
            if is_midi:
                compiler = self._new_compiler()
                events = compiler.compile_file(str(path))
                source = sws_engine.midi_events_to_sws_source(
                    events,
                    compiler.tempo_map,
                )
            else:
                source = path.read_text(encoding="utf-8")
        except sws_engine.SWSError as error:
            details = error.args[0]
            if isinstance(details, tuple) and len(details) == 3:
                message = self._t(
                    "compile_error",
                    line=details[0],
                    kind=details[1],
                    message=details[2],
                )
            else:
                message = str(error)
            messagebox.showerror(
                self._t("open_failed"),
                message,
                parent=self.root,
            )
            self._write_output(message)
            return
        except (OSError, UnicodeError) as error:
            messagebox.showerror(
                self._t("open_failed"), str(error), parent=self.root
            )
            return
        except ValueError as error:
            messagebox.showerror(
                self._t("open_failed"), str(error), parent=self.root
            )
            self._write_output(str(error))
            return
        self._cancel_draft_save()
        self._clear_draft()
        self.current_path = None if is_midi else path
        self.current_ust_path = None
        self._set_source(source)
        self._update_title()
        if is_midi:
            message = self._t("midi_imported", path=path)
            self.document_status.set(message)
            self._write_output(message)
        else:
            self.document_status.set(self._t("opened"))
            self._write_output(f'{self._t("opened")}: {path}')
        self._remember_recent_file(path)

    def _voicebank_instruments(self) -> set[str]:
        if self.utau_voicebank is None:
            return set()
        return {self.utau_voicebank.root.name.casefold()}

    def _new_compiler(self) -> sws_engine.Compiler:
        return sws_engine.Compiler(
            extra_instruments=self._voicebank_instruments()
        )

    def _current_utau_resample_cache(
        self,
    ) -> sws_engine.UTAUResampleCacheSession | None:
        if self.current_ust_path is None:
            return None
        ust_path = self.current_ust_path.resolve()
        cache = self._utau_resample_caches.get(ust_path)
        if cache is None:
            cache = sws_engine.UTAUResampleCacheSession(ust_path.parent)
            self._utau_resample_caches[ust_path] = cache
        return cache

    def open_ust_with_instrument(self, filename: str | None = None) -> None:
        if not self._confirm_discard_changes():
            return
        if filename is None:
            filename = filedialog.askopenfilename(
                parent=self.root,
                title=self._t("open_ust_with_instrument"),
                filetypes=[
                    (self._t("ust_files"), "*.ust"),
                    (self._t("all_files"), "*.*"),
                ],
                initialdir=str(
                    self.current_path.parent
                    if self.current_path
                    else APP_DIRECTORY
                ),
            )
        if not filename:
            return

        instrument = self._choose_ust_instrument()
        if instrument is None:
            return

        path = Path(filename)
        allowed_instruments = self._voicebank_instruments()
        try:
            source = sws_engine.USTParser().parse_file(
                str(path),
                instrument=instrument,
                allowed_instruments=allowed_instruments,
            )
        except sws_engine.SWSError as error:
            details = error.args[0]
            if isinstance(details, tuple) and len(details) == 3:
                message = self._t(
                    "compile_error",
                    line=details[0],
                    kind=details[1],
                    message=details[2],
                )
            else:
                message = str(error)
            messagebox.showerror(
                self._t("open_failed"),
                message,
                parent=self.root,
            )
            self._write_output(message)
            return
        except (OSError, UnicodeError, ValueError) as error:
            message = str(error)
            messagebox.showerror(
                self._t("open_failed"),
                message,
                parent=self.root,
            )
            self._write_output(message)
            return

        self._cancel_draft_save()
        self._clear_draft()
        self.current_path = None
        self.current_ust_path = path.resolve()
        self._set_source(source, single_view=True)
        self._update_title()
        self.document_status.set(self._t("opened"))
        self._write_output(
            self._t(
                "ust_imported",
                instrument=instrument,
                path=path,
            )
        )
        self._remember_recent_file(path)

    def open_utau_voicebank_info(
        self,
        parent: tk.Misc | None = None,
    ) -> bool:
        voicebank = self.utau_voicebank
        if voicebank is None:
            return False
        if (
            self.voicebank_info_dialog is not None
            and self.voicebank_info_dialog.winfo_exists()
        ):
            self.voicebank_info_dialog.focus_set()
            return True

        parent = parent or self.settings_dialog or self.root
        dialog = tk.Toplevel(parent)
        self.voicebank_info_dialog = dialog
        dialog.title(self._t("voicebank_info"))
        dialog.transient(parent)
        dialog.geometry("760x540")
        dialog.minsize(560, 360)
        dialog.configure(background=self.theme_colors["background"])

        content = ttk.Frame(dialog, padding=12)
        content.pack(fill=tk.BOTH, expand=True)
        notebook = ttk.Notebook(content)
        notebook.pack(fill=tk.BOTH, expand=True)

        overview_lines = [
            f'{self._t("voicebank_folder")}: {voicebank.root}',
            f'{self._t("voicebank_oto_count")}: {len(voicebank.oto_entries)}',
            "",
            self._t("voicebank_metadata"),
        ]
        if voicebank.character:
            overview_lines.extend(
                f"{key}={value}"
                for key, value in voicebank.character.items()
            )
        else:
            overview_lines.append(self._t("voicebank_no_metadata"))
        if voicebank.warnings:
            overview_lines.extend(
                ["", self._t("voicebank_warnings"), *voicebank.warnings]
            )

        oto_lines = []
        for entry in voicebank.oto_entries:
            relative_wav = entry.wav_path.relative_to(voicebank.root)
            oto_lines.append(
                f"{entry.alias or entry.wav_path.name} | {relative_wav}"
            )
            oto_lines.append(
                "  "
                f"offset={entry.offset:g}, consonant={entry.consonant:g}, "
                f"cutoff={entry.cutoff:g}, "
                f"preutterance={entry.preutterance:g}, "
                f"overlap={entry.overlap:g}"
            )
        if not oto_lines:
            oto_lines.append(self._t("voicebank_no_oto"))

        if voicebank.readme_text is not None:
            readme_text = voicebank.readme_text
        elif any(
            key.casefold() == "readme" and value
            for key, value in voicebank.character.items()
        ):
            readme_text = self._t("voicebank_readme_unavailable")
        else:
            readme_text = self._t("voicebank_no_readme")

        def add_text_tab(label: str, value: str) -> None:
            frame = ttk.Frame(notebook)
            text = tk.Text(
                frame,
                wrap=tk.WORD,
                background=self.theme_colors["panel"],
                foreground=self.theme_colors["foreground"],
                insertbackground=self.theme_colors["foreground"],
            )
            scrollbar = ttk.Scrollbar(
                frame,
                orient=tk.VERTICAL,
                command=text.yview,
            )
            text.configure(yscrollcommand=scrollbar.set)
            text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            text.insert("1.0", value)
            text.configure(state=tk.DISABLED)
            notebook.add(frame, text=label)

        add_text_tab(
            self._t("voicebank_overview"),
            "\n".join(overview_lines),
        )
        add_text_tab(
            self._t("voicebank_oto"),
            "\n".join(oto_lines),
        )
        add_text_tab(
            self._t("voicebank_readme"),
            readme_text,
        )

        buttons = ttk.Frame(content)
        buttons.pack(fill=tk.X, pady=(10, 0))

        def close() -> None:
            if self.voicebank_info_dialog is dialog:
                self.voicebank_info_dialog = None
            dialog.destroy()

        ttk.Button(
            buttons,
            text=self._t("cancel"),
            command=close,
        ).pack(side=tk.RIGHT)
        dialog.protocol("WM_DELETE_WINDOW", close)
        dialog.bind("<Escape>", lambda _event: close())
        dialog.grab_set()
        dialog.focus_set()
        return True

    def load_utau_voicebank(self, directory: str | None = None) -> bool:
        if directory is None:
            directory = filedialog.askdirectory(
                parent=self.root,
                title=self._t("load_utau_voicebank"),
                initialdir=str(
                    self.current_path.parent
                    if self.current_path
                    else APP_DIRECTORY
                ),
                mustexist=True,
            )
        if not directory:
            return False

        try:
            voicebank = sws_engine.read_utau_voicebank(directory)
        except (OSError, UnicodeError, ValueError) as error:
            messagebox.showerror(
                self._t("voicebank_load_failed"),
                str(error),
                parent=self.root,
            )
            self._write_output(str(error))
            return False

        self.utau_voicebank = voicebank
        name = next(
            (
                value
                for key, value in voicebank.character.items()
                if key.casefold() == "name"
            ),
            voicebank.root.name,
        )
        summary = self._t(
            "voicebank_loaded",
            name=name,
            entries=len(voicebank.oto_entries),
            warnings=len(voicebank.warnings),
        )
        self.document_status.set(summary)
        self._write_output(summary)
        self._write_output(f"Voicebank: {voicebank.root}")

        if voicebank.character:
            self._write_output(self._t("voicebank_metadata"))
            for key, value in voicebank.character.items():
                self._write_output(f"{key}={value}")

        for entry in voicebank.oto_entries[:10]:
            self._write_output(
                f"oto: {entry.alias or entry.wav_path.name} "
                f"({entry.wav_path.relative_to(voicebank.root)})"
            )
        if len(voicebank.oto_entries) > 10:
            self._write_output(
                f"... {len(voicebank.oto_entries) - 10} more oto entries"
            )

        if voicebank.warnings:
            self._write_output(self._t("voicebank_warnings"))
            for warning in voicebank.warnings:
                self._write_output(warning)
            messagebox.showwarning(
                self._t("voicebank_warnings"),
                summary,
                parent=self.root,
            )
        else:
            messagebox.showinfo(
                self._t("load_utau_voicebank"),
                summary,
                parent=self.root,
            )
        return True

    def _choose_ust_instrument(self) -> str | None:
        dialog = tk.Toplevel(self.root)
        dialog.title(self._t("ust_instrument_title"))
        dialog.transient(self.root)
        dialog.resizable(False, False)
        frame = ttk.Frame(dialog, padding=14)
        frame.pack(fill=tk.BOTH, expand=True)
        ttk.Label(
            frame,
            text=self._t("ust_instrument_prompt"),
        ).pack(anchor=tk.W, pady=(0, 8))

        voicebank_instrument = (
            self.utau_voicebank.root.name
            if self.utau_voicebank is not None
            else None
        )
        instruments = set(sws_engine.VALID_INSTRUMENTS)
        if voicebank_instrument:
            instruments.add(voicebank_instrument)
        instrument_var = tk.StringVar(
            master=dialog,
            value=voicebank_instrument or sws_engine.DEFAULT_UST_INSTRUMENT,
        )
        instrument_box = ttk.Combobox(
            frame,
            textvariable=instrument_var,
            values=sorted(instruments, key=str.casefold),
            state="readonly",
        )
        instrument_box.pack(fill=tk.X)

        result: list[str | None] = [None]

        def finish(accepted: bool) -> None:
            selected = instrument_var.get()
            if accepted and selected in instruments:
                result[0] = selected
            dialog.destroy()

        buttons = ttk.Frame(frame)
        buttons.pack(fill=tk.X, pady=(12, 0))
        ttk.Button(
            buttons,
            text=self._t("cancel"),
            command=lambda: finish(False),
        ).pack(side=tk.RIGHT)
        ttk.Button(
            buttons,
            text=self._t("apply"),
            command=lambda: finish(True),
        ).pack(side=tk.RIGHT, padx=(0, 6))
        dialog.protocol("WM_DELETE_WINDOW", lambda: finish(False))
        dialog.bind("<Return>", lambda _event: finish(True))
        dialog.bind("<Escape>", lambda _event: finish(False))
        dialog.grab_set()
        instrument_box.focus_set()
        self.root.wait_window(dialog)
        return result[0]

    def save_document(self) -> bool:
        if self.current_path is None:
            return self.save_document_as()
        return self._write_document(self.current_path)

    def save_document_as(self) -> bool:
        filename = filedialog.asksaveasfilename(
            parent=self.root,
            title=self._t("save_source"),
            defaultextension=".ss",
            filetypes=[
                (self._t("sws_files"), "*.ss"),
                (self._t("text_files"), "*.txt"),
                (self._t("all_files"), "*.*"),
            ],
            initialdir=str(self.current_path.parent if self.current_path else APP_DIRECTORY),
            initialfile=self.current_path.name if self.current_path else "untitled.ss",
        )
        if not filename:
            return False
        path = Path(filename)
        if not path.suffix:
            path = path.with_suffix(".ss")
        if self._write_document(path):
            self.current_path = path
            self._update_title()
            return True
        return False

    def save_selected_track(self, file_format: str = "ss") -> bool:
        if self.active_task is not None:
            return False
        self._capture_active_track()
        track_name = self._track_label(self.active_track)
        extensions = {
            "ss": ".ss",
            "ust": ".ust",
            "mid": ".mid",
            "midi": ".midi",
            "wav": ".wav",
        }
        extension = extensions.get(file_format)
        if extension is None:
            raise ValueError(f"unsupported track export format: {file_format}")

        if file_format == "ss":
            file_type = self._t("sws_files")
        elif file_format == "ust":
            file_type = self._t("export_ust")
        elif file_format in {"mid", "midi"}:
            translation_key = (
                "save_track_mid" if file_format == "mid" else "save_track_midi"
            )
            file_type = self._t(translation_key)
        else:
            file_type = self._t("export_wav")

        filename = filedialog.asksaveasfilename(
            parent=self.root,
            title=self._t("save_selected_track"),
            defaultextension=extension,
            filetypes=[
                (file_type, f"*{extension}"),
                (self._t("all_files"), "*.*"),
            ],
            initialdir=str(
                self.current_path.parent if self.current_path else APP_DIRECTORY
            ),
            initialfile=f"track{extension}",
        )
        if not filename:
            return False

        path = Path(filename)
        if path.suffix.lower() != extension:
            path = path.with_suffix(extension)

        try:
            if file_format == "ss":
                sws_engine.SSGenerator(
                    self.track_buffers.get(self.active_track, "")
                ).generate(str(path))
            else:
                source = self._document_source()
                compiler = self._new_compiler()
                events = compiler.compile_source(source)
                if compiler.plugins_to_run:
                    run_plugins(
                        compiler.plugins_to_run,
                        events,
                        compiler,
                        self.loaded_js_plugins.copy(),
                        self.loaded_plugin_syntaxes.copy(),
                    )
                events = filter_events_for_tracks(
                    events,
                    source,
                    set(),
                    {self.active_track},
                    self.settings["mixedFunctionTracksToGlobal"],
                )
                if not events:
                    raise ValueError(self._t("no_track_events"))

                path.parent.mkdir(parents=True, exist_ok=True)
                if file_format == "ust":
                    if not self._supports_ust_export(events, compiler.tempo_map):
                        raise ValueError(self._t("ust_export_unsupported"))
                    sws_engine.USTGenerator(
                        events,
                        compiler.tempo_map,
                        compiler.key,
                    ).generate(str(path))
                elif file_format in {"mid", "midi"}:
                    sws_engine.MIDIGenerator(
                        events,
                        compiler.tempo_map,
                        compiler.key,
                    ).generate(str(path))
                else:
                    sws_engine.analyze_slurs(events)
                    self.active_task = "export"
                    self.compiling = True
                    self._set_task_controls()
                    self._update_title()
                    self.document_status.set(self._t("exporting_wav"))
                    self._write_output(self._t("exporting_wav"))
                    worker = threading.Thread(
                        target=self._wav_export_worker,
                        args=(
                            events,
                            compiler,
                            path,
                            self.settings["masterVolume"],
                            self.output_plugin,
                        ),
                        daemon=True,
                    )
                    worker.start()
                    return True
        except Exception as error:
            messagebox.showerror(
                (
                    self._t("save_failed")
                    if file_format == "ss"
                    else self._t("export_as")
                ),
                str(error),
                parent=self.root,
            )
            self._write_output(str(error))
            return False

        message = self._t(
            "track_saved",
            track=track_name,
            path=path,
        )
        self.document_status.set(message)
        self._write_output(message)
        return True

    def export_ust(self) -> None:
        self._export_sequence("ust")

    def export_midi(self) -> None:
        self._export_sequence("midi")

    def export_wav(self) -> None:
        self._export_sequence("wav")

    def _export_sequence(self, file_format: str) -> None:
        if self.active_task is not None:
            return
        if file_format == "ust":
            extension = ".ust"
            file_type = self._t("export_ust")
            generator_name = ".ust"
        elif file_format == "midi":
            extension = ".midi"
            file_type = self._t("export_midi")
            generator_name = ".midi"
        else:
            extension = ".wav"
            file_type = self._t("export_wav")
            generator_name = ".wav"

        filename = filedialog.asksaveasfilename(
            parent=self.root,
            title=self._t("export_as"),
            defaultextension=extension,
            filetypes=[
                (
                    file_type,
                    "*.midi *.mid" if file_format == "midi" else f"*{extension}",
                ),
                (self._t("all_files"), "*.*"),
            ],
            initialdir=str(
                self.current_path.parent if self.current_path else APP_DIRECTORY
            ),
        )
        if not filename:
            return

        path = Path(filename)
        accepted_extensions = (
            {".midi", ".mid"} if file_format == "midi" else {extension}
        )
        if path.suffix.lower() not in accepted_extensions:
            path = path.with_suffix(extension)
        if file_format == "midi":
            generator_name = path.suffix.lower()

        try:
            compiler = self._new_compiler()
            events = compiler.compile_source(self._document_source())
            if compiler.plugins_to_run:
                run_plugins(
                    compiler.plugins_to_run,
                    events,
                    compiler,
                    self.loaded_js_plugins.copy(),
                    self.loaded_plugin_syntaxes.copy(),
                )

            path.parent.mkdir(parents=True, exist_ok=True)
            if file_format == "ust":
                if not self._supports_ust_export(events, compiler.tempo_map):
                    raise ValueError(self._t("ust_export_unsupported"))
                sws_engine.USTGenerator(
                    events,
                    compiler.tempo_map,
                    compiler.key,
                ).generate(str(path))
            elif file_format == "midi":
                sws_engine.MIDIGenerator(
                    events,
                    compiler.tempo_map,
                    compiler.key,
                ).generate(str(path))
            else:
                sws_engine.analyze_slurs(events)
                self.active_task = "export"
                self.compiling = True
                self._set_task_controls()
                self._update_title()
                self.document_status.set(self._t("exporting_wav"))
                self._write_output(self._t("exporting_wav"))
                worker = threading.Thread(
                    target=self._wav_export_worker,
                    args=(
                        events,
                        compiler,
                        path,
                        self.settings["masterVolume"],
                        self.output_plugin,
                        self.output_plugin_syntax,
                    ),
                    daemon=True,
                )
                worker.start()
                return
        except Exception as error:
            message = self._t("export_failed", message=error)
            messagebox.showerror(self._t("export_as"), message, parent=self.root)
            self._write_output(message)
            return

        message = self._t("export_success", format=generator_name, path=path)
        self._write_output(message)
        self.document_status.set(message)

    def _wav_export_worker(
        self,
        events: list[sws_engine.SoundEvent],
        compiler: sws_engine.Compiler,
        path: Path,
        master_volume: int,
        output_plugin: tuple[str, str] | None,
        output_plugin_syntax: str,
    ) -> None:
        try:
            if output_plugin is None:
                sws_engine.Renderer(
                    events,
                    compiler.tempo_map,
                    compiler.key,
                    master_volume=master_volume,
                ).render(str(path))
            else:
                plugin_name, plugin_source = output_plugin
                render_output_plugin = (
                    render_python_output_plugin_to_wav
                    if output_plugin_syntax == "PY"
                    else render_output_plugin_to_wav
                )
                render_output_plugin(
                    plugin_name,
                    plugin_source,
                    events,
                    compiler,
                    str(path),
                    sws_engine.SAMPLE_RATE,
                    master_volume,
                )
            result = ("format_saved", (".wav", path))
        except Exception as error:
            result = ("format_failed", (".wav", error))
        if not self.closing:
            self.compile_results.put(result)

    @staticmethod
    def _supports_ust_export(
        events: list[sws_engine.SoundEvent],
        tempo_map: sws_engine.TempoMap,
    ) -> bool:
        previous_end = 0.0
        for event in sorted(events, key=lambda item: (item.start, item.line)):
            if event.start < previous_end:
                return False
            previous_end = event.end

        for beat, _tempo in tempo_map.segments[1:]:
            for event in events:
                is_sounding = any(
                    note.pitch != "null" for note in event.notes
                )
                if is_sounding and event.start < beat < event.end:
                    return False
        return True

    def _write_document(self, path: Path) -> bool:
        source = self._document_source()
        try:
            path.write_text(source, encoding="utf-8", newline="\n")
        except OSError as error:
            messagebox.showerror(
                self._t("save_failed"), str(error), parent=self.root
            )
            return False
        self.current_path = path
        self.modified = False
        self.editor.edit_modified(False)
        self._cancel_draft_save()
        self._clear_draft()
        self._update_title()
        self.document_status.set(self._t("saved"))
        self._write_output(f'{self._t("saved")}: {path}')
        return True

    def _set_task_controls(self) -> None:
        busy = self.active_task is not None
        self._set_playback_input_lock(self.active_task == "play")
        self.compile_button.configure(
            state=tk.DISABLED if busy else tk.NORMAL
        )
        self.play_button.configure(
            state=tk.DISABLED if busy else tk.NORMAL
        )
        self.stop_button.configure(
            state=(
                tk.NORMAL
                if self.active_task == "play" and self.playback_phase != "stopping"
                else tk.DISABLED
            )
        )

    def _iter_widget_tree(self, parent: tk.Misc):
        yield parent
        for child in parent.winfo_children():
            yield from self._iter_widget_tree(child)

    def _is_stop_button_widget(self, widget: tk.Misc) -> bool:
        while widget is not None:
            if widget is self.stop_button:
                return True
            widget = getattr(widget, "master", None)
        return False

    def _block_playback_input(self, event: tk.Event) -> str | None:
        if self._is_stop_button_widget(event.widget):
            return None
        if getattr(event, "keysym", None) == "Escape":
            self.stop_playback()
        return "break"

    def _set_playback_input_lock(self, locked: bool) -> None:
        if locked == self._playback_input_locked:
            return
        self._playback_input_locked = locked
        widgets = list(self._iter_widget_tree(self.root))
        widgets.extend(menu for menu in self.menus if menu not in widgets)

        if locked:
            for sequence in (
                "<KeyPress>",
                "<ButtonPress>",
                "<ButtonRelease>",
                "<MouseWheel>",
                "<Button-4>",
                "<Button-5>",
            ):
                self.root.bind_class(
                    self._playback_lock_tag,
                    sequence,
                    self._block_playback_input,
                )
            self._playback_widget_states = []
            for widget in widgets:
                tags = widget.bindtags()
                if self._playback_lock_tag not in tags:
                    widget.bindtags((self._playback_lock_tag, *tags))
                if widget is self.stop_button:
                    continue
                try:
                    state = widget.cget("state")
                except tk.TclError:
                    continue
                self._playback_widget_states.append((widget, state))
                widget.configure(state=tk.DISABLED)

            self._playback_menu_states = []
            for menu in self.menus:
                last_entry = menu.index("end")
                if last_entry is None:
                    continue
                for index in range(last_entry + 1):
                    if menu.type(index) == "separator":
                        continue
                    state = menu.entrycget(index, "state")
                    self._playback_menu_states.append(
                        (menu, index, state)
                    )
                    menu.entryconfigure(index, state=tk.DISABLED)
            return

        for widget, state in self._playback_widget_states:
            if widget.winfo_exists():
                widget.configure(state=state)
        self._playback_widget_states = []
        for menu, index, state in self._playback_menu_states:
            if menu.winfo_exists():
                menu.entryconfigure(index, state=state)
        self._playback_menu_states = []
        for widget in widgets:
            tags = tuple(
                tag
                for tag in widget.bindtags()
                if tag != self._playback_lock_tag
            )
            widget.bindtags(tags)

    def compile_document(self) -> None:
        if self.active_task is not None:
            return
        source = self._document_source()
        self.active_task = "compile"
        self.compiling = True
        self._set_task_controls()
        self._update_title()
        self._write_output(self._t("compiling_source"))
        worker = threading.Thread(
            target=self._compile_worker,
            args=(
                source,
                self.loaded_js_plugins.copy(),
                self.loaded_plugin_syntaxes.copy(),
                self._voicebank_instruments(),
            ),
            daemon=True,
        )
        worker.start()

    def play_document(self) -> None:
        if self.active_task is not None:
            return
        source = self._document_source()
        self.active_task = "play"
        self.playback_phase = "rendering"
        self.playback_stop_event.clear()
        self.compiling = True
        self._set_task_controls()
        self._update_title()
        self._write_output(self._t("rendering"))
        worker = threading.Thread(
            target=self._play_worker,
            args=(
                source,
                set(self.muted_tracks),
                set(self.solo_tracks),
                self.settings["mixedFunctionTracksToGlobal"],
                self.loaded_js_plugins.copy(),
                self.loaded_plugin_syntaxes.copy(),
                self.output_plugin,
                self.output_plugin_syntax,
                PlaybackOptions(
                    use_utau_tools=bool(
                        self.settings["useUtauToolsForPlayback"]
                    ),
                    wavtool_path=str(self.settings["utauWavtoolPath"]),
                    resampler_path=str(self.settings["utauResamplerPath"]),
                    master_volume=int(self.settings["masterVolume"]),
                    resampler_flags=str(
                        self.settings["utauResamplerFlags"]
                    ),
                ),
                self.utau_voicebank,
                self._current_utau_resample_cache(),
            ),
            daemon=True,
        )
        worker.start()

    def stop_playback(self) -> None:
        if self.active_task != "play" or self.playback_phase == "stopping":
            return
        self.playback_phase = "stopping"
        self.playback_stop_event.set()
        self._set_task_controls()
        self._update_title()
        self._write_output(self._t("stop_requested"))

    def _compile_worker(
        self,
        source: str,
        plugin_sources: dict[str, str],
        plugin_syntaxes: dict[str, str],
        extra_instruments: set[str] | None = None,
    ) -> None:
        try:
            compiler = sws_engine.Compiler(extra_instruments=extra_instruments)
            events = compiler.compile_source(source)
            sws_engine.analyze_slurs(events)
            run_plugins(
                compiler.plugins_to_run,
                events,
                compiler,
                plugin_sources,
                plugin_syntaxes,
            )
            result = ("success", len(events))
        except sws_engine.SWSError as error:
            result = ("sws_error", error.args[0])
        except ValueError as error:
            result = ("validation_error", str(error))
        except Exception as error:
            result = ("error", str(error))

        if not self.closing:
            self.compile_results.put(result)

    def _play_worker(
        self,
        source: str,
        muted_tracks: set[TrackKey],
        solo_tracks: set[TrackKey],
        mixed_functions_global: bool,
        plugin_sources: dict[str, str],
        plugin_syntaxes: dict[str, str],
        output_plugin: tuple[str, str] | None,
        output_plugin_syntax: str,
        playback_options: PlaybackOptions,
        voicebank: sws_engine.UTAUVoicebank | None,
        resample_cache: sws_engine.UTAUResampleCacheSession | None = None,
    ) -> None:
        wav_path: str | None = None
        result: tuple[str, object]
        utau_filename_fallbacks = set()
        cache_playback_started = False

        def report_utau_progress(stage, detail, completed, total):
            if not self.closing:
                self.compile_results.put(
                    (
                        "playback_progress",
                        (stage, detail, completed, total),
                    )
                )

        try:
            if resample_cache is not None:
                resample_cache.begin_playback()
                cache_playback_started = True
            if self.playback_stop_event.is_set():
                result = ("playback_stopped", None)
            else:
                compiler = sws_engine.Compiler(
                    extra_instruments=(
                        {voicebank.root.name}
                        if voicebank is not None
                        else None
                    )
                )
                events = compiler.compile_source(source)
                if compiler.plugins_to_run:
                    plugin_events = copy.deepcopy(events)
                    sws_engine.analyze_slurs(plugin_events)
                    run_plugins(
                        compiler.plugins_to_run,
                        plugin_events,
                        compiler,
                        plugin_sources,
                        plugin_syntaxes,
                        cancel_event=self.playback_stop_event,
                    )
                events = filter_events_for_tracks(
                    events,
                    source,
                    muted_tracks,
                    solo_tracks,
                    mixed_functions_global,
                )
                if self.playback_stop_event.is_set():
                    result = ("playback_stopped", None)
                elif not events:
                    result = ("no_sound", None)
                else:
                    sws_engine.analyze_slurs(events)
                    temp_fd, wav_path = tempfile.mkstemp(
                        prefix="sws-preview-",
                        suffix=".wav",
                    )
                    os.close(temp_fd)
                    if playback_options.use_utau_tools and output_plugin is not None:
                        raise ValueError(
                            self._t("utau_output_plugin_conflict")
                        )
                    if playback_options.use_utau_tools and voicebank is None:
                        raise ValueError(
                            self._t("utau_playback_not_ready")
                        )

                    if output_plugin is not None:
                        plugin_name, plugin_source = output_plugin
                        render_output_plugin = (
                            render_python_output_plugin_to_wav
                            if output_plugin_syntax == "PY"
                            else render_output_plugin_to_wav
                        )
                        render_output_plugin(
                            plugin_name,
                            plugin_source,
                            events,
                            compiler,
                            wav_path,
                            sws_engine.SAMPLE_RATE,
                            playback_options.master_volume,
                            cancel_event=self.playback_stop_event,
                        )
                    elif voicebank is None:
                        sws_engine.Renderer(
                            events,
                            compiler.tempo_map,
                            compiler.key,
                            master_volume=playback_options.master_volume,
                            cancel_event=self.playback_stop_event,
                        ).render(wav_path)
                    else:
                        utau_events, builtin_events = (
                            _partition_events_for_voicebank(
                                events,
                                voicebank,
                                force_utau=playback_options.use_utau_tools,
                            )
                        )
                        if not utau_events:
                            sws_engine.Renderer(
                                events,
                                compiler.tempo_map,
                                compiler.key,
                                master_volume=playback_options.master_volume,
                                cancel_event=self.playback_stop_event,
                            ).render(wav_path)
                        elif not builtin_events:
                            utau_filename_fallbacks.update(
                                sws_engine.render_utau_events(
                                    utau_events,
                                    compiler.tempo_map,
                                    voicebank,
                                    playback_options.wavtool_path,
                                    playback_options.resampler_path,
                                    wav_path,
                                    master_volume=playback_options.master_volume,
                                    resampler_flags=playback_options.resampler_flags,
                                    cancel_event=self.playback_stop_event,
                                    progress_callback=report_utau_progress,
                                    resample_cache=resample_cache,
                                )
                                or ()
                            )
                        else:
                            duration_ms = (
                                compiler.tempo_map.beat_to_seconds(
                                    max(event.end for event in events)
                                )
                                * 1000
                            )
                            with tempfile.TemporaryDirectory(
                                prefix="sws-mixed-preview-"
                            ) as render_directory:
                                directory = Path(render_directory)
                                utau_path = directory / "utau.wav"
                                builtin_path = directory / "builtin.wav"
                                utau_filename_fallbacks.update(
                                    sws_engine.render_utau_events(
                                        utau_events,
                                        compiler.tempo_map,
                                        voicebank,
                                        playback_options.wavtool_path,
                                        playback_options.resampler_path,
                                        utau_path,
                                        master_volume=100,
                                        resampler_flags=playback_options.resampler_flags,
                                        cancel_event=self.playback_stop_event,
                                        progress_callback=report_utau_progress,
                                        resample_cache=resample_cache,
                                    )
                                    or ()
                                )
                                sws_engine.Renderer(
                                    builtin_events,
                                    compiler.tempo_map,
                                    compiler.key,
                                    master_volume=100,
                                    cancel_event=self.playback_stop_event,
                                ).render(builtin_path)
                                sws_engine.mix_wav_files(
                                    [utau_path, builtin_path],
                                    wav_path,
                                    minimum_duration_ms=duration_ms,
                                    cancel_event=self.playback_stop_event,
                                    master_volume=playback_options.master_volume,
                                )
                    if self.playback_stop_event.is_set():
                        result = ("playback_stopped", None)
                    else:
                        if not self.closing:
                            for alias, path in sorted(utau_filename_fallbacks):
                                self.compile_results.put(
                                    (
                                        "playback_warning",
                                        self._t(
                                            "utau_filename_fallback",
                                            alias=alias,
                                            path=path,
                                        ),
                                    )
                                )
                            self.compile_results.put(("playback_started", None))
                        completed = sws_engine.play_audio_cancellable(
                            wav_path,
                            self.playback_stop_event,
                        )
                        result = (
                            "playback_complete" if completed else "playback_stopped",
                            None,
                        )
        except sws_engine.SWSError as error:
            result = ("sws_error", error.args[0])
        except InterruptedError:
            result = (
                "playback_stopped"
                if self.playback_stop_event.is_set()
                else "playback_failed",
                "Audio rendering was interrupted.",
            )
        except ValueError as error:
            result = ("playback_failed", str(error))
        except Exception as error:
            result = ("playback_failed", str(error))

        if wav_path is not None:
            try:
                Path(wav_path).unlink(missing_ok=True)
            except OSError as error:
                result = (
                    "playback_failed",
                    f"Could not remove temporary audio file: {error}",
                )
        if cache_playback_started and resample_cache is not None:
            try:
                resample_cache.finish_playback(
                    result[0] == "playback_complete"
                )
            except Exception as error:
                result = (
                    "playback_failed",
                    f"Could not finalize UTAU resample cache: {error}",
                )
        if not self.closing:
            self.compile_results.put(result)

    def _schedule_compile_result_poll(self) -> None:
        if not self.closing:
            self._compile_result_after_id = self.root.after(
                100,
                self._process_compile_results,
            )

    def _cancel_compile_result_poll(self) -> None:
        after_id = self._compile_result_after_id
        self._compile_result_after_id = None
        if after_id is not None:
            self.root.after_cancel(after_id)

    def _handle_root_destroy(self, event: tk.Event) -> None:
        if event.widget is self.root:
            self.closing = True
            self._cancel_compile_result_poll()

    def _process_compile_results(self) -> None:
        self._compile_result_after_id = None
        if self.closing:
            return
        try:
            while True:
                result = self.compile_results.get_nowait()
                if result[0] == "playback_started":
                    self.playback_phase = "playing"
                    self.document_status.set(self._t("playing"))
                    self._write_output(self._t("playback_started"))
                elif result[0] == "playback_warning":
                    self._write_output(str(result[1]))
                elif result[0] == "playback_progress":
                    stage, detail, completed, total = result[1]
                    self._write_output(
                        self._t(
                            f"utau_progress_{stage}",
                            detail=detail,
                            completed=completed,
                            total=total,
                        )
                    )
                else:
                    self._finish_compile(result)
        except Empty:
            pass
        self._schedule_compile_result_poll()

    def _finish_compile(self, result: tuple[str, object]) -> None:
        self.active_task = None
        self.playback_phase = ""
        self.compiling = False
        self._set_task_controls()
        self._update_title()
        if result[0] == "playback_complete":
            self.document_status.set(self._t("playback_complete"))
            self._write_output(self._t("playback_complete"))
        elif result[0] == "playback_stopped":
            self.document_status.set(self._t("playback_stopped"))
            self._write_output(self._t("playback_stopped"))
        elif result[0] == "playback_failed":
            self.document_status.set(self._t("playback_failed_status"))
            self._write_output(
                self._t("playback_failed", message=result[1])
            )
        elif result[0] == "no_sound":
            self.document_status.set(self._t("no_sound"))
            self._write_output(self._t("no_sound"))
        elif result[0] == "success":
            event_count = result[1]
            self._write_output(
                self._t("compile_success", count=event_count)
            )
            self.document_status.set(self._t("compile_success", count=event_count))
        elif result[0] == "format_saved":
            format_name, path = result[1]
            message = self._t(
                "export_success",
                format=format_name,
                path=path,
            )
            self._write_output(message)
            self.document_status.set(message)
        elif result[0] == "format_failed":
            _format_name, error = result[1]
            message = self._t("export_failed", message=error)
            self._write_output(message)
            self.document_status.set(message)
        elif result[0] == "sws_error":
            line, error_type, message = result[1]
            self._write_output(
                self._t(
                    "compile_error",
                    line=line,
                    kind=error_type,
                    message=message,
                )
            )
            self.document_status.set(self._t("compile_failed_status"))
        else:
            self._write_output(self._t("compile_failed", message=result[1]))
            self.document_status.set(self._t("compile_failed_status"))

    def close(self) -> None:
        if self.active_task == "play":
            return
        if self._confirm_discard_changes():
            self.closing = True
            self._cancel_compile_result_poll()
            if self.active_task == "play":
                self.playback_stop_event.set()
            for plugin_name in list(self.input_plugin_views):
                self._close_input_plugin(plugin_name)
            cleanup_errors = []
            for cache in self._utau_resample_caches.values():
                try:
                    cache.cleanup()
                except OSError as error:
                    cleanup_errors.append(str(error))
            self._utau_resample_caches.clear()
            if cleanup_errors:
                message = self._t(
                    "utau_cache_cleanup_failed",
                    errors="\n".join(cleanup_errors),
                )
                self._write_output(message)
                messagebox.showwarning(
                    self._t("utau_cache_cleanup_title"),
                    message,
                    parent=self.root,
                )
            self.root.destroy()


def main() -> None:
    root = tk.Tk()
    SWSEditor(root)
    root.mainloop()


if __name__ == "__main__":
    main()
