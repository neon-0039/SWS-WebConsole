import importlib.util
import tempfile
import unittest
from pathlib import Path

import sws_engine


class TimelineRepeatTests(unittest.TestCase):
    def test_lp_end_repeats_until_the_baseline_song_end(self):
        events = sws_engine.Compiler().compile_source(
            'lp:end(1) {\n'
            '    snd("piano",4,C4);\n'
            '}\n'
            'snd("piano",1,G4,class="guide");'
        )
        repeated_events = [event for event in events if event.class_name is None]
        guide_events = [event for event in events if event.class_name == "guide"]

        self.assertEqual([0, 2], [event.start for event in repeated_events])
        self.assertEqual([(3, 4)], [
            (event.start, event.duration) for event in guide_events
        ])

    def test_lp_end_accepts_tick_intervals_and_exposes_num(self):
        events = sws_engine.Compiler().compile_source(
            'lp:end(#120) {\n'
            '    snd("piano",16,C4);\n'
            '}\n'
            'snd("piano",2,G4,class="guide");'
        )
        repeated_events = [event for event in events if event.class_name is None]
        self.assertEqual([0, 0.5, 1, 1.5], [event.start for event in repeated_events])

    def test_lp_end_requires_advancing_body_and_positive_interval(self):
        for source in (
            'lp:end(1) {\n    dispin(num);\n}\nsnd("piano",1,G4);',
            'lp:end(0) {\n    snd("piano",4,C4);\n}\nsnd("piano",1,G4);',
        ):
            with self.subTest(source=source):
                with self.assertRaises(sws_engine.SWSError):
                    sws_engine.Compiler().compile_source(source)

    def test_js_beat_interval_includes_callback_duration(self):
        events = sws_engine.Compiler().compile_source(
            'syntax="JS";\n'
            'function pulse() {\n'
            '    sws.snd("piano",4,C4);\n'
            '}\n'
            'sws.setInterval(pulse,0.5);\n'
            'sws.snd("piano",1,G4,class="guide");'
        )
        pulse_events = [event for event in events if event.class_name is None]
        self.assertEqual([0, 1.5, 3], [event.start for event in pulse_events])

    def test_js_millisecond_interval_waits_before_first_callback(self):
        events = sws_engine.Compiler().compile_source(
            'syntax="JS";\n'
            'function pulse() {\n'
            '    sws.snd("piano",4,C4);\n'
            '}\n'
            'setInterval(pulse,500);\n'
            'sws.snd("piano",1,G4,class="guide");'
        )
        pulse_events = [event for event in events if event.class_name is None]
        self.assertEqual([1, 2, 3], [event.start for event in pulse_events])

    def test_millisecond_schedule_uses_tempo_map_inverse(self):
        tempo_map = sws_engine.TempoMap(120)
        tempo_map.set_tempo(1, 60)
        self.assertEqual(2.0, tempo_map.seconds_to_beat(1.5))

    def test_standalone_engine_expands_lp_end(self):
        standalone_path = Path(__file__).with_name("SOUND-WAV-SCRIPT.py")
        spec = importlib.util.spec_from_file_location(
            "sws_standalone_repeat_test",
            standalone_path,
        )
        standalone = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(standalone)

        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / "repeat.ss"
            source_path.write_text(
                'lp:end(1) {\n'
                '    snd("piano",4,C4);\n'
                '}\n'
                'snd("piano",1,G4,class="guide");',
                encoding="utf-8",
            )
            events = standalone.Compiler().compile_ss(source_path)

        repeated_events = [event for event in events if event.class_name is None]
        self.assertEqual([0, 2], [event.start for event in repeated_events])

    def test_standalone_engine_expands_js_beat_intervals(self):
        standalone_path = Path(__file__).with_name("SOUND-WAV-SCRIPT.py")
        spec = importlib.util.spec_from_file_location(
            "sws_standalone_interval_test",
            standalone_path,
        )
        standalone = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(standalone)

        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / "interval.ss"
            source_path.write_text(
                'syntax="JS";\n'
                'function pulse() {\n'
                '    sws.snd("piano",4,C4);\n'
                '}\n'
                'sws.setInterval(pulse,0.5);\n'
                'sws.snd("piano",1,G4,class="guide");',
                encoding="utf-8",
            )
            events = standalone.Compiler().compile_ss(source_path)

        repeated_events = [event for event in events if event.class_name is None]
        self.assertEqual([0, 1.5, 3], [event.start for event in repeated_events])


if __name__ == "__main__":
    unittest.main()
