import unittest

import sws_engine
from track_editor import (
    GLOBAL_TRACK,
    compose_source,
    filter_events_for_tracks,
    partition_source,
    remove_track_from_source,
)


class TrackEditorTests(unittest.TestCase):
    def test_partition_and_round_trip_preserve_source(self):
        source = (
            'key("C");\n'
            'snd("piano", 4, C4, class="melody");\n'
            'snd("piano", 4, D4);\n'
            'snd("piano", 4, E4, class="bass");\n'
        )

        segments, buffers = partition_source(source)

        self.assertIn("melody", buffers)
        self.assertIn("bass", buffers)
        self.assertIn("", buffers)
        self.assertEqual(source, compose_source(segments, buffers, buffers.copy()))

    def test_editing_a_track_replaces_its_source_slots(self):
        source = (
            "<before>\n"
            'snd("piano", 4, C4, class="melody");\n'
            "<middle>\n"
            'snd("piano", 4, E4, class="melody");\n'
        )
        segments, buffers = partition_source(source)
        baseline = buffers.copy()
        buffers["melody"] = 'snd("piano", 2, G4, class="melody");\n'

        composed_source = compose_source(segments, buffers, baseline)
        self.assertEqual(
            "<before>\n"
            'snd("piano", 2, G4, class="melody");\n'
            "<middle>\n",
            composed_source,
        )
        events = sws_engine.Compiler().compile_source(composed_source)
        self.assertEqual(["melody"], [event.class_name for event in events])

    def test_nested_and_multiline_calls_remain_shared(self):
        source = (
            'if (true) {\n'
            '  snd("piano", 4, C4, class="nested");\n'
            '}\n'
            'snd(\n'
            '  "piano", 4, D4, class="multiline"\n'
            ');\n'
        )

        segments, buffers = partition_source(source)

        self.assertEqual({None: source}, buffers)
        self.assertTrue(all(segment.track_name is None for segment in segments))

    def test_python_like_source_only_partitions_top_level_calls(self):
        source = (
            'syntax = "py"\n'
            'snd("piano", 4, C4, class="top")\n'
            'if True:\n'
            '    snd("piano", 4, D4, class="nested")\n'
        )

        segments, buffers = partition_source(source)

        self.assertIn("top", buffers)
        self.assertNotIn("nested", buffers)
        self.assertEqual(source, compose_source(segments, buffers, buffers.copy()))

    def test_composed_source_compiles_events_from_all_tracks(self):
        source = (
            'snd("piano", 4, C4, class="melody");\n'
            'snd("piano", 4, D4);\n'
            'snd("piano", 4, E4, class="bass");\n'
        )
        segments, buffers = partition_source(source)
        compiled_source = compose_source(segments, buffers, buffers.copy())

        events = sws_engine.Compiler().compile_source(compiled_source)

        self.assertEqual(
            ["melody", None, "bass"],
            [event.class_name for event in events],
        )

    def test_added_track_is_appended_to_compiled_source(self):
        segments, buffers = partition_source("<shared>\n")
        baseline = buffers.copy()
        buffers["new-track"] = (
            'snd("piano", 4, G4, class="new-track");\n'
        )
        baseline["new-track"] = ""

        compiled_source = compose_source(segments, buffers, baseline)
        events = sws_engine.Compiler().compile_source(compiled_source)

        self.assertEqual(["new-track"], [event.class_name for event in events])

    def test_mixed_track_function_uses_global_or_default_tab_by_setting(self):
        source = (
            "function phrase() {\n"
            '  snd("piano", 4, C4, class="main");\n'
            '  snd("piano", 4, D4, class="sub");\n'
            "}\n"
            "phrase();\n"
        )

        global_segments, global_buffers = partition_source(source, True)
        default_segments, default_buffers = partition_source(source, False)

        function_source = "".join(source.splitlines(keepends=True)[:4])
        self.assertEqual(function_source, global_buffers[GLOBAL_TRACK])
        self.assertNotIn("main", global_buffers)
        self.assertNotIn("sub", global_buffers)
        self.assertEqual(function_source, default_buffers[""])
        self.assertNotIn(GLOBAL_TRACK, default_buffers)
        self.assertEqual(
            source,
            compose_source(
                global_segments,
                global_buffers,
                global_buffers.copy(),
            ),
        )
        events = sws_engine.Compiler().compile_source(
            compose_source(
                default_segments,
                default_buffers,
                default_buffers.copy(),
            )
        )
        self.assertEqual(["main", "sub"], [event.class_name for event in events])

    def test_single_track_function_is_assigned_to_that_track(self):
        source = (
            "func phrase() {\n"
            '  snd("piano", 4, C4, class="main");\n'
            "}\n"
        )

        _segments, buffers = partition_source(source)

        self.assertEqual(source, buffers["main"])
        self.assertNotIn(GLOBAL_TRACK, buffers)

    def test_function_track_detection_includes_nested_multiline_sounds(self):
        source = (
            "function phrase() {\n"
            "  if (true) {\n"
            "    snd(\n"
            '      "piano", 4, C4, class="main"\n'
            "    );\n"
            '    snd("piano", 4, D4, class="sub");\n'
            "  }\n"
            "}\n"
        )

        _segments, buffers = partition_source(source)

        self.assertEqual(source, buffers[GLOBAL_TRACK])

    def test_arrow_function_is_assigned_by_its_sound_tracks(self):
        source = (
            "const phrase = () => {\n"
            '  snd("piano", 4, C4, class="main");\n'
            '  snd("piano", 4, D4, class="sub");\n'
            "};\n"
        )

        _segments, buffers = partition_source(source)

        self.assertEqual(source, buffers[GLOBAL_TRACK])

    def test_solo_and_mute_filter_playback_events_by_tab_owner(self):
        source = (
            'snd("piano", 4, C4, class="main");\n'
            'snd("piano", 4, D4, class="sub");\n'
        )
        events = sws_engine.Compiler().compile_source(source)

        soloed = filter_events_for_tracks(events, source, set(), {"sub"})
        muted = filter_events_for_tracks(events, source, {"main"}, set())
        all_muted = filter_events_for_tracks(
            events,
            source,
            {"main"},
            {"main"},
        )

        self.assertEqual(["sub"], [event.class_name for event in soloed])
        self.assertEqual(["sub"], [event.class_name for event in muted])
        self.assertEqual([], all_muted)

    def test_global_tab_mutes_all_events_from_a_mixed_function(self):
        source = (
            "function phrase() {\n"
            '  snd("piano", 4, C4, class="main");\n'
            '  snd("piano", 4, D4, class="sub");\n'
            "}\n"
            "phrase();\n"
        )
        events = sws_engine.Compiler().compile_source(source)

        filtered = filter_events_for_tracks(
            events,
            source,
            {GLOBAL_TRACK},
            set(),
        )

        self.assertEqual([], filtered)

    def test_removing_a_track_keeps_other_tracks_and_shared_source(self):
        source = (
            "<shared>\n"
            'snd("piano", 4, C4, class="main");\n'
            'snd("piano", 4, D4, class="sub");\n'
        )

        remaining = remove_track_from_source(source, "main")

        self.assertEqual(
            "<shared>\n"
            'snd("piano", 4, D4, class="sub");\n',
            remaining,
        )


if __name__ == "__main__":
    unittest.main()
