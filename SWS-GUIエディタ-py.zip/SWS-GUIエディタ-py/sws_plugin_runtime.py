"""JavaScript data-plugin execution for the native editor."""

from array import array
import json
import math
import os
from pathlib import Path
import queue
import shutil
import subprocess
import struct
import sys
import threading
from typing import Mapping, Sequence
import wave

import sws_engine


PLUGIN_TIMEOUT_SECONDS = 30
NODE_RUNNER = r"""
const fs = require("node:fs");
const request = JSON.parse(fs.readFileSync(0, "utf8"));

try {
  const plugin = new Function("SWS", `"use strict";\n${request.source}`);
  plugin(request.data);
} catch (error) {
  console.error(error && error.stack ? error.stack : String(error));
  process.exitCode = 1;
}
"""
PYTHON_DATA_RUNNER = r"""
import json
import sys
import traceback

request = json.load(sys.stdin)
namespace = {
    "SWS": request["data"],
    "__name__": "sws_data_plugin",
}

try:
    exec(
        compile(request["source"], request["name"], "exec"),
        namespace,
        namespace,
    )
    run = namespace.get("run")
    if callable(run):
        run(namespace["SWS"])
except BaseException:
    traceback.print_exc(file=sys.stderr)
    raise SystemExit(1)
"""
OUTPUT_RUNNER = r"""
const fs = require("node:fs");
const request = JSON.parse(fs.readFileSync(0, "utf8"));
const pluginConsole = Object.freeze({
  log: (...values) => process.stderr.write(values.join(" ") + "\n"),
  warn: (...values) => process.stderr.write(values.join(" ") + "\n"),
  error: (...values) => process.stderr.write(values.join(" ") + "\n")
});

try {
  const createPlugin = new Function(
    "SWS",
    "console",
    `"use strict";\n${request.source}`
  );
  const plugin = createPlugin(
    Object.freeze({ api_version: 1, type: "output" }),
    pluginConsole
  );
  if (!plugin || typeof plugin.render !== "function") {
    throw new TypeError(
      "output plugin must return an object with render(song, sampleRate)"
    );
  }

  const output = plugin.render(request.song, request.sampleRate);
  if (
    !output ||
    !(output.left instanceof Float32Array) ||
    !(output.right instanceof Float32Array) ||
    output.left.length === 0 ||
    output.left.length !== output.right.length
  ) {
    throw new TypeError(
      "render() must return equal-length, non-empty Float32Array left and right channels"
    );
  }
  for (let index = 0; index < output.left.length; index++) {
    if (
      !Number.isFinite(output.left[index]) ||
      !Number.isFinite(output.right[index])
    ) {
      throw new TypeError("render() returned a non-finite audio sample");
    }
  }

  const header = Buffer.alloc(12);
  header.write("SWSO", 0, "ascii");
  header.writeUInt32LE(output.left.length, 4);
  header.writeUInt32LE(output.right.length, 8);
  process.stdout.write(header);
  process.stdout.write(Buffer.from(
    output.left.buffer,
    output.left.byteOffset,
    output.left.byteLength
  ));
  process.stdout.write(Buffer.from(
    output.right.buffer,
    output.right.byteOffset,
    output.right.byteLength
  ));
} catch (error) {
  process.stderr.write(
    error && error.stack ? error.stack : String(error)
  );
  process.exitCode = 1;
}
"""
PYTHON_OUTPUT_RUNNER = r"""
from array import array
import json
import math
import struct
import sys
import traceback

request = json.load(sys.stdin)
namespace = {
    "SWS": {"api_version": 1, "type": "output"},
    "__name__": "sws_output_plugin",
}

try:
    exec(
        compile(request["source"], request["name"], "exec"),
        namespace,
        namespace,
    )
    render = namespace.get("render")
    if not callable(render):
        raise TypeError("output plugin must define render(song, sample_rate)")

    output = render(request["song"], request["sample_rate"])
    if isinstance(output, dict):
        left_values = output.get("left")
        right_values = output.get("right")
    elif isinstance(output, (tuple, list)) and len(output) == 2:
        left_values, right_values = output
    else:
        raise TypeError(
            "render() must return (left_samples, right_samples) or "
            "{'left': left_samples, 'right': right_samples}"
        )

    if isinstance(left_values, (str, bytes)) or isinstance(
        right_values, (str, bytes)
    ):
        raise TypeError("render() channels must be numeric iterables")
    left = array("f", left_values)
    right = array("f", right_values)
    if len(left) == 0 or len(left) != len(right):
        raise ValueError("render() must return equal-length, non-empty channels")
    if not all(math.isfinite(sample) for sample in left):
        raise ValueError("render() returned a non-finite left sample")
    if not all(math.isfinite(sample) for sample in right):
        raise ValueError("render() returned a non-finite right sample")
    if sys.byteorder != "little":
        left.byteswap()
        right.byteswap()

    output_stream = sys.stdout.buffer
    output_stream.write(struct.pack("<4sII", b"SWSO", len(left), len(right)))
    output_stream.write(left.tobytes())
    output_stream.write(right.tobytes())
except BaseException:
    traceback.print_exc(file=sys.stderr)
    raise SystemExit(1)
"""
INPUT_PLUGIN_RUNNER = r"""
const readline = require("node:readline");
let nextNodeId = 1;
let editorState;
let editorOperations;
let editorApi;
let plugin;
let dispose;

const pluginConsole = Object.freeze({
  log: (...values) => process.stderr.write(values.join(" ") + "\n"),
  warn: (...values) => process.stderr.write(values.join(" ") + "\n"),
  error: (...values) => process.stderr.write(values.join(" ") + "\n")
});

function send(value) {
  process.stdout.write(JSON.stringify(value) + "\n");
}

function makeElement(tagName) {
  const element = {
    id: nextNodeId++,
    tagName: String(tagName).toLowerCase(),
    type: "",
    value: "",
    placeholder: "",
    disabled: false,
    checked: false,
    className: "",
    style: {},
    attributes: {},
    children: [],
    listeners: Object.create(null),
    parentNode: null,
    _text: ""
  };
  Object.defineProperty(element, "textContent", {
    get() {
      return this._text + this.children.map(child => child.textContent).join("");
    },
    set(value) {
      this._text = String(value ?? "");
      this.children = [];
    }
  });
  Object.defineProperty(element, "innerText", {
    get() { return this.textContent; },
    set(value) { this.textContent = value; }
  });
  Object.defineProperty(element, "innerHTML", {
    get() { return this.textContent; },
    set(value) { this.textContent = value; }
  });
  element.addEventListener = function(type, listener) {
    if (typeof listener !== "function") return;
    (this.listeners[type] ||= []).push(listener);
  };
  element.removeEventListener = function(type, listener) {
    this.listeners[type] = (this.listeners[type] || []).filter(
      item => item !== listener
    );
  };
  element.appendChild = function(child) {
    if (!child || typeof child !== "object") {
      child = makeElement("#text");
      child.textContent = String(arguments[0]);
    }
    if (child.parentNode) child.parentNode.removeChild(child);
    child.parentNode = this;
    this.children.push(child);
    return child;
  };
  element.append = function(...children) {
    children.forEach(child => this.appendChild(child));
  };
  element.removeChild = function(child) {
    const index = this.children.indexOf(child);
    if (index >= 0) {
      this.children.splice(index, 1);
      child.parentNode = null;
    }
    return child;
  };
  element.setAttribute = function(name, value) {
    this.attributes[String(name)] = String(value);
    if (name in this) this[name] = value;
  };
  element.getAttribute = function(name) {
    return this.attributes[String(name)] ?? null;
  };
  const classNames = new Set();
  element.classList = {
    add: (...names) => names.forEach(name => classNames.add(String(name))),
    remove: (...names) => names.forEach(name => classNames.delete(String(name))),
    contains: name => classNames.has(String(name)),
    toggle: name => {
      name = String(name);
      if (classNames.has(name)) {
        classNames.delete(name);
        return false;
      }
      classNames.add(name);
      return true;
    }
  };
  return element;
}

function serialize(element) {
  return {
    id: element.id,
    tagName: element.tagName,
    type: element.type,
    textContent: element._text,
    value: element.value,
    placeholder: element.placeholder,
    disabled: Boolean(element.disabled),
    checked: Boolean(element.checked),
    className: element.className,
    events: Object.keys(element.listeners),
    children: element.children.map(serialize)
  };
}

function makeEditor(state, operations) {
  const validateRange = (start, end) => {
    if (
      !Number.isSafeInteger(start) ||
      !Number.isSafeInteger(end) ||
      start < 0 ||
      end < start ||
      end > state.text.length
    ) {
      throw new RangeError("editor range is outside the current source");
    }
  };
  const applyRange = (start, end, text) => {
    validateRange(start, end);
    if (typeof text !== "string") {
      throw new TypeError("editor text must be a string");
    }
    state.text = state.text.slice(0, start) + text + state.text.slice(end);
    const caret = start + text.length;
    state.selection = { start: caret, end: caret };
    operations.push({ op: "replaceRange", start, end, text });
    return caret;
  };
  const getSelection = () => ({
    start: state.selection.start,
    end: state.selection.end,
    text: state.text.slice(state.selection.start, state.selection.end)
  });

  return Object.freeze({
    api_version: 1,
    getText: () => state.text,
    getSelection,
    insertText(text) {
      const { start, end } = state.selection;
      return applyRange(start, end, text);
    },
    replaceSelection(text) {
      const { start, end } = state.selection;
      return applyRange(start, end, text);
    },
    replaceRange: applyRange,
    replaceAll(text) {
      return applyRange(0, state.text.length, text);
    },
    setSelection(start, end = start) {
      validateRange(start, end);
      state.selection = { start, end };
      operations.push({ op: "setSelection", start, end });
    }
  });
}

function dispatch(root, request) {
  const elements = new Map();
  const visit = element => {
    elements.set(element.id, element);
    element.children.forEach(visit);
  };
  visit(root);
  const target = elements.get(request.elementId);
  if (!target) throw new Error("input plugin element no longer exists");
  if (request.value !== undefined) target.value = String(request.value);
  if (request.checked !== undefined) target.checked = Boolean(request.checked);

  editorState.text = request.editor.text;
  editorState.selection = request.editor.selection;
  editorOperations.length = 0;
  const event = {
    type: request.eventType,
    target,
    currentTarget: target,
    defaultPrevented: false,
    preventDefault() { this.defaultPrevented = true; },
    stopPropagation() {}
  };
  for (const listener of target.listeners[request.eventType] || []) {
    listener.call(target, event);
  }
  return {
    type: "update",
    tree: serialize(root),
    operations: editorOperations,
    editor: editorState
  };
}

async function main() {
  const reader = readline.createInterface({
    input: process.stdin,
    crlfDelay: Infinity
  });
  const iterator = reader[Symbol.asyncIterator]();
  const first = await iterator.next();
  if (first.done) return;
  const initial = JSON.parse(first.value);
  const document = {
    createElement: name => makeElement(name),
    createTextNode: text => {
      const node = makeElement("#text");
      node.textContent = text;
      return node;
    }
  };
  const root = makeElement("div");
  editorState = initial.editor;
  editorOperations = [];
  try {
    const createPlugin = new Function(
      "SWS",
      "document",
      "console",
      `"use strict";\n${initial.source}`
    );
    plugin = createPlugin(
      Object.freeze({ api_version: 1, type: "input" }),
      document,
      pluginConsole
    );
    if (!plugin || typeof plugin.mount !== "function") {
      throw new TypeError(
        "input plugin must return an object with mount(container, editor)"
      );
    }
    editorApi = makeEditor(editorState, editorOperations);
    dispose = plugin.mount(root, editorApi);
    send({
      type: "ready",
      displayName: typeof plugin.name === "string" && plugin.name.trim()
        ? plugin.name.trim()
        : initial.name,
      tree: serialize(root),
      operations: editorOperations,
      editor: editorState
    });
  } catch (error) {
    send({
      type: "error",
      message: error && error.stack ? error.stack : String(error)
    });
    reader.close();
    return;
  }

  for await (const line of iterator) {
    let request;
    try {
      request = JSON.parse(line);
      if (request.type === "close") {
        if (typeof dispose === "function") dispose();
        break;
      }
      send(dispatch(root, request));
    } catch (error) {
      send({
        type: "error",
        message: error && error.stack ? error.stack : String(error)
      });
    }
  }
  reader.close();
}

main().catch(error => {
  send({
    type: "error",
    message: error && error.stack ? error.stack : String(error)
  });
});
"""


def find_node_runtime() -> str | None:
    executable_name = "node.exe" if os.name == "nt" else "node"
    candidates = []

    bundle_directory = getattr(sys, "_MEIPASS", None)
    if bundle_directory:
        candidates.append(Path(bundle_directory) / "runtime" / executable_name)

    if getattr(sys, "frozen", False):
        executable_directory = Path(sys.executable).resolve().parent
        candidates.append(executable_directory / "runtime" / executable_name)

    candidates.append(Path(__file__).resolve().parent / "runtime" / executable_name)
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)

    return shutil.which("node")


def run_javascript_plugins(
    plugin_requests: Sequence[tuple[str, int]],
    events: list[sws_engine.SoundEvent],
    compiler: sws_engine.Compiler,
    plugin_sources: Mapping[str, str],
) -> None:
    if not plugin_requests:
        return

    node_executable = find_node_runtime()
    if node_executable is None:
        sws_engine.sws_error(
            plugin_requests[0][1],
            "RuntimeError",
            "Node.js runtime not found; include node.exe in runtime or install Node.js.",
        )

    plugin_data = sws_engine.events_to_plugin_data(events, compiler)
    for plugin_name, line_number in plugin_requests:
        if plugin_name not in plugin_sources:
            sws_engine.sws_error(
                line_number,
                "FileNotFoundError",
                f"plugin '{plugin_name}' has not been loaded",
            )

        request = {
            "source": plugin_sources[plugin_name],
            "data": plugin_data,
        }
        try:
            completed = subprocess.run(
                [node_executable, "--eval", NODE_RUNNER],
                input=json.dumps(request, ensure_ascii=False),
                capture_output=True,
                check=False,
                encoding="utf-8",
                errors="replace",
                timeout=PLUGIN_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            sws_engine.sws_error(
                line_number,
                "TimeoutError",
                f"plugin '{plugin_name}' exceeded "
                f"{PLUGIN_TIMEOUT_SECONDS} seconds",
            )
        except OSError as error:
            sws_engine.sws_error(
                line_number,
                "RuntimeError",
                f"could not start Node.js for plugin '{plugin_name}': {error}",
            )

        if completed.returncode != 0:
            message = completed.stderr.strip() or "JavaScript execution failed"
            sws_engine.sws_error(
                line_number,
                "RuntimeError",
                f"plugin '{plugin_name}' failed: {message}",
            )


def run_python_plugins(
    plugin_requests: Sequence[tuple[str, int]],
    events: list[sws_engine.SoundEvent],
    compiler: sws_engine.Compiler,
    plugin_sources: Mapping[str, str],
) -> None:
    if not plugin_requests:
        return

    plugin_data = sws_engine.events_to_plugin_data(events, compiler)
    for plugin_name, line_number in plugin_requests:
        if plugin_name not in plugin_sources:
            sws_engine.sws_error(
                line_number,
                "FileNotFoundError",
                f"plugin '{plugin_name}' has not been loaded",
            )

        request = {
            "name": f"{plugin_name}.py",
            "source": plugin_sources[plugin_name],
            "data": plugin_data,
        }
        try:
            completed = subprocess.run(
                [sys.executable, "-c", PYTHON_DATA_RUNNER],
                input=json.dumps(request, ensure_ascii=False),
                capture_output=True,
                check=False,
                encoding="utf-8",
                errors="replace",
                timeout=PLUGIN_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            sws_engine.sws_error(
                line_number,
                "TimeoutError",
                f"Python plugin '{plugin_name}' exceeded "
                f"{PLUGIN_TIMEOUT_SECONDS} seconds",
            )
        except OSError as error:
            sws_engine.sws_error(
                line_number,
                "RuntimeError",
                f"could not start Python for plugin '{plugin_name}': {error}",
            )

        if completed.returncode != 0:
            message = completed.stderr.strip() or "Python execution failed"
            sws_engine.sws_error(
                line_number,
                "RuntimeError",
                f"plugin '{plugin_name}' failed: {message}",
            )


def run_plugins(
    plugin_requests: Sequence[tuple[str, int]],
    events: list[sws_engine.SoundEvent],
    compiler: sws_engine.Compiler,
    plugin_sources: Mapping[str, str],
    plugin_syntaxes: Mapping[str, str] | None = None,
) -> None:
    syntaxes = plugin_syntaxes or {}
    for plugin_name, line_number in plugin_requests:
        if plugin_name not in plugin_sources:
            sws_engine.sws_error(
                line_number,
                "FileNotFoundError",
                f"plugin '{plugin_name}' has not been loaded",
            )
        syntax = syntaxes.get(plugin_name, "JS").upper()
        if syntax == "JS":
            run_javascript_plugins(
                [(plugin_name, line_number)],
                events,
                compiler,
                {plugin_name: plugin_sources[plugin_name]},
            )
        elif syntax in {"PY", "PYTHON"}:
            run_python_plugins(
                [(plugin_name, line_number)],
                events,
                compiler,
                {plugin_name: plugin_sources[plugin_name]},
            )
        else:
            sws_engine.sws_error(
                line_number,
                "ValueError",
                f"plugin '{plugin_name}' has unsupported syntax '{syntax}'",
            )


class JavaScriptInputSession:
    def __init__(
        self,
        name: str,
        source: str,
        editor_state: dict[str, object],
    ) -> None:
        self.name = name
        self.responses: queue.Queue[dict[str, object]] = queue.Queue()
        self._commands: queue.Queue[dict[str, object]] = queue.Queue()
        self._closed = False
        self._commands.put(
            {
                "type": "init",
                "name": name,
                "source": source,
                "editor": editor_state,
            }
        )
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def dispatch(
        self,
        element_id: int,
        event_type: str,
        editor_state: dict[str, object],
        value: str | None = None,
        checked: bool | None = None,
    ) -> None:
        request: dict[str, object] = {
            "type": "event",
            "elementId": element_id,
            "eventType": event_type,
            "editor": editor_state,
        }
        if value is not None:
            request["value"] = value
        if checked is not None:
            request["checked"] = checked
        self._commands.put(request)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._commands.put({"type": "close"})

    def _read_response(self, process: subprocess.Popen[str]) -> dict[str, object]:
        timer = threading.Timer(
            PLUGIN_TIMEOUT_SECONDS,
            lambda: process.kill() if process.poll() is None else None,
        )
        timer.daemon = True
        timer.start()
        try:
            if process.stdout is None:
                raise RuntimeError("Node.js stdout pipe is unavailable")
            line = process.stdout.readline()
        finally:
            timer.cancel()
        if not line:
            raise RuntimeError("Node.js input plugin stopped without a response")
        response = json.loads(line)
        if not isinstance(response, dict):
            raise RuntimeError("Node.js input plugin returned an invalid response")
        return response

    def _run(self) -> None:
        process: subprocess.Popen[str] | None = None
        try:
            node_executable = find_node_runtime()
            if node_executable is None:
                raise RuntimeError(
                    "Node.js runtime not found; include node.exe in runtime "
                    "or install Node.js."
                )
            process = subprocess.Popen(
                [node_executable, "--eval", INPUT_PLUGIN_RUNNER],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                encoding="utf-8",
                bufsize=1,
            )
            while True:
                request = self._commands.get()
                if process.stdin is None:
                    raise RuntimeError("Node.js stdin pipe is unavailable")
                process.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
                process.stdin.flush()
                if request["type"] == "close":
                    try:
                        process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    break
                self.responses.put(self._read_response(process))
        except (
            OSError,
            RuntimeError,
            json.JSONDecodeError,
            subprocess.TimeoutExpired,
        ) as error:
            self.responses.put({"type": "error", "message": str(error)})
        finally:
            if process is not None:
                if process.poll() is None:
                    process.kill()
                    process.wait()
                if process.stdin is not None:
                    process.stdin.close()
                if process.stdout is not None:
                    process.stdout.close()


def render_output_plugin_to_wav(
    name: str,
    source: str,
    events: list[sws_engine.SoundEvent],
    compiler: sws_engine.Compiler,
    output_path: str | os.PathLike[str],
    sample_rate: int,
    master_volume: int,
) -> None:
    plugin_data = sws_engine.events_to_plugin_data(events, compiler)
    plugin_data["sample_rate"] = sample_rate
    request = {
        "source": source,
        "song": plugin_data,
        "sampleRate": sample_rate,
    }

    node_executable = find_node_runtime()
    if node_executable is None:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            "Node.js runtime not found; include node.exe in runtime or install Node.js.",
        )
    try:
        completed = subprocess.run(
            [node_executable, "--eval", OUTPUT_RUNNER],
            input=json.dumps(request, ensure_ascii=False).encode("utf-8"),
            capture_output=True,
            check=False,
            timeout=PLUGIN_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"output plugin '{name}' exceeded {PLUGIN_TIMEOUT_SECONDS} seconds",
        )
    except OSError as error:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"could not start Node.js for output plugin '{name}': {error}",
        )

    if completed.returncode != 0:
        message = completed.stderr.decode("utf-8", errors="replace").strip()
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"output plugin '{name}' failed: "
            f"{message or 'JavaScript execution failed'}",
        )

    _write_plugin_audio_response(
        name,
        completed.stdout,
        output_path,
        sample_rate,
        master_volume,
    )


def render_python_output_plugin_to_wav(
    name: str,
    source: str,
    events: list[sws_engine.SoundEvent],
    compiler: sws_engine.Compiler,
    output_path: str | os.PathLike[str],
    sample_rate: int,
    master_volume: int,
) -> None:
    plugin_data = sws_engine.events_to_plugin_data(events, compiler)
    plugin_data["sample_rate"] = sample_rate
    request = {
        "name": f"{name}.py",
        "source": source,
        "song": plugin_data,
        "sample_rate": sample_rate,
    }

    try:
        completed = subprocess.run(
            [sys.executable, "-c", PYTHON_OUTPUT_RUNNER],
            input=json.dumps(request, ensure_ascii=False).encode("utf-8"),
            capture_output=True,
            check=False,
            timeout=PLUGIN_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"output plugin '{name}' exceeded {PLUGIN_TIMEOUT_SECONDS} seconds",
        )
    except OSError as error:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"could not start Python for output plugin '{name}': {error}",
        )

    if completed.returncode != 0:
        message = completed.stderr.decode("utf-8", errors="replace").strip()
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"output plugin '{name}' failed: "
            f"{message or 'Python execution failed'}",
        )

    _write_plugin_audio_response(
        name,
        completed.stdout,
        output_path,
        sample_rate,
        master_volume,
    )


def _write_plugin_audio_response(
    name: str,
    raw_output: bytes,
    output_path: str | os.PathLike[str],
    sample_rate: int,
    master_volume: int,
) -> None:
    if len(raw_output) < 12 or raw_output[:4] != b"SWSO":
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"output plugin '{name}' returned an invalid audio response",
        )
    left_count, right_count = struct.unpack_from("<II", raw_output, 4)
    if left_count == 0 or left_count != right_count:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"output plugin '{name}' returned invalid channel lengths",
        )
    channel_bytes = left_count * 4
    if len(raw_output) != 12 + channel_bytes * 2:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            f"output plugin '{name}' returned truncated audio data",
        )
    if array("f").itemsize != 4:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            "the current platform does not support 32-bit float samples",
        )

    left = array("f")
    right = array("f")
    left.frombytes(raw_output[12 : 12 + channel_bytes])
    right.frombytes(raw_output[12 + channel_bytes :])
    if sys.byteorder != "little":
        left.byteswap()
        right.byteswap()

    gain = max(0, min(100, master_volume)) / 100
    pcm = array("h")
    for left_sample, right_sample in zip(left, right):
        if not math.isfinite(left_sample) or not math.isfinite(right_sample):
            sws_engine.sws_error(
                1,
                "OutputPluginError",
                f"output plugin '{name}' returned a non-finite audio sample",
            )
        for sample in (left_sample * gain, right_sample * gain):
            clipped = max(-1.0, min(1.0, sample))
            scale = 32768 if clipped < 0 else 32767
            pcm.append(math.floor(clipped * scale + 0.5))

    if sample_rate <= 0:
        sws_engine.sws_error(
            1,
            "OutputPluginError",
            "sample rate must be greater than zero",
        )
    with wave.open(str(output_path), "wb") as wav_file:
        wav_file.setnchannels(2)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(pcm.tobytes())
