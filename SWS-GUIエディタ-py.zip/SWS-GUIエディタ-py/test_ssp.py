import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from SWS_GUI import SWSEditor
from sws_ssp import parse_ssp_package


class SSPParserTests(unittest.TestCase):
    def test_parses_all_sections_and_ignores_braces_in_js_literals(self):
        package = parse_ssp_package(
            """/* package */
dataplugin: {
  syntax="JS";
  return { text: "}", pattern: /[{}]/ };
},
inputplugin: { return { mount(container, editor) {} }; }
outputplugin: { return { render() { return { left: [], right: [] }; } }; }
"""
        )

        self.assertIn('text: "}"', package.data_source)
        self.assertIn("pattern: /[{}]/", package.data_source)
        self.assertIn("mount(container, editor)", package.input_source)
        self.assertIn("render()", package.output_source)
        self.assertFalse(package.data_is_default)
        self.assertFalse(package.input_is_default)
        self.assertFalse(package.output_is_default)
        self.assertEqual("JS", package.data_syntax)
        self.assertEqual("JS", package.input_syntax)
        self.assertEqual("JS", package.output_syntax)

    def test_parses_python_sections_with_comments_and_triple_quoted_strings(self):
        package = parse_ssp_package(
            '''dataplugin:{
syntax="PY"
# braces in comments do not end a section: }
MESSAGE = """text with { braces } and a quote: " """
def run(SWS):
    SWS["custom"] = {"text": "}"}
}
inputplugin:{
syntax="PYTHON"
default
}
outputplugin:{syntax="JS"; default}
'''
        )

        self.assertEqual("PY", package.data_syntax)
        self.assertIn('SWS["custom"]', package.data_source)
        self.assertEqual("PY", package.input_syntax)
        self.assertTrue(package.input_is_default)
        self.assertEqual("JS", package.output_syntax)
        self.assertTrue(package.output_is_default)

    def test_parses_default_sections(self):
        package = parse_ssp_package(
            "dataplugin:{default} inputplugin:{default} outputplugin:{default}"
        )

        self.assertTrue(package.data_is_default)
        self.assertTrue(package.input_is_default)
        self.assertTrue(package.output_is_default)

    def test_rejects_duplicate_missing_and_unclosed_sections(self):
        invalid_packages = (
            "dataplugin:{} dataplugin:{} inputplugin:{} outputplugin:{}",
            "dataplugin:{} inputplugin:{}",
            "dataplugin:{ return { inputplugin:{} outputplugin:{}",
        )
        for source in invalid_packages:
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    parse_ssp_package(source)

    def test_rejects_unsupported_syntax_declaration(self):
        with self.assertRaisesRegex(ValueError, 'syntax="SWS" is not supported'):
            parse_ssp_package(
                'dataplugin:{syntax="SWS" default} '
                "inputplugin:{default} outputplugin:{default}"
            )


class SSPPluginLoadingTests(unittest.TestCase):
    def _app(self):
        app = SWSEditor.__new__(SWSEditor)
        app.language = "en-US"
        app.root = object()
        app.loaded_js_plugins = {}
        app.loaded_plugin_syntaxes = {}
        app.loaded_input_plugins = {}
        app.loaded_input_plugin_syntaxes = {}
        app.output_plugin = None
        app.output_plugin_syntax = "JS"
        app.input_plugin_views = {}
        app._confirm_plugin_load = Mock(return_value=True)
        app._refresh_plugin_menu = Mock()
        app._write_output = Mock()
        return app

    def _load_file(self, app, source):
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        path = Path(temp_dir.name) / "bundle.ssp"
        path.write_text(source, encoding="utf-8")
        dialog = patch(
            "SWS_GUI.filedialog.askopenfilename",
            return_value=str(path),
        )
        dialog.start()
        self.addCleanup(dialog.stop)
        app.load_ssp_plugin()

    def test_installs_custom_sections_together(self):
        app = self._app()
        self._load_file(
            app,
            """dataplugin:{return {api_version: 1};}
inputplugin:{return {mount(container, editor) {}};}
outputplugin:{return {render() {}};}""",
        )

        self.assertEqual("return {api_version: 1};", app.loaded_js_plugins["bundle"])
        self.assertEqual(
            "return {mount(container, editor) {}};",
            app.loaded_input_plugins["bundle"],
        )
        self.assertEqual(("bundle", "return {render() {}};"), app.output_plugin)
        app._confirm_plugin_load.assert_called_once_with(
            "bundle",
            False,
            package=True,
        )

    def test_defaults_register_no_op_data_and_remove_input_and_output(self):
        app = self._app()
        app.loaded_input_plugins["bundle"] = "old input"
        app.output_plugin = ("old-output", "old output")
        self._load_file(
            app,
            "dataplugin:{default} inputplugin:{default} outputplugin:{default}",
        )

        self.assertEqual("", app.loaded_js_plugins["bundle"])
        self.assertNotIn("bundle", app.loaded_input_plugins)
        self.assertIsNone(app.output_plugin)
        app._confirm_plugin_load.assert_called_once_with(
            "bundle",
            True,
            package=True,
        )

    def test_installs_mixed_python_and_javascript_sections(self):
        app = self._app()
        self._load_file(
            app,
            '''dataplugin:{
syntax="PY"
def run(SWS):
    SWS["custom"] = True
}
inputplugin:{
syntax="JS"
return {mount(container, editor) {}};
}
outputplugin:{
syntax="PY"
def render(song, sample_rate):
    return ([0.0], [0.0])
}''',
        )

        self.assertIn('def run(SWS):', app.loaded_js_plugins["bundle"])
        self.assertEqual("PY", app.loaded_plugin_syntaxes["bundle"])
        self.assertIn(
            "return {mount(container, editor) {}};",
            app.loaded_input_plugins["bundle"],
        )
        self.assertEqual("JS", app.loaded_input_plugin_syntaxes["bundle"])
        self.assertIn("def render(song, sample_rate):", app.output_plugin[1])
        self.assertEqual("PY", app.output_plugin_syntax)

    @patch("SWS_GUI.messagebox.showerror")
    def test_invalid_package_does_not_change_loaded_plugins(self, showerror):
        app = self._app()
        app.loaded_js_plugins["bundle"] = "existing data"
        app.loaded_input_plugins["bundle"] = "existing input"
        app.output_plugin = ("existing output", "existing source")

        self._load_file(app, "dataplugin:{} inputplugin:{}")

        self.assertEqual("existing data", app.loaded_js_plugins["bundle"])
        self.assertEqual("existing input", app.loaded_input_plugins["bundle"])
        self.assertEqual(
            ("existing output", "existing source"),
            app.output_plugin,
        )
        showerror.assert_called_once()


if __name__ == "__main__":
    unittest.main()
