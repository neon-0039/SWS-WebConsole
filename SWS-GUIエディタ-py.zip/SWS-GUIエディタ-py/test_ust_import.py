import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

from SWS_GUI import SWSEditor
import sws_engine


UST_SOURCE = """\
[#VERSION]
UST Version1.2

[#SETTING]
Tempo=120
[#0000]
Length=480
Lyric=a
NoteNum=60
[#TRACKEND]
"""


class USTImportTests(unittest.TestCase):
    def _write_ust(self, directory: str) -> Path:
        path = Path(directory) / "sample.ust"
        path.write_text(UST_SOURCE, encoding="utf-8")
        return path

    def test_selected_instrument_is_written_to_imported_source(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self._write_ust(directory)

            source = sws_engine.USTParser().parse_file(
                str(path),
                instrument="piano",
            )

        self.assertIn('snd("piano",4,C4,Lyric="a");', source)
        self.assertNotIn('snd("synth"', source)

    def test_default_instrument_remains_synth(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self._write_ust(directory)

            source = sws_engine.USTParser().parse_file(str(path))

        self.assertIn('snd("synth",4,C4,Lyric="a");', source)

    def test_unknown_instrument_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self._write_ust(directory)

            with self.assertRaises(sws_engine.SWSError):
                sws_engine.USTParser().parse_file(
                    str(path),
                    instrument="unknown",
                )

    def test_pitch_curve_imports_and_exports_ust_pitch_fields(self):
        source = UST_SOURCE.replace(
            "NoteNum=60\n",
            "NoteNum=60\nPBS=0;0\nPBW=240,240\nPBY=100,0,\n",
        )
        with tempfile.TemporaryDirectory() as directory:
            ust_path = Path(directory) / "pitch.ust"
            ust_path.write_text(source, encoding="utf-8")
            compiler = sws_engine.Compiler()
            events = compiler.compile_ust(str(ust_path))

            self.assertTrue(events[0].pitch_enabled)
            self.assertEqual(
                ((0, 0.0), (240, 10.0), (480, 0.0)),
                events[0].pitch_curve.points,
            )

            exported_path = Path(directory) / "roundtrip.ust"
            sws_engine.USTGenerator(
                events,
                compiler.tempo_map,
                compiler.key,
            ).generate(exported_path)

            exported = exported_path.read_text(encoding="utf-8")
            self.assertIn("PBS=0;0", exported)
            self.assertIn("PBW=240,240", exported)
            self.assertIn("PBY=100,0,", exported)

    def test_gui_opens_ust_using_the_selected_instrument(self):
        try:
            root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root.withdraw()
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = self._write_ust(directory)
                with patch(
                    "SWS_GUI.RECENT_FILES_PATH",
                    Path(directory) / "recent_files.json",
                ):
                    app = SWSEditor(root)
                    app.draft_path = Path(directory) / "draft.json"
                    app._set_source("")
                with (
                    patch(
                        "SWS_GUI.filedialog.askopenfilename",
                        return_value=str(path),
                    ),
                    patch.object(
                        app,
                        "_confirm_discard_changes",
                        return_value=True,
                    ),
                    patch.object(
                        app,
                        "_choose_ust_instrument",
                        return_value="piano",
                    ),
                ):
                    app.open_ust_with_instrument()

                source = app.editor.get("1.0", "end-1c")
                self.assertIn('snd("piano",4,C4,Lyric="a");', source)
                self.assertIsNone(app.current_path)
                self.assertEqual(path.resolve(), app.recent_files[0])
        finally:
            root.destroy()


if __name__ == "__main__":
    unittest.main()
