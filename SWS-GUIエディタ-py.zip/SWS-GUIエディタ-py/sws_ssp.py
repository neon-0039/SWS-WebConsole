"""Parser for integrated SWS JavaScript and Python plugin packages."""

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class SSPPackage:
    data_source: str
    input_source: str
    output_source: str
    data_syntax: str = "JS"
    input_syntax: str = "JS"
    output_syntax: str = "JS"

    @property
    def data_is_default(self) -> bool:
        return self.data_source.strip() == "default"

    @property
    def input_is_default(self) -> bool:
        return self.input_source.strip() == "default"

    @property
    def output_is_default(self) -> bool:
        return self.output_source.strip() == "default"


def _skip_trivia(source: str, start: int) -> int:
    index = start
    while index < len(source):
        if source[index].isspace() or source[index] in ",;":
            index += 1
            continue
        if source[index] == "#":
            newline = source.find("\n", index + 1)
            carriage_return = source.find("\r", index + 1)
            comment_end = min(
                (position for position in (newline, carriage_return) if position >= 0),
                default=len(source),
            )
            index = comment_end
            continue
        if source.startswith("//", index):
            newline = source.find("\n", index + 2)
            carriage_return = source.find("\r", index + 2)
            comment_end = min(
                (position for position in (newline, carriage_return) if position >= 0),
                default=len(source),
            )
            index = comment_end
            continue
        if source.startswith("/*", index):
            comment_end = source.find("*/", index + 2)
            if comment_end < 0:
                raise ValueError("unclosed comment in .ssp package")
            index = comment_end + 2
            continue
        break
    return index


def _find_section_end(
    source: str,
    open_index: int,
    *,
    python_syntax: bool = False,
) -> int:
    depth = 1
    quote = None
    triple_quote = False
    escaped = False
    line_comment = False
    block_comment = False
    in_regex = False
    regex_character_class = False
    can_start_regex = True
    regex_prefix_words = {
        "await", "case", "delete", "do", "else", "in", "instanceof",
        "new", "of", "return", "throw", "typeof", "void", "yield",
    }

    index = open_index + 1
    while index < len(source):
        character = source[index]
        next_character = source[index + 1] if index + 1 < len(source) else ""

        if quote is not None:
            if triple_quote:
                if escaped:
                    escaped = False
                elif character == "\\":
                    escaped = True
                elif source.startswith(quote * 3, index):
                    quote = None
                    triple_quote = False
                    index += 3
                    continue
                index += 1
                continue
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            index += 1
            continue

        if in_regex:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == "[" and not regex_character_class:
                regex_character_class = True
            elif character == "]" and regex_character_class:
                regex_character_class = False
            elif character == "/" and not regex_character_class:
                in_regex = False
                can_start_regex = False
            index += 1
            continue

        if line_comment:
            if character in "\r\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            if character == "*" and next_character == "/":
                block_comment = False
                index += 2
            else:
                index += 1
            continue
        if character == "/" and next_character == "/":
            line_comment = True
            index += 2
            continue
        if character == "/" and next_character == "*":
            block_comment = True
            index += 2
            continue
        if python_syntax and character == "#":
            line_comment = True
            index += 1
            continue
        if character == "/" and can_start_regex:
            in_regex = True
            regex_character_class = False
            index += 1
            continue
        if character in "\"'`":
            quote = character
            if python_syntax and character != "`" and source.startswith(
                character * 3,
                index,
            ):
                triple_quote = True
                index += 3
                can_start_regex = False
                continue
            can_start_regex = False
            index += 1
            continue
        if character.isspace():
            index += 1
            continue
        if re.match(r"[A-Za-z_$]", character):
            word_match = re.match(r"[A-Za-z_$][A-Za-z0-9_$]*", source[index:])
            word = word_match.group(0)
            can_start_regex = word in regex_prefix_words
            index += len(word)
            continue
        if character.isdigit():
            index += 1
            while index < len(source) and re.match(r"[A-Za-z0-9_.]", source[index]):
                index += 1
            can_start_regex = False
            continue
        if character == "{":
            depth += 1
            can_start_regex = True
            index += 1
            continue
        if character == "}":
            depth -= 1
            if depth == 0:
                return index
            can_start_regex = False
            index += 1
            continue
        if character in ").]`":
            can_start_regex = False
            index += 1
            continue
        if character in "+-" and next_character == character:
            can_start_regex = False
            index += 2
            continue
        can_start_regex = True
        index += 1

    return -1


def _section_syntax(source: str, open_index: int) -> str:
    start = _skip_trivia(source, open_index + 1)
    declaration = re.match(
        r'^syntax[ \t]*=[ \t]*"([^"]+)"[ \t]*;?',
        source[start:],
        re.I,
    )
    if declaration is None:
        return "JS"
    language = declaration.group(1).upper()
    return "PY" if language in {"PY", "PYTHON"} else "JS"


def _parse_section(source: str, section_name: str) -> tuple[str, str]:
    start = _skip_trivia(source, 0)
    declaration = re.match(
        r'^syntax[ \t]*=[ \t]*"([^"]+)"[ \t]*;?',
        source[start:],
        re.I,
    )
    if declaration is None:
        if re.match(r"^syntax\b", source[start:], re.I):
            raise ValueError(
                f'{section_name} syntax must be declared as "JS" or "PY"'
            )
        return "JS", source

    language = declaration.group(1).upper()
    if language not in {"JS", "PY", "PYTHON"}:
        raise ValueError(
            f'{section_name} syntax="{language}" is not supported; use "JS" or "PY"'
        )
    syntax = "PY" if language in {"PY", "PYTHON"} else "JS"
    end = start + declaration.end()
    if end < len(source):
        following = source[end]
        if (
            not following.isspace()
            and following not in ",;"
            and not source.startswith("//", end)
            and not source.startswith("/*", end)
            and not (syntax == "PY" and following == "#")
        ):
            raise ValueError(
                f"{section_name} syntax declaration must be followed by whitespace or a separator"
            )
    return syntax, source[:start] + source[end:]


def parse_ssp_package(source: str) -> SSPPackage:
    text = source.removeprefix("\ufeff")
    sections = {}
    index = _skip_trivia(text, 0)
    declaration_pattern = re.compile(
        r"^(dataplugin|inputplugin|outputplugin)\s*:\s*\{"
    )

    while index < len(text):
        declaration = declaration_pattern.match(text[index:])
        if declaration is None:
            raise ValueError(
                "expected dataplugin:{...}, inputplugin:{...}, or outputplugin:{...} in .ssp package"
            )
        section_name = declaration.group(1)
        if section_name in sections:
            raise ValueError(f"duplicate {section_name} section in .ssp package")
        open_index = index + declaration.end() - 1
        python_syntax = _section_syntax(text, open_index) == "PY"
        close_index = _find_section_end(
            text,
            open_index,
            python_syntax=python_syntax,
        )
        if close_index < 0:
            raise ValueError(f"unclosed {section_name} section in .ssp package")
        section_source = text[open_index + 1:close_index]
        if not section_source.strip():
            raise ValueError(f"{section_name} section must not be empty")
        sections[section_name] = _parse_section(section_source, section_name)
        index = _skip_trivia(text, close_index + 1)

    for section_name in ("dataplugin", "inputplugin", "outputplugin"):
        if section_name not in sections:
            raise ValueError(f"missing {section_name} section in .ssp package")

    return SSPPackage(
        data_source=sections["dataplugin"][1],
        input_source=sections["inputplugin"][1],
        output_source=sections["outputplugin"][1],
        data_syntax=sections["dataplugin"][0],
        input_syntax=sections["inputplugin"][0],
        output_syntax=sections["outputplugin"][0],
    )
