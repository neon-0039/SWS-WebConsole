import io
import importlib.util
import tempfile
import tkinter as tk
import unittest
import wave
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from SWS_GUI import SWSEditor
import sws_engine


class UTAUVoicebankTests(unittest.TestCase):
    def test_pitch_curve_syntax_uses_s_curve_cents_points(self):
        for source in (
            'pitchmode="on";\nsnd("synth",1,C4,vol=60,pitch=[0,100,0]);',
            'syntax="py"\npitchmode="on"\nsws.snd("synth",1,C4,vol=60,pitch=[0,100,0])',
            'syntax="js"\npitchmode="on";\nsws.snd("synth",1,C4,vol=60,pitch=[0,100,0]);',
        ):
            with self.subTest(source=source):
                event = sws_engine.Compiler().compile_source(source)[0]
                self.assertEqual((0.0, 100.0, 0.0), event.pitch_curve)
                self.assertAlmostEqual(60 * 100 / 128, event.volume)
                self.assertTrue(event.pitch_enabled)
                self.assertEqual(
                    [0.0, 100.0, 0.0],
                    event.to_dict()["pitch_curve"],
                )

        self.assertAlmostEqual(
            50,
            sws_engine._sample_s_curve((0.0, 100.0, 0.0), 0.25),
        )
        self.assertAlmostEqual(
            15.625,
            sws_engine._sample_s_curve((0.0, 100.0), 0.25),
        )
        self.assertEqual(
            "AAAyBkAyAA",
            sws_engine._encode_utau_pitch([0, 50, 100, 50, 0]),
        )
        self.assertEqual("+c", sws_engine._encode_utau_pitch([-100]))
        self.assertEqual("AA#2#", sws_engine._encode_flat_utau_pitch(3))
        self.assertEqual(
            [0, 50, 100, 50, 0],
            [
                round(value)
                for value in sws_engine._build_utau_pitch_values(
                    (0.0, 100.0, 0.0),
                    5,
                    120,
                    20,
                    0,
                )
            ],
        )

    def test_standalone_engine_accepts_vol_and_pitch_syntax(self):
        script_path = Path(__file__).with_name("SOUND-WAV-SCRIPT.py")
        spec = importlib.util.spec_from_file_location(
            "sws_standalone_engine_test",
            script_path,
        )
        standalone = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(standalone)

        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / "pitch.ss"
            source_path.write_text(
                'pitchmode="on";\nsnd("synth",1,C4,vol=60,pitch=[0,100,0]);',
                encoding="utf-8",
            )
            event = standalone.Compiler().compile_ss(source_path)[0]

        self.assertAlmostEqual(60 * 100 / 128, event.volume)
        self.assertEqual((0.0, 100.0, 0.0), event.pitch_curve)
        self.assertTrue(event.pitch_enabled)

        with tempfile.TemporaryDirectory() as directory:
            compatibility_path = Path(directory) / "compatibility.ss"
            compatibility_path.write_text(
                'pitchmode="on";\n'
                'snd("synth",4,C4,vol=6db,pitch=[Y=0,X=0;Y=5,X=120]);\n'
                'snd("guitar",4,E4)-cnt-snd("open_hihat",8,G4);\n'
                'sleepTicks(120);',
                encoding="utf-8",
            )
            events = standalone.Compiler().compile_ss(compatibility_path)
        self.assertEqual(3, len(events))
        self.assertTrue(events[0].pitch_enabled)
        self.assertIsInstance(events[0].pitch_curve, standalone.PitchCurvePoints)
        self.assertAlmostEqual(100 * 10 ** (-6 / 20), events[0].volume)
        self.assertEqual(events[1].start, events[2].start)

    def test_pitch_curve_rejects_invalid_values(self):
        for attribute in (
            "pitch=[]",
            "pitch=[0,true,100]",
            "pitch=[2048]",
            "pitch=[" + ",".join(["0"] * 257) + "]",
        ):
            with self.subTest(attribute=attribute):
                with self.assertRaises(sws_engine.SWSError):
                    sws_engine.Compiler().compile_source(
                        f'snd("synth",1,C4,{attribute});'
                    )

    def test_volume_attribute_is_rejected_and_vol_is_supported(self):
        for syntax in ("SWS", "JS", "py"):
            with self.subTest(syntax=syntax):
                compiler = sws_engine.Compiler()
                prefix = {
                    "SWS": "",
                    "JS": 'syntax="js"\n',
                    "py": 'syntax="py"\n',
                }[syntax]
                call = (
                    'snd("synth",1,C4,vol=60);'
                    if syntax == "SWS"
                    else 'sws.snd("synth",1,C4,vol=60)'
                )
                event = compiler.compile_source(prefix + call)[0]
                self.assertAlmostEqual(60 * 100 / 128, event.volume)

                invalid_call = call.replace("vol=60", "volume=60")
                with self.assertRaises(sws_engine.SWSError):
                    sws_engine.Compiler().compile_source(
                        prefix + invalid_call
                    )
                for invalid_volume in ("129", "1.5", "-6db", "101db"):
                    with self.subTest(syntax=syntax, volume=invalid_volume):
                        with self.assertRaises(sws_engine.SWSError):
                            sws_engine.Compiler().compile_source(
                                prefix
                                + call.replace("vol=60", f"vol={invalid_volume}")
                            )

        for volume, expected in (
            ("128", 100.0),
            ("0db", 100.0),
            ("6db", 100 * 10 ** (-6 / 20)),
        ):
            event = sws_engine.Compiler().compile_source(
                f'snd("synth",1,C4,vol={volume});'
            )[0]
            self.assertAlmostEqual(expected, event.volume)

        standalone_path = Path(__file__).with_name("SOUND-WAV-SCRIPT.py")
        spec = importlib.util.spec_from_file_location(
            "sws_standalone_volume_test",
            standalone_path,
        )
        standalone = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(standalone)
        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / "volume.ss"
            source_path.write_text(
                'snd("synth",1,C4,volume=60);',
                encoding="utf-8",
            )
            with self.assertRaises(standalone.SWSError):
                standalone.Compiler().compile_ss(source_path)

    def test_builtin_renderer_applies_pitch_curve_to_note_frequency(self):
        events = sws_engine.Compiler().compile_source(
            'pitchmode="on";\nsnd("sine",400,C4,pitch=[0,100]);'
        )
        observed_frequencies = []

        def capture_frequency(instrument, phase, frequency, time):
            observed_frequencies.append(frequency)
            return 0.1

        with tempfile.TemporaryDirectory() as directory:
            output_path = Path(directory) / "pitch.wav"
            with patch(
                "sws_engine.synth_wave_with_phase",
                side_effect=capture_frequency,
            ):
                sws_engine.Renderer(
                    events,
                    sws_engine.TempoMap(120),
                    "C",
                ).render(output_path)

        self.assertGreater(
            max(observed_frequencies),
            min(observed_frequencies),
        )

    def test_pitchmode_points_volume_and_added_sws_commands(self):
        source = (
            'pitchmode="on";'
            'snd("synth",4,C4,vol=6db,pitch=[Y=0,X=0;Y=10,X=240;Y=0,X=480]);'
            'snd("guitar",4,E4)-cnt-snd("open_hihat",8,G4);'
            'sleepTicks(120);'
            'snd("default_voice",4,A4,vol=128);'
        )
        events = sws_engine.Compiler().compile_source(source)
        self.assertEqual(4, len(events))
        self.assertEqual([0, 1, 1, 2.25], [event.start for event in events])
        self.assertAlmostEqual(100 * 10 ** (-6 / 20), events[0].volume)
        self.assertIsInstance(events[0].pitch_curve, sws_engine.PitchCurvePoints)
        self.assertTrue(events[0].pitch_enabled)
        self.assertEqual(events[1].start, events[2].start)
        self.assertAlmostEqual(100, events[3].volume)
        self.assertFalse(events[3].pitch_curve)

        with self.assertRaises(sws_engine.SWSError):
            sws_engine.Compiler().compile_source(
                'snd("synth",4,C4,vol=129);'
            )
        compiler = sws_engine.Compiler()
        compiler.compile_source('tempoconst="999.9";\nsnd("synth",4,C4);')
        self.assertEqual(999.9, compiler.tempo_map.segments[0][1])
        with self.assertRaises(sws_engine.SWSError):
            sws_engine.Compiler().compile_source(
                'tempoconst="1000";\nsnd("synth",4,C4);'
            )

    def test_pitch_points_cnt_and_sleep_ticks_in_js_and_python_syntax(self):
        sources = (
            'syntax="js";\n'
            'pitchmode="on";\n'
            'sws.snd("synth",4,C4,pitch=[Y=0,X=0;Y=5,X=120])-cnt-'
            'sws.snd("piano",8,E4);\n'
            'sws.sleepTicks(120);',
            'syntax="py"\n'
            'pitchmode="on"\n'
            'sws.snd("synth",4,C4,pitch=[Y=0,X=0;Y=5,X=120])-cnt-'
            'sws.snd("piano",8,E4)\n'
            'sws.sleepTicks(120)',
        )
        for source in sources:
            with self.subTest(source=source):
                events = sws_engine.Compiler().compile_source(source)
                self.assertEqual(2, len(events))
                self.assertEqual(events[0].start, events[1].start)
                self.assertTrue(events[0].pitch_enabled)
                self.assertIsInstance(
                    events[0].pitch_curve,
                    sws_engine.PitchCurvePoints,
                )

        compiler = sws_engine.Compiler()
        events = compiler.compile_source(
            'pitchmode="on";'
            'snd("synth",4,C4,pitch=[Y=0,X=0;Y=10,X=240]);'
        )
        plugin_data = sws_engine.events_to_plugin_data(events, compiler)
        self.assertTrue(plugin_data["project"]["pitch_mode"])
        self.assertEqual(
            {"points": [{"x": 0, "y": 0.0}, {"x": 240, "y": 10.0}]},
            plugin_data["events"][0]["pitchData"],
        )

    def test_cnt_uses_the_selected_tracks_existing_cursor(self):
        events = sws_engine.Compiler().compile_source(
            'snd("piano",4,C4,class="melody");'
            'snd("piano",4,D4,class="melody");'
            'snd("piano",4,E4,class="melody")-cnt-'
            'snd("sine",8,G4,class="melody");'
        )
        self.assertEqual([0, 1, 2, 2], [event.start for event in events])

    def test_slurred_notes_render_as_one_utau_segment(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            voicebank_root = root / "voicebank"
            voicebank_root.mkdir()
            sample_path = voicebank_root / "sample.wav"
            self._write_test_wave(sample_path, 2000)
            (voicebank_root / "oto.ini").write_text(
                "sample.wav=a,0,0,0,0,0\n",
                encoding="utf-8",
            )
            voicebank = sws_engine.read_utau_voicebank(voicebank_root)
            wavtool = root / "wavtool.exe"
            resampler = root / "resampler.exe"
            wavtool.touch()
            resampler.touch()
            output_path = root / "render.wav"
            compiler = sws_engine.Compiler()
            events = compiler.compile_source(
                'snd("synth",2,C4~,Lyric="a");\n'
                'snd("synth",2,C4,Lyric="a");'
            )
            sws_engine.analyze_slurs(events)
            calls = []

            def run_tool(executable, arguments, cancel_event=None, tempo=None):
                calls.append((Path(executable), arguments))
                if Path(executable) == resampler:
                    self._write_test_wave(Path(arguments[1]), 1000)

            with (
                patch("sws_engine._run_utau_tool", side_effect=run_tool),
                patch("sws_engine._finalize_wavtool_output"),
                patch("sws_engine._mix_utau_wavs"),
            ):
                sws_engine.render_utau_events(
                    events,
                    compiler.tempo_map,
                    voicebank,
                    wavtool,
                    resampler,
                    output_path,
                )

            self.assertEqual([resampler, wavtool], [call[0] for call in calls])
            self.assertEqual("1920@120.000000+0", calls[1][1][3])

    def test_slur_cannot_continue_on_another_track(self):
        events = sws_engine.Compiler().compile_source(
            'snd("synth",1,C4~,class="lead");\n'
            'snd("synth",1,C4,class="harmony");'
        )

        with self.assertRaisesRegex(ValueError, "slur target not found"):
            sws_engine.analyze_slurs(events)

    def test_running_tool_can_be_cancelled(self):
        class FakeProcess:
            returncode = 0

            def __init__(self):
                self.terminated = False

            def communicate(self, timeout=None):
                if timeout == 0.1:
                    raise sws_engine.subprocess.TimeoutExpired("resampler", timeout)
                return "", ""

            def terminate(self):
                self.terminated = True

            def kill(self):
                raise AssertionError(
                    "cancelled process should be terminated, not killed"
                )

        process = FakeProcess()
        with patch("sws_engine.subprocess.Popen", return_value=process):
            with self.assertRaises(InterruptedError):
                sws_engine._run_utau_tool(
                    Path("resampler.exe"),
                    [],
                    cancel_event=SimpleNamespace(is_set=lambda: True),
                )

        self.assertTrue(process.terminated)

    def test_render_uses_resampler_then_wavtool_and_mixes_output(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            voicebank_root = root / "voicebank"
            voicebank_root.mkdir()
            sample_path = voicebank_root / "sample.wav"
            self._write_test_wave(sample_path, 2000)
            (voicebank_root / "oto.ini").write_text(
                "sample.wav=a,0,0,0,0,0\n",
                encoding="utf-8",
            )
            voicebank = sws_engine.read_utau_voicebank(voicebank_root)
            wavtool = root / "wavtool.exe"
            resampler = root / "resampler.exe"
            wavtool.touch()
            resampler.touch()
            output_path = root / "render.wav"
            compiler = sws_engine.Compiler()
            events = compiler.compile_source(
                'pitchmode="on";\n'
                'snd("synth",1,C4,Lyric="a",vol=60,pitch=[0,100,0]);\n'
                'snd("synth",4,D4,Lyric="a");'
            )
            compiler.tempo_map.set_tempo(2, 90)
            calls = []
            phrase_samples = {}
            launch_options = []

            def start_tool(arguments, **kwargs):
                calls.append(arguments)
                launch_options.append(kwargs)
                executable = Path(arguments[0])
                if executable == resampler:
                    self._write_test_wave(Path(arguments[2]), 1000)
                else:
                    output = Path(arguments[1])
                    phrase_samples.setdefault(output, []).extend([2000] * 441)
                    contents = self._wav_bytes(phrase_samples[output])
                    output.parent.mkdir(parents=True, exist_ok=True)
                    output.write_bytes(contents)
                    Path(str(output) + ".whd").write_bytes(contents[:44])
                    Path(str(output) + ".dat").write_bytes(contents[44:])
                    output.unlink()

                return SimpleNamespace(
                    returncode=0,
                    communicate=lambda timeout=None: ("", ""),
                    terminate=lambda: None,
                    kill=lambda: None,
                )

            with patch("sws_engine.subprocess.Popen", side_effect=start_tool):
                sws_engine.render_utau_events(
                    events,
                    compiler.tempo_map,
                    voicebank,
                    wavtool,
                    resampler,
                    output_path,
                    master_volume=50,
                    resampler_flags="g+12Y0",
                )

            self.assertEqual(
                [resampler, wavtool, resampler, wavtool],
                [Path(call[0]) for call in calls],
            )
            self.assertEqual("C4", calls[0][3])
            self.assertEqual("100", calls[0][4])
            self.assertEqual("g+12Y0", calls[0][5])
            self.assertIn("Bk", calls[0][13])
            self.assertEqual("47", calls[0][10])
            self.assertEqual("!102.857143", calls[0][12])
            self.assertEqual("44100", launch_options[0]["env"]["samples"])
            self.assertEqual(
                "102.857143",
                launch_options[0]["env"]["tempo"],
            )
            self.assertEqual(
                "1920@102.857143+0",
                calls[1][4],
            )
            self.assertEqual(calls[1][1], calls[3][1])
            self.assertEqual("D4", calls[2][3])
            self.assertEqual("!90.000000", calls[2][12])
            self.assertEqual("480@90.000000+0", calls[3][4])
            self.assertEqual(
                [
                    "0",
                    "5",
                    "35",
                    "0",
                    "100",
                    "100",
                    "0",
                    "0.000",
                    "0",
                    "30",
                    "100",
                ],
                calls[1][5:],
            )
            with wave.open(str(output_path), "rb") as rendered:
                self.assertEqual(1, rendered.getnchannels())
                self.assertEqual(44100, rendered.getframerate())
                self.assertEqual(132300, rendered.getnframes())
                self.assertEqual(
                    1000,
                    int.from_bytes(
                        rendered.readframes(1),
                        "little",
                        signed=True,
                    ),
                )

    def test_chord_notes_render_on_separate_wavtool_lanes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            voicebank_root = root / "voicebank"
            voicebank_root.mkdir()
            sample_path = voicebank_root / "sample.wav"
            self._write_test_wave(sample_path, 2000)
            (voicebank_root / "oto.ini").write_text(
                "sample.wav=a,0,0,0,0,0\n",
                encoding="utf-8",
            )
            voicebank = sws_engine.read_utau_voicebank(voicebank_root)
            wavtool = root / "wavtool.exe"
            resampler = root / "resampler.exe"
            wavtool.touch()
            resampler.touch()
            compiler = sws_engine.Compiler()
            events = compiler.compile_source(
                'snd("synth",4,fsn=[C4,E4],Lyric="a");'
            )
            calls = []

            def start_tool(arguments, **_kwargs):
                calls.append(arguments)
                if Path(arguments[0]) == resampler:
                    self._write_test_wave(Path(arguments[2]), 1000)
                else:
                    self._write_test_wave(Path(arguments[1]), 2000)
                return SimpleNamespace(
                    returncode=0,
                    communicate=lambda timeout=None: ("", ""),
                    terminate=lambda: None,
                    kill=lambda: None,
                )

            output_path = root / "chord.wav"
            with patch("sws_engine.subprocess.Popen", side_effect=start_tool):
                sws_engine.render_utau_events(
                    events,
                    compiler.tempo_map,
                    voicebank,
                    wavtool,
                    resampler,
                    output_path,
                )

            self.assertEqual(
                ["C4", "E4"],
                [calls[index][3] for index in (0, 2)],
            )
            self.assertNotEqual(calls[1][1], calls[3][1])
            with wave.open(str(output_path), "rb") as rendered:
                self.assertEqual(
                    4000,
                    int.from_bytes(
                        rendered.readframes(1),
                        "little",
                        signed=True,
                    ),
                )

    def test_rest_splits_phrases_and_preserves_absolute_timing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            voicebank_root = root / "voicebank"
            voicebank_root.mkdir()
            sample_path = voicebank_root / "sample.wav"
            self._write_test_wave(sample_path, 2000)
            (voicebank_root / "oto.ini").write_text(
                "sample.wav=a,0,0,0,0,0\n",
                encoding="utf-8",
            )
            voicebank = sws_engine.read_utau_voicebank(voicebank_root)
            wavtool = root / "wavtool.exe"
            resampler = root / "resampler.exe"
            wavtool.touch()
            resampler.touch()
            compiler = sws_engine.Compiler()
            events = compiler.compile_source(
                'snd("synth",4,C4,Lyric="a");\n'
                'snd("synth",2,null);\n'
                'snd("synth",4,D4,Lyric="a");'
            )
            calls = []

            def start_tool(arguments, **_kwargs):
                calls.append(arguments)
                if Path(arguments[0]) == resampler:
                    self._write_test_wave(Path(arguments[2]), 1000)
                else:
                    self._write_test_wave(Path(arguments[1]), 2000)
                return SimpleNamespace(
                    returncode=0,
                    communicate=lambda timeout=None: ("", ""),
                    terminate=lambda: None,
                    kill=lambda: None,
                )

            output_path = root / "rest.wav"
            with patch("sws_engine.subprocess.Popen", side_effect=start_tool):
                sws_engine.render_utau_events(
                    events,
                    compiler.tempo_map,
                    voicebank,
                    wavtool,
                    resampler,
                    output_path,
                )

            wavtool_calls = [
                call for call in calls if Path(call[0]) == wavtool
            ]
            self.assertEqual(2, len(wavtool_calls))
            self.assertNotEqual(wavtool_calls[0][1], wavtool_calls[1][1])
            with wave.open(str(output_path), "rb") as rendered:
                self.assertEqual(88200, rendered.getnframes())
                samples = rendered.readframes(rendered.getnframes())
            self.assertEqual(
                2000,
                int.from_bytes(samples[:2], "little", signed=True),
            )
            self.assertEqual(
                0,
                int.from_bytes(
                    samples[44100 * 2:44100 * 2 + 2],
                    "little",
                    signed=True,
                ),
            )
            self.assertEqual(
                2000,
                int.from_bytes(
                    samples[66150 * 2:66150 * 2 + 2],
                    "little",
                    signed=True,
                ),
            )

    def test_render_reports_missing_lyric_alias_before_running_tools(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            voicebank_root = root / "voicebank"
            voicebank_root.mkdir()
            sample_path = voicebank_root / "sample.wav"
            self._write_test_wave(sample_path, 1000)
            (voicebank_root / "oto.ini").write_text(
                "sample.wav=other,0,0,0,0,0\n",
                encoding="utf-8",
            )
            voicebank = sws_engine.read_utau_voicebank(voicebank_root)
            wavtool = root / "wavtool.exe"
            resampler = root / "resampler.exe"
            wavtool.touch()
            resampler.touch()
            events = sws_engine.Compiler().compile_source(
                'snd("synth",4,C4,Lyric="missing");'
            )

            with patch("sws_engine.subprocess.Popen") as run_tool:
                with self.assertRaisesRegex(ValueError, 'alias "missing"'):
                    sws_engine.render_utau_events(
                        events,
                        sws_engine.Compiler().tempo_map,
                        voicebank,
                        wavtool,
                        resampler,
                        root / "render.wav",
                    )

            run_tool.assert_not_called()

    @staticmethod
    def _write_test_wave(path, sample):
        with wave.open(str(path), "wb") as target:
            target.setnchannels(1)
            target.setsampwidth(2)
            target.setframerate(44100)
            target.writeframes(sample.to_bytes(2, "little", signed=True) * 441)

    @staticmethod
    def _wav_bytes(samples):
        contents = io.BytesIO()
        with wave.open(contents, "wb") as target:
            target.setnchannels(1)
            target.setsampwidth(2)
            target.setframerate(44100)
            target.writeframes(
                b"".join(
                    sample.to_bytes(2, "little", signed=True)
                    for sample in samples
                )
            )
        return contents.getvalue()

    def test_reads_character_metadata_and_recursive_oto_ini_entries(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "voicebank"
            nested = root / "append"
            nested.mkdir(parents=True)
            (root / "character.txt").write_text(
                "\ufeffname=サンプル音源\nauthor=作成者\nreadme=manual.txt\n",
                encoding="utf-8",
            )
            (root / "manual.txt").write_text(
                "音源の説明\n",
                encoding="utf-8",
            )
            (root / "oto.ini").write_bytes(
                "あ.wav=あ,10.5,20,-30,4,2\n".encode("cp932")
            )
            (nested / "oto.ini").write_text(
                "a.wav=alias,1,2,-3,4,5\n"
                "bad.wav=alias,invalid,2,-3,4,5\n"
                "../../outside.wav=escape,1,2,-3,4,5\n",
                encoding="utf-8",
            )

            voicebank = sws_engine.read_utau_voicebank(root)

        self.assertEqual(voicebank.character["name"], "サンプル音源")
        self.assertEqual(voicebank.character["author"], "作成者")
        self.assertEqual(voicebank.readme_path.name, "manual.txt")
        self.assertEqual(voicebank.readme_text, "音源の説明\n")
        self.assertEqual(len(voicebank.oto_entries), 2)
        entry = next(item for item in voicebank.oto_entries if item.alias == "あ")
        self.assertEqual(entry.offset, 10.5)
        self.assertEqual(entry.consonant, 20)
        self.assertEqual(entry.cutoff, -30)
        self.assertEqual(entry.preutterance, 4)
        self.assertEqual(entry.overlap, 2)
        self.assertEqual(entry.wav_path.name, "あ.wav")
        self.assertEqual(len(voicebank.warnings), 2)
        self.assertTrue(any("numeric" in warning for warning in voicebank.warnings))
        self.assertTrue(any("escapes" in warning for warning in voicebank.warnings))

    def test_requires_an_oto_ini_file(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileNotFoundError):
                sws_engine.read_utau_voicebank(directory)

    def test_gui_loads_selected_voicebank_and_reports_metadata(self):
        try:
            root_window = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root_window.withdraw()
        try:
            with tempfile.TemporaryDirectory() as directory:
                bank_path = Path(directory) / "voicebank"
                bank_path.mkdir()
                (bank_path / "character.txt").write_text(
                    "name=GUI Test\nreadme=readme.txt\n",
                    encoding="utf-8",
                )
                (bank_path / "oto.ini").write_text(
                    "a.wav=a,0,1,-1,0,0\n",
                    encoding="utf-8",
                )
                (bank_path / "readme.txt").write_text(
                    "This is the voicebank readme.",
                    encoding="utf-8",
                )

                with patch(
                    "SWS_GUI.RECENT_FILES_PATH",
                    Path(directory) / "recent_files.json",
                ):
                    app = SWSEditor(root_window)
                    app.draft_path = Path(directory) / "draft.json"

                app.open_settings()
                settings_dialog = app.settings_dialog
                self.assertEqual(
                    str(tk.DISABLED),
                    str(app.utau_voicebank_info_button["state"]),
                )
                app._close_settings(settings_dialog)

                with (
                    patch(
                        "SWS_GUI.filedialog.askdirectory",
                        return_value=str(bank_path),
                    ),
                    patch("SWS_GUI.messagebox.showinfo") as showinfo,
                ):
                    self.assertTrue(app.load_utau_voicebank())

                self.assertEqual(app.utau_voicebank.character["name"], "GUI Test")
                self.assertEqual(len(app.utau_voicebank.oto_entries), 1)
                self.assertIn("GUI Test", app.output.get("1.0", "end"))
                showinfo.assert_called_once()

                app.open_settings()
                self.assertEqual(
                    str(tk.NORMAL),
                    str(app.utau_voicebank_info_button["state"]),
                )
                app.utau_voicebank_info_button.invoke()

                def find_text_widgets(widget):
                    widgets = []
                    for child in widget.winfo_children():
                        if isinstance(child, tk.Text):
                            widgets.append(child)
                        else:
                            widgets.extend(find_text_widgets(child))
                    return widgets

                texts = find_text_widgets(app.voicebank_info_dialog)
                self.assertTrue(
                    any(
                        "This is the voicebank readme."
                        in text.get("1.0", "end")
                        for text in texts
                    )
                )
                app.voicebank_info_dialog.destroy()
                app.voicebank_info_dialog = None
                app._close_settings(app.settings_dialog)
        finally:
            root_window.destroy()


if __name__ == "__main__":
    unittest.main()
