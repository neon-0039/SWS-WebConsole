import json
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch

import sws_engine
from SWS_GUI import LANGUAGE_NAMES, PlaybackOptions, SWSEditor
from track_editor import GLOBAL_TRACK


class EditorFeatureTests(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        self.root.withdraw()
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        with patch(
            "SWS_GUI.RECENT_FILES_PATH",
            Path(self.temp_dir.name) / "recent_files.json",
        ):
            self.app = SWSEditor(self.root)
        self.app.draft_path = Path(self.temp_dir.name) / "draft.json"
        self.addCleanup(self.root.destroy)

    def test_settings_dialog_can_resize_and_scroll(self):
        self.root.deiconify()
        self.root.update()
        self.app.open_settings()
        dialog = self.app.settings_dialog
        self.assertIsNotNone(dialog)
        assert dialog is not None
        dialog.geometry("560x460")
        self.root.update()
        self.assertEqual((1, 1), dialog.resizable())

        def descendants(widget: tk.Misc) -> list[tk.Misc]:
            result = []
            for child in widget.winfo_children():
                result.append(child)
                result.extend(descendants(child))
            return result

        widgets = descendants(dialog)
        canvas = next(widget for widget in widgets if isinstance(widget, tk.Canvas))
        language_box = next(
            widget for widget in widgets if isinstance(widget, ttk.Combobox)
        )
        initial_width = canvas.winfo_width()
        initial_control_width = language_box.winfo_width()
        self.assertLess(canvas.yview()[1], 1)
        initial_scroll = canvas.yview()[0]
        canvas.event_generate("<MouseWheel>", delta=-120)
        self.root.update()
        self.assertGreater(canvas.yview()[0], initial_scroll)

        dialog.geometry("680x600")
        self.root.update()
        self.assertGreater(canvas.winfo_width(), initial_width)
        self.assertGreater(language_box.winfo_width(), initial_control_width)
        canvas_window = canvas.find_all()[0]
        self.assertEqual(
            canvas.winfo_width(),
            int(canvas.itemcget(canvas_window, "width")),
        )
        self.app._close_settings(dialog)

    def test_auto_indent_continues_and_indents_blocks(self):
        self.app.settings["autoIndent"] = True
        self.app._set_source("    if ready:")
        self.app.editor.mark_set(tk.INSERT, "end-1c")
        self.app._handle_return(tk.Event())
        self.assertEqual(
            "    if ready:\n        ",
            self.app.editor.get("1.0", "end-1c"),
        )

        self.app._set_source("    value")
        self.app.editor.mark_set(tk.INSERT, "end-1c")
        self.app._handle_return(tk.Event())
        self.assertEqual(
            "    value\n    ",
            self.app.editor.get("1.0", "end-1c"),
        )

    def test_auto_indent_can_be_disabled(self):
        self.app.settings["autoIndent"] = False
        self.app._set_source("value")
        self.app.editor.mark_set(tk.INSERT, "end-1c")
        self.assertIsNone(self.app._handle_return(tk.Event()))

    def test_destroy_handler_cancels_compile_result_poll(self):
        pending_callback = self.app._compile_result_after_id
        self.assertIsNotNone(pending_callback)
        event = tk.Event()
        event.widget = self.root

        with patch.object(
            self.root,
            "after_cancel",
            wraps=self.root.after_cancel,
        ) as after_cancel:
            self.app._handle_root_destroy(event)

        after_cancel.assert_called_once_with(pending_callback)
        self.assertIsNone(self.app._compile_result_after_id)

    def test_search_moves_forward_and_wraps_in_both_directions(self):
        self.app._set_source("alpha beta alpha")
        self.app.search_query = tk.StringVar(value="alpha")
        self.app.search_status = ttk.Label(self.root)
        self.app.editor.mark_set(tk.INSERT, "end-1c")

        self.app._find_text(backwards=False)
        self.assertEqual("1.0", self.app.editor.index("search_match.first"))
        self.app._find_text(backwards=False)
        self.assertEqual("1.11", self.app.editor.index("search_match.first"))
        self.app._find_text(backwards=True)
        self.assertEqual("1.0", self.app.editor.index("search_match.first"))

    def test_search_dialog_opens_and_closes(self):
        self.app.open_search()
        self.assertIsNotNone(self.app.search_dialog)
        self.assertTrue(self.app.search_dialog.winfo_exists())

        self.app._close_search()
        self.assertIsNone(self.app.search_dialog)

    def test_selected_text_is_replaced_as_one_undoable_edit(self):
        source = "alpha beta"
        self.app._set_source(source)
        self.app.editor.tag_add(tk.SEL, "1.0", "1.5")
        self.app._update_edit_menu_state()
        self.assertEqual(tk.NORMAL, self.app.edit_menu.entrycget(4, "state"))

        self.app.open_selection_replacement()
        self.assertIsNotNone(self.app.replace_target)
        self.app.replace_target.insert("1.0", "omega")
        self.app._apply_selection_replacement()

        self.assertEqual(
            "omega beta",
            self.app.editor.get("1.0", "end-1c"),
        )
        self.app.undo_edit()
        self.assertEqual(source, self.app.editor.get("1.0", "end-1c"))

    def test_open_document_records_it_in_recent_files(self):
        path = Path(self.temp_dir.name) / "opened.ss"
        path.write_text('snd("synth",4,C4);', encoding="utf-8")
        with patch.object(self.app, "_confirm_discard_changes", return_value=True):
            self.app.open_document(str(path))

        self.assertEqual(path.resolve(), self.app.recent_files[0])
        self.assertNotIn(GLOBAL_TRACK, self.app.track_buffers)
        self.assertEqual(
            [str(path.resolve())],
            json.loads(
                (Path(self.temp_dir.name) / "recent_files.json").read_text(
                    encoding="utf-8"
                )
            ),
        )

    def test_global_track_is_created_only_when_needed_and_cannot_be_deleted(self):
        self.assertNotIn(GLOBAL_TRACK, self.app.track_buffers)
        path = Path(self.temp_dir.name) / "global.ss"
        path.write_text(
            "function phrase() {\n"
            '  snd("synth",4,C4,class="lead");\n'
            '  snd("synth",4,E4,class="harmony");\n'
            "}\n"
            "phrase();\n",
            encoding="utf-8",
        )
        with patch.object(self.app, "_confirm_discard_changes", return_value=True):
            self.app.open_document(str(path))

        self.assertIn(GLOBAL_TRACK, self.app.track_buffers)
        self.app.active_track = GLOBAL_TRACK
        with patch("SWS_GUI.messagebox.askyesno") as ask_delete:
            self.app.delete_selected_track()

        ask_delete.assert_not_called()
        self.assertIn(GLOBAL_TRACK, self.app.track_buffers)

    def test_file_export_menu_contains_ust_and_midi(self):
        self.assertEqual(self.app._t("export_as"), self.app.file_menu.entrycget(7, "label"))
        self.assertEqual(
            self.app._t("export_midi"),
            self.app.export_menu.entrycget(0, "label"),
        )
        self.assertEqual(
            self.app._t("export_wav"),
            self.app.export_menu.entrycget(1, "label"),
        )
        self.assertEqual(
            self.app._t("export_ust"),
            self.app.export_menu.entrycget(2, "label"),
        )
        labels = []
        for index in range(self.app.file_menu.index("end") + 1):
            if self.app.file_menu.type(index) != "separator":
                labels.append(self.app.file_menu.entrycget(index, "label"))
        self.assertIn(self.app._t("save_selected_track"), labels)
        self.assertEqual(
            [
                self.app._t("save_track_source"),
                self.app._t("save_track_ust"),
                self.app._t("save_track_mid"),
                self.app._t("save_track_midi"),
                self.app._t("save_track_wav"),
            ],
            [
                self.app.save_track_menu.entrycget(index, "label")
                for index in range(5)
            ],
        )

    def test_saves_only_the_selected_track_source(self):
        source = (
            'snd("piano", 4, C4, class="melody");\n'
            'snd("piano", 4, D4, class="bass");\n'
        )
        self.app._set_source(source)
        self.app._select_track("melody")
        path = Path(self.temp_dir.name) / "melody.ss"

        with patch(
            "SWS_GUI.filedialog.asksaveasfilename",
            return_value=str(path),
        ):
            self.assertTrue(self.app.save_selected_track())

        self.assertEqual(
            'snd("piano", 4, C4, class="melody");\n',
            path.read_text(encoding="utf-8"),
        )

    def test_selected_track_exports_ust_and_both_midi_extensions(self):
        source = (
            'snd("synth", 4, C4, class="melody");\n'
            'snd("synth", 4, D4, class="bass");\n'
        )
        self.app._set_source(source)
        self.app._select_track("melody")

        ust_path = Path(self.temp_dir.name) / "melody.ust"
        with patch(
            "SWS_GUI.filedialog.asksaveasfilename",
            return_value=str(ust_path),
        ):
            self.assertTrue(self.app.save_selected_track("ust"))
        ust_text = ust_path.read_text(encoding="utf-8")
        self.assertIn("NoteNum=60", ust_text)
        self.assertNotIn("NoteNum=62", ust_text)

        for extension, file_format in ((".mid", "mid"), (".midi", "midi")):
            path = Path(self.temp_dir.name) / f"melody{extension}"
            with patch(
                "SWS_GUI.filedialog.asksaveasfilename",
                return_value=str(path),
            ):
                self.assertTrue(self.app.save_selected_track(file_format))

            compiler = sws_engine.Compiler()
            events = compiler.compile_file(str(path))
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].notes[0].pitch, "C4")

    def test_selected_track_wav_export_contains_only_active_track(self):
        source = (
            'snd("synth", 4, C4, class="melody");\n'
            'snd("synth", 4, D4, class="bass");\n'
        )
        self.app._set_source(source)
        self.app._select_track("melody")
        captured_events = []

        class CaptureThread:
            def __init__(self, target, args, daemon):
                captured_events.extend(args[0])

            def start(self):
                pass

        with (
            patch(
                "SWS_GUI.filedialog.asksaveasfilename",
                return_value=str(Path(self.temp_dir.name) / "melody.wav"),
            ),
            patch("SWS_GUI.threading.Thread", CaptureThread),
        ):
            self.assertTrue(self.app.save_selected_track("wav"))

        self.assertEqual(len(captured_events), 1)
        self.assertEqual(captured_events[0].notes[0].pitch, "C4")
        self.app.active_task = None
        self.app.compiling = False

    def test_exports_wav_in_background_and_reports_completion(self):
        path = Path(self.temp_dir.name) / "song.wav"
        self.app._set_source('snd("synth", 0.1, C4);')

        class ImmediateThread:
            def __init__(self, target, args, daemon):
                self.target = target
                self.args = args

            def start(self):
                self.target(*self.args)

        with (
            patch(
                "SWS_GUI.filedialog.asksaveasfilename",
                return_value=str(path),
            ),
            patch("SWS_GUI.threading.Thread", ImmediateThread),
        ):
            self.app.export_wav()

        self.assertTrue(path.is_file())
        self.assertTrue(path.read_bytes().startswith(b"RIFF"))
        self.app._finish_compile(self.app.compile_results.get_nowait())
        self.assertIn(".wav", self.app.document_status.get())

    def test_utau_tool_paths_can_be_selected_in_settings(self):
        self.app.open_settings()
        dialog = self.app.settings_dialog
        assert dialog is not None

        def descendants(widget: tk.Misc) -> list[tk.Misc]:
            result = []
            for child in widget.winfo_children():
                result.append(child)
                result.extend(descendants(child))
            return result

        canvas = next(
            widget
            for widget in descendants(dialog)
            if isinstance(widget, tk.Canvas)
        )
        content = canvas.nametowidget(
            canvas.itemcget(canvas.find_all()[0], "window")
        )
        tool_controls = {
            int(child.grid_info()["row"]): child
            for child in content.winfo_children()
            if isinstance(child, ttk.Frame)
            and str(child.grid_info().get("row")) in ("15", "16")
        }
        flags_entry = next(
            child
            for child in content.winfo_children()
            if isinstance(child, ttk.Entry)
            and child.grid_info().get("row") == 17
        )
        self.assertEqual("", flags_entry.get())
        entries = [
            next(
                child
                for child in tool_controls[row].winfo_children()
                if isinstance(child, ttk.Entry)
            )
            for row in (15, 16)
        ]
        browse_buttons = [
            next(
                child
                for child in tool_controls[row].winfo_children()
                if isinstance(child, ttk.Button)
            )
            for row in (15, 16)
        ]

        with patch(
            "SWS_GUI.filedialog.askopenfilename",
            side_effect=[
                r"C:\UTAU\wavtool.exe",
                r"C:\UTAU\resampler.exe",
            ],
        ):
            for button in browse_buttons:
                button.invoke()

        self.assertEqual(r"C:\UTAU\wavtool.exe", entries[0].get())
        self.assertEqual(r"C:\UTAU\resampler.exe", entries[1].get())

    def test_utau_playback_settings_are_saved_and_loaded(self):
        self.app.settings_path = Path(self.temp_dir.name) / "settings.json"
        variables = {
            "editorFontSize": tk.StringVar(value="14"),
            "masterVolume": tk.DoubleVar(value=100),
            "editorWrap": tk.BooleanVar(value=False),
            "autoIndent": tk.BooleanVar(value=True),
            "showLineNumbers": tk.BooleanVar(value=True),
            "autoSaveDraft": tk.BooleanVar(value=True),
            "warnUnsaved": tk.BooleanVar(value=True),
            "mixedFunctionTracksToGlobal": tk.BooleanVar(value=True),
            "useUtauToolsForPlayback": tk.BooleanVar(value=True),
            "utauWavtoolPath": tk.StringVar(value=r"C:\UTAU\wavtool.exe"),
            "utauResamplerPath": tk.StringVar(value=r"C:\UTAU\resampler.exe"),
            "utauResamplerFlags": tk.StringVar(value="g+12Y0"),
            "language": tk.StringVar(value=LANGUAGE_NAMES["ja"]),
            "theme": tk.StringVar(value=self.app._t("dark")),
            "syntaxPreset": tk.StringVar(
                value=self.app._t(
                    f"preset_{self.app.settings['syntaxPreset']}"
                )
            ),
        }

        self.app.open_settings()
        self.app._apply_settings(self.app.settings_dialog, variables)

        self.assertEqual(
            {
                "useUtauToolsForPlayback": True,
                "utauWavtoolPath": r"C:\UTAU\wavtool.exe",
                "utauResamplerPath": r"C:\UTAU\resampler.exe",
                "utauResamplerFlags": "g+12Y0",
            },
            {
                key: json.loads(
                    self.app.settings_path.read_text(encoding="utf-8")
                )[key]
                for key in (
                    "useUtauToolsForPlayback",
                    "utauWavtoolPath",
                    "utauResamplerPath",
                    "utauResamplerFlags",
                )
            },
        )
        self.assertIsNone(self.app._load_settings())
        self.assertTrue(self.app.settings["useUtauToolsForPlayback"])
        self.assertEqual(r"C:\UTAU\wavtool.exe", self.app.settings["utauWavtoolPath"])
        self.assertEqual(
            r"C:\UTAU\resampler.exe",
            self.app.settings["utauResamplerPath"],
        )
        self.assertEqual("g+12Y0", self.app.settings["utauResamplerFlags"])

    def test_utau_playback_requires_a_loaded_voicebank(self):
        self.app.settings["useUtauToolsForPlayback"] = True

        self.app._play_worker(
            'snd("synth",4,C4);',
            set(),
            set(),
            True,
            {},
            {},
            None,
            "JS",
            PlaybackOptions(True, "", "", 100),
            None,
        )

        status, message = self.app.compile_results.get_nowait()
        self.assertEqual("playback_failed", status)
        self.assertEqual(self.app._t("utau_playback_not_ready"), message)

    def test_exports_ust_with_lyrics(self):
        path = Path(self.temp_dir.name) / "song.ust"
        self.app._set_source('snd("synth", 4, C4, Lyric="ka");')
        with patch("SWS_GUI.filedialog.asksaveasfilename", return_value=str(path)):
            self.app.export_ust()

        ust_text = path.read_text(encoding="utf-8")
        self.assertIn("Lyric=ka", ust_text)
        self.assertIn("NoteNum=60", ust_text)

    def test_ust_export_defaults_missing_lyrics_to_a(self):
        path = Path(self.temp_dir.name) / "song.ust"
        self.app._set_source('snd("synth", 4, C4);')
        with patch("SWS_GUI.filedialog.asksaveasfilename", return_value=str(path)):
            self.app.export_ust()

        ust_text = path.read_text(encoding="utf-8")
        self.assertIn("Lyric=あ", ust_text)

    def test_ust_chord_uses_source_pitch_order_and_first_pitch_as_note_num(self):
        tempo_map = sws_engine.TempoMap()
        event = sws_engine.SoundEvent(
            "synth",
            0,
            4,
            [
                sws_engine.NoteData("G4"),
                sws_engine.NoteData("C4"),
                sws_engine.NoteData("E4"),
            ],
            1,
        )
        path = Path(self.temp_dir.name) / "chord.ust"

        sws_engine.USTGenerator([event], tempo_map, "C").generate(path)

        ust_text = path.read_text(encoding="utf-8")
        self.assertIn("Lyric=G4C4E4", ust_text)
        self.assertIn("NoteNum=67", ust_text)

    def test_ust_records_tempo_changes_on_notes_and_splits_rests(self):
        tempo_map = sws_engine.TempoMap()
        tempo_map.set_tempo(2, 90)
        tempo_map.set_tempo(4, 100)
        events = [
            sws_engine.SoundEvent(
                "synth", 0, 1, [sws_engine.NoteData("C4")], 1
            ),
            sws_engine.SoundEvent(
                "synth", 4, 1, [sws_engine.NoteData("D4")], 2
            ),
        ]
        path = Path(self.temp_dir.name) / "tempo.ust"

        sws_engine.USTGenerator(events, tempo_map, "C").generate(path)

        sections = path.read_text(encoding="utf-8").split("[#")
        self.assertTrue(
            any("Lyric=R\nIntensity=100\nModulation=0" in section
                and "Length=480" in section for section in sections)
        )
        self.assertTrue(
            any("Tempo=90.00" in section and "Lyric=R" in section
                for section in sections)
        )
        self.assertTrue(
            any("Tempo=100.00" in section and "NoteNum=62" in section
                for section in sections)
        )

    def test_ust_export_allows_chords_and_rejects_tempo_inside_note(self):
        chord = sws_engine.SoundEvent(
            "synth",
            0,
            4,
            [sws_engine.NoteData("C4"), sws_engine.NoteData("E4")],
            1,
        )
        tempo_map = sws_engine.TempoMap()
        tempo_map.set_tempo(2, 90)

        self.assertFalse(
            SWSEditor._supports_ust_export([chord], tempo_map)
        )
        self.assertTrue(
            SWSEditor._supports_ust_export(
                [chord],
                sws_engine.TempoMap(),
            )
        )

    def test_exports_midi_note_events(self):
        path = Path(self.temp_dir.name) / "song.midi"
        self.app._set_source('snd("synth", 4, C4);')
        with patch("SWS_GUI.filedialog.asksaveasfilename", return_value=str(path)):
            self.app.export_midi()

        midi_data = path.read_bytes()
        self.assertTrue(midi_data.startswith(b"MThd"))
        self.assertIn(bytes((0x90, 60, 127)), midi_data)
        self.assertIn(bytes((0x80, 60, 0)), midi_data)


if __name__ == "__main__":
    unittest.main()
