"""Source partitioning helpers for the native track-tab editor."""

from dataclasses import dataclass
from enum import Enum
import re

import sws_engine


DEFAULT_TRACK = ""


class SpecialTrack(Enum):
    GLOBAL = "global"


GLOBAL_TRACK = SpecialTrack.GLOBAL
TrackKey = str | None | SpecialTrack


@dataclass(frozen=True)
class SourceSegment:
    track_name: TrackKey
    code: str


def partition_source(
    source: str,
    mixed_functions_global: bool = True,
) -> tuple[list[SourceSegment], dict[TrackKey, str]]:
    syntax_match = re.search(
        r'(?im)^\s*syntax\s*=\s*"([^"]+)"',
        source,
    )
    syntax_name = syntax_match.group(1).lower() if syntax_match else "sws"
    syntax = (
        "py" if syntax_name in ("py", "python")
        else "JS" if syntax_name in ("js", "javascript")
        else "SWS"
    )

    try:
        clean_source = sws_engine._strip_source_comments(source, syntax)
    except sws_engine.SWSError:
        return ([SourceSegment(None, source)] if source else []), {None: source}

    raw_lines = source.splitlines(keepends=True)
    clean_lines = clean_source.splitlines(keepends=True)
    if len(raw_lines) != len(clean_lines):
        return ([SourceSegment(None, source)] if source else []), {None: source}

    function_lines = (
        _function_line_owners(clean_lines, mixed_functions_global)
        if syntax != "py"
        else {}
    )
    segments: list[SourceSegment] = []
    buffers: dict[TrackKey, str] = {None: ""}
    brace_depth = 0
    for line_index, (raw_line, clean_line) in enumerate(
        zip(raw_lines, clean_lines)
    ):
        code = clean_line.rstrip("\r\n")
        is_top_level = (
            not code.strip()
            or not code[0].isspace()
            if syntax == "py"
            else brace_depth == 0
        )
        if line_index in function_lines:
            owner = function_lines[line_index]
        else:
            is_track_statement = False
            track_name = None
            if is_top_level and code.strip():
                is_track_statement, track_name = _standalone_snd_track(code)
            owner = track_name if is_track_statement else None
        segments.append(SourceSegment(owner, raw_line))
        buffers[owner] = buffers.get(owner, "") + raw_line
        if syntax != "py":
            brace_depth = max(0, brace_depth + _brace_delta(code))

    return segments, buffers


def compose_source(
    segments: list[SourceSegment],
    buffers: dict[TrackKey, str],
    baseline: dict[TrackKey, str],
) -> str:
    output: list[str] = []
    segment_tracks = {segment.track_name for segment in segments}
    last_segment: dict[TrackKey, int] = {}
    for index, segment in enumerate(segments):
        last_segment[segment.track_name] = index

    replacement_lines = {
        track_name: current.splitlines(keepends=True)
        for track_name, current in buffers.items()
        if current != baseline.get(track_name, "")
    }
    line_positions = {track_name: 0 for track_name in replacement_lines}

    for index, segment in enumerate(segments):
        track_name = segment.track_name
        current = buffers.get(track_name, "")
        if current == baseline.get(track_name, ""):
            output.append(segment.code)
            continue

        lines = replacement_lines.get(track_name, [])
        position = line_positions.get(track_name, 0)
        if position < len(lines):
            line = lines[position]
            output.append(
                line if line.endswith(("\n", "\r")) else line + "\n"
            )
            position += 1
        line_positions[track_name] = position
        if index == last_segment[track_name]:
            output.extend(
                line if line.endswith(("\n", "\r")) else line + "\n"
                for line in lines[position:]
            )
            line_positions[track_name] = len(lines)

    for track_name, code in buffers.items():
        if track_name not in segment_tracks and code:
            if output and not output[-1].endswith(("\n", "\r")):
                output.append("\n")
            output.append(code if code.endswith(("\n", "\r")) else code + "\n")

    return "".join(output)


def filter_events_for_tracks(
    events: list[sws_engine.SoundEvent],
    source: str,
    muted_tracks: set[TrackKey],
    solo_tracks: set[TrackKey],
    mixed_functions_global: bool = True,
) -> list[sws_engine.SoundEvent]:
    segments = partition_source(source, mixed_functions_global)[0]
    line_owners = [segment.track_name for segment in segments]
    filtered_events = []
    for event in events:
        line_index = event.line - 1
        owner = (
            line_owners[line_index]
            if 0 <= line_index < len(line_owners)
            else None
        )
        if owner in muted_tracks:
            continue
        if solo_tracks and owner not in solo_tracks:
            continue
        filtered_events.append(event)
    return filtered_events


def remove_track_from_source(
    source: str,
    track_name: TrackKey,
    mixed_functions_global: bool = True,
) -> str:
    segments = partition_source(source, mixed_functions_global)[0]
    return "".join(
        segment.code
        for segment in segments
        if segment.track_name != track_name
    )


def _standalone_snd_track(code: str) -> tuple[bool, str | None]:
    match = re.match(r"(?<![\w.])(?:sws\.)?snd\s*\(", code, re.IGNORECASE)
    if not match:
        return False, None

    opening = match.end() - 1
    closing, track_name = _parse_snd_call(code, opening)
    if (
        closing is None
        or track_name is None
        or code[closing + 1:].strip().removesuffix(";").strip()
    ):
        return False, None

    return True, track_name


def _function_line_owners(
    lines: list[str],
    mixed_functions_global: bool,
) -> dict[int, TrackKey]:
    function_header = re.compile(
        r"^(?:"
        r"(?:function|func)\s+[A-Za-z_]\w*\s*\([^)]*\)"
        r"|(?:const|let|var)\s+[A-Za-z_]\w*\s*=\s*\([^)]*\)\s*=>"
        r")\s*\{",
        re.IGNORECASE,
    )
    owners: dict[int, TrackKey] = {}
    block_depth = 0
    line_index = 0

    while line_index < len(lines):
        code = lines[line_index].rstrip("\r\n")
        if block_depth == 0 and function_header.match(code.strip()):
            end_index = line_index
            function_depth = 0
            while end_index < len(lines):
                function_depth += _brace_delta(
                    lines[end_index].rstrip("\r\n")
                )
                if function_depth == 0:
                    break
                end_index += 1

            body = "".join(lines[line_index:end_index + 1])
            tracks = _sound_tracks_in_code(body)
            if len(tracks) == 1:
                owner: TrackKey = next(iter(tracks))
            elif len(tracks) > 1:
                owner = GLOBAL_TRACK if mixed_functions_global else DEFAULT_TRACK
            else:
                owner = None
            owners.update(
                (index, owner)
                for index in range(line_index, min(end_index, len(lines) - 1) + 1)
            )
            line_index = end_index + 1
            continue

        block_depth = max(0, block_depth + _brace_delta(code))
        line_index += 1

    return owners


def _sound_tracks_in_code(code: str) -> set[str]:
    tracks = set()
    call_pattern = re.compile(
        r"(?<![\w.])(?:sws\.)?snd\s*\(",
        re.IGNORECASE,
    )
    index = 0
    quote: str | None = None
    escaped = False
    while index < len(code):
        char = code[index]
        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            index += 1
            continue
        if char in ("'", '"', "`"):
            quote = char
            index += 1
            continue

        match = call_pattern.match(code, index)
        if not match:
            index += 1
            continue
        closing, track_name = _parse_snd_call(code, match.end() - 1)
        if closing is None:
            index = match.end()
            continue
        if track_name is not None:
            tracks.add(track_name)
        index = closing + 1

    return tracks


def _parse_snd_call(code: str, opening: int) -> tuple[int | None, str | None]:
    depth = 0
    quote: str | None = None
    escaped = False
    closing = None
    for index in range(opening, len(code)):
        char = code[index]
        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in ("'", '"', "`"):
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                closing = index
                break

    if closing is None:
        return None, None
    try:
        arguments = sws_engine.split_arguments(code[opening + 1:closing])
    except ValueError:
        return closing, None

    if len(arguments) < 3:
        return closing, None

    track_name = DEFAULT_TRACK
    found_class = False
    for argument in arguments[3:]:
        if "=" not in argument:
            continue
        attribute, value = argument.split("=", 1)
        if attribute.strip() != "class":
            continue
        class_match = re.fullmatch(r'"([^"]+)"', value.strip())
        if found_class or not class_match:
            return closing, None
        track_name = class_match.group(1)
        found_class = True

    return closing, track_name


def _brace_delta(code: str) -> int:
    depth = 0
    quote: str | None = None
    escaped = False
    for char in code:
        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in ("'", '"', "`"):
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
    return depth
