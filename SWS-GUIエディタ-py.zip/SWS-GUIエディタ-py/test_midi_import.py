import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

from SWS_GUI import SWSEditor
import sws_engine


class MIDIImportTests(unittest.TestCase):
    def test_midi_events_convert_to_editable_source_with_timing_and_velocity(self):
        tempo_map = sws_engine.TempoMap(120)
        tempo_map.set_tempo(2, 90)
        events = [
            sws_engine.SoundEvent(
                "synth",
                0,
                2,
                [
                    sws_engine.NoteData("C4", key_bypass=True),
                    sws_engine.NoteData("E4", key_bypass=True),
                ],
                1,
                class_name="midi_track_1",
                volume=80,
            ),
            sws_engine.SoundEvent(
                "synth",
                1,
                1,
                [sws_engine.NoteData("G4", key_bypass=True)],
                2,
                class_name="midi_track_1",
                volume=60,
            ),
            sws_engine.SoundEvent(
                "synth",
                3,
                1,
                [sws_engine.NoteData("A4", key_bypass=True)],
                3,
                class_name="midi_track_1",
                volume=100,
            ),
        ]

        source = sws_engine.midi_events_to_sws_source(events, tempo_map)
        compiler = sws_engine.Compiler()
        compiled_events = compiler.compile_source(source)
        notes = [event for event in compiled_events if event.notes]

        self.assertEqual(
            [(event.start, event.duration) for event in notes],
            [(0, 2), (1, 1), (3, 1)],
        )
        self.assertEqual(
            [event.volume for event in notes],
            [
                round(volume * 128 / 100) * 100 / 128
                for volume in (80, 60, 100)
            ],
        )
        self.assertEqual(compiler.tempo_map.segments, [(0, 120), (2, 90)])
        self.assertEqual(notes[0].class_name, "midi_track_1")
        self.assertEqual(notes[1].class_name, "midi_track_1_voice_2")
        self.assertEqual(len(notes[0].notes), 2)

    def test_fractional_midi_ticks_round_trip_through_sws_timing(self):
        tempo_map = sws_engine.TempoMap(120)
        tempo_map.set_tempo(0.375, 90)
        events = [
            sws_engine.SoundEvent(
                "synth",
                0.125,
                0.125,
                [sws_engine.NoteData("C4", key_bypass=True)],
                1,
                class_name="midi_track_1",
            ),
            sws_engine.SoundEvent(
                "synth",
                0.5,
                0.25,
                [sws_engine.NoteData("D4", key_bypass=True)],
                2,
                class_name="midi_track_1",
            ),
        ]

        source = sws_engine.midi_events_to_sws_source(events, tempo_map)
        compiler = sws_engine.Compiler()
        compiled_events = compiler.compile_source(source)
        notes = [event for event in compiled_events if event.notes]

        self.assertAlmostEqual(notes[0].start, 0.125)
        self.assertAlmostEqual(notes[0].duration, 0.125)
        self.assertAlmostEqual(notes[1].start, 0.5)
        self.assertAlmostEqual(notes[1].duration, 0.25)
        self.assertAlmostEqual(compiler.tempo_map.segments[1][0], 0.375)

    def test_gui_opens_mid_and_midi_as_editable_sws_source(self):
        try:
            root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root.withdraw()
        try:
            tempo_map = sws_engine.TempoMap(120)
            midi_event = sws_engine.SoundEvent(
                "synth",
                0,
                1,
                [sws_engine.NoteData("C4", key_bypass=True)],
                1,
                class_name="track",
            )
            with tempfile.TemporaryDirectory() as directory:
                paths = [Path(directory) / "sample.mid", Path(directory) / "sample.midi"]
                for path in paths:
                    sws_engine.MIDIGenerator(
                        [midi_event],
                        tempo_map,
                        "C",
                    ).generate(str(path))

                with patch(
                    "SWS_GUI.RECENT_FILES_PATH",
                    Path(directory) / "recent_files.json",
                ):
                    app = SWSEditor(root)
                    app.draft_path = Path(directory) / "draft.json"
                    for path in paths:
                        with (
                            patch.object(
                                app,
                                "_confirm_discard_changes",
                                return_value=True,
                            ),
                            patch(
                                "SWS_GUI.filedialog.askopenfilename",
                                return_value=str(path),
                            ),
                        ):
                            app.open_document()

                        source = app.editor.get("1.0", "end-1c")
                        self.assertIn('class="midi_track_1"', source)
                        self.assertIsNone(app.current_path)
                        self.assertEqual(
                            sws_engine.Compiler().compile_source(source)[0].start,
                            0,
                        )
        finally:
            root.destroy()


if __name__ == "__main__":
    unittest.main()
