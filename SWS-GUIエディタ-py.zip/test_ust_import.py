import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from tkinter import ttk
from unittest.mock import patch

from SWS_GUI import SWSEditor
import sws_engine


UST_SOURCE = """\
[#VERSION]
UST Version1.2

[#SETTING]
Tempo=120
[#0000]
Length=480
Lyric=a
NoteNum=60
[#TRACKEND]
"""


class USTImportTests(unittest.TestCase):
    def _write_ust(self, directory: str) -> Path:
        path = Path(directory) / "sample.ust"
        path.write_text(UST_SOURCE, encoding="utf-8")
        return path

    def test_selected_instrument_is_written_to_imported_source(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self._write_ust(directory)

            source = sws_engine.USTParser().parse_file(
                str(path),
                instrument="piano",
            )

        self.assertIn('tempoconst="120.00";', source)
        self.assertIn('key="null";', source)
        self.assertIn('snd("piano",#480,C4,Lyric="a");', source)
        self.assertNotIn('snd("synth"', source)

    def test_default_instrument_remains_synth(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self._write_ust(directory)

            source = sws_engine.USTParser().parse_file(str(path))

        self.assertIn('snd("synth",#480,C4,Lyric="a");', source)

    def test_imported_note_lengths_are_preserved_as_ticks(self):
        source_text = UST_SOURCE.replace("Length=480", "Length=1234")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ticks.ust"
            path.write_text(source_text, encoding="utf-8")
            source = sws_engine.USTParser().parse_file(str(path))
            events = sws_engine.Compiler().compile_source(source)

        self.assertIn('snd("synth",#1234,C4,Lyric="a");', source)
        self.assertEqual(1234 / 480, events[0].duration)

    def test_imported_rest_lengths_are_preserved_as_ticks(self):
        source_text = UST_SOURCE.replace("Lyric=a", "Lyric=R")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rest.ust"
            path.write_text(source_text, encoding="utf-8")
            source = sws_engine.USTParser().parse_file(str(path))

        self.assertIn("sleepTicks(480);", source)

    def test_import_header_matches_browser_ust_expansion(self):
        source_text = UST_SOURCE.replace(
            "Tempo=120",
            "Tempo=999.5",
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "header.ust"
            path.write_text(source_text)
            source = sws_engine.USTParser().parse_file(str(path))

        self.assertTrue(
            source.startswith('tempoconst="999.50";\nkey="null";\n')
        )
        compiler = sws_engine.Compiler()
        compiler.compile_source(source)
        self.assertEqual(999.5, compiler.tempo_map.segments[0][1])

    def test_import_preserves_chromatic_pitch_outside_the_default_key(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self._write_ust(directory)
            path.write_text(
                UST_SOURCE.replace("NoteNum=60", "NoteNum=61"),
                encoding="utf-8",
            )
            source = sws_engine.USTParser().parse_file(str(path))
            events = sws_engine.Compiler().compile_source(source)

        note = events[0].notes[0]
        self.assertIn('C#4', source)
        self.assertFalse(note.key_bypass)
        self.assertEqual("null", note.key)
        self.assertEqual(
            61,
            sws_engine.note_to_midi(
                note.pitch,
                note.key,
                note.key_bypass,
            ),
        )

    def test_unknown_instrument_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self._write_ust(directory)

            with self.assertRaises(sws_engine.SWSError):
                sws_engine.USTParser().parse_file(
                    str(path),
                    instrument="unknown",
                )

    def test_pitch_curve_imports_and_exports_ust_pitch_fields(self):
        source = UST_SOURCE.replace(
            "NoteNum=60\n",
            "NoteNum=60\nPBS=0;0\nPBW=240,240\nPBY=100,0,\n",
        )
        with tempfile.TemporaryDirectory() as directory:
            ust_path = Path(directory) / "pitch.ust"
            ust_path.write_text(source, encoding="utf-8")
            compiler = sws_engine.Compiler()
            events = compiler.compile_ust(str(ust_path))
            self.assertLess(
                compiler.ss_source_code.index('pitchmode="on";'),
                compiler.ss_source_code.index('tempoconst="120.00";'),
            )
            self.assertIn('key="null";', compiler.ss_source_code)

            self.assertTrue(events[0].pitch_enabled)
            self.assertEqual(
                ((0, 0.0), (240, 10.0), (480, 0.0)),
                events[0].pitch_curve.points,
            )

            exported_path = Path(directory) / "roundtrip.ust"
            sws_engine.USTGenerator(
                events,
                compiler.tempo_map,
                compiler.key,
            ).generate(exported_path)

            exported = exported_path.read_text(encoding="utf-8")
            self.assertIn("PBS=0;0", exported)
            self.assertIn("PBW=240,240", exported)
            self.assertIn("PBY=100,0,", exported)

    def test_gui_opens_ust_using_the_selected_instrument(self):
        try:
            root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root.withdraw()
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = self._write_ust(directory)
                path.write_text(
                    UST_SOURCE.replace(
                        "[#0000]\n",
                        "[#0000]\n"
                        "Length=240\n"
                        "Lyric=R\n"
                        "NoteNum=60\n"
                        "\n"
                        "[#0001]\n",
                    ),
                    encoding="utf-8",
                )
                with patch(
                    "SWS_GUI.RECENT_FILES_PATH",
                    Path(directory) / "recent_files.json",
                ):
                    app = SWSEditor(root)
                    app.draft_path = Path(directory) / "draft.json"
                    app._set_source("")
                with (
                    patch(
                        "SWS_GUI.filedialog.askopenfilename",
                        return_value=str(path),
                    ),
                    patch.object(
                        app,
                        "_confirm_discard_changes",
                        return_value=True,
                    ),
                    patch.object(
                        app,
                        "_choose_ust_instrument",
                        return_value="piano",
                    ),
                ):
                    app.open_ust_with_instrument()

                source = app.editor.get("1.0", "end-1c")
                self.assertIn('tempoconst="120.00";', source)
                self.assertIn('key="null";', source)
                self.assertIn("sleepTicks(240);", source)
                self.assertIn('snd("piano",#480,C4,Lyric="a");', source)
                self.assertEqual(source.rstrip(), app._document_source().rstrip())
                self.assertIsNone(app.current_path)
                self.assertEqual(path.resolve(), app.current_ust_path)
                cache = app._current_utau_resample_cache()
                assert cache is not None
                self.assertEqual(path.parent.resolve(), cache.base_directory)
                self.assertEqual(path.resolve(), app.recent_files[0])
        finally:
            root.destroy()

    def test_voicebank_name_is_allowed_for_ust_import(self):
        try:
            root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root.withdraw()
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = self._write_ust(directory)
                voicebank_root = Path(directory) / "My Voicebank"
                voicebank_root.mkdir()
                (voicebank_root / "oto.ini").write_text(
                    "sample.wav=a,0,0,0,0,0\n",
                    encoding="utf-8",
                )
                voicebank = sws_engine.read_utau_voicebank(voicebank_root)
                with patch(
                    "SWS_GUI.RECENT_FILES_PATH",
                    Path(directory) / "recent_files.json",
                ):
                    app = SWSEditor(root)
                    app.draft_path = Path(directory) / "draft.json"
                    app.utau_voicebank = voicebank
                    app._set_source("")

                def accept_voicebank_instrument():
                    dialog = next(
                        widget
                        for widget in root.winfo_children()
                        if isinstance(widget, tk.Toplevel)
                    )

                    def descendants(widget):
                        for child in widget.winfo_children():
                            yield child
                            yield from descendants(child)

                    widgets = list(descendants(dialog))
                    instrument_box = next(
                        widget
                        for widget in widgets
                        if widget.winfo_class() == "TCombobox"
                    )
                    self.assertIn(
                        voicebank_root.name,
                        instrument_box["values"],
                    )
                    self.assertEqual(
                        voicebank_root.name,
                        instrument_box.get(),
                    )
                    apply_button = next(
                        widget
                        for widget in widgets
                        if isinstance(widget, ttk.Button)
                        and widget.cget("text") == app._t("apply")
                    )
                    apply_button.invoke()

                with (
                    patch.object(
                        app,
                        "_confirm_discard_changes",
                        return_value=True,
                    ),
                ):
                    root.after(50, accept_voicebank_instrument)
                    app.open_ust_with_instrument(str(path))

                source = app.editor.get("1.0", "end-1c")
                self.assertIn(
                    'snd("My Voicebank",#480,C4,Lyric="a");',
                    source,
                )
                self.assertEqual(
                    1,
                    len(app._new_compiler().compile_source(source)),
                )
        finally:
            root.destroy()

    def test_open_document_routes_ust_files_to_import_dialog(self):
        try:
            root = tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk is unavailable: {error}")
        root.withdraw()
        try:
            with tempfile.TemporaryDirectory() as directory:
                path = self._write_ust(directory)
                with patch(
                    "SWS_GUI.RECENT_FILES_PATH",
                    Path(directory) / "recent_files.json",
                ):
                    app = SWSEditor(root)
                    app.draft_path = Path(directory) / "draft.json"
                with (
                    patch(
                        "SWS_GUI.filedialog.askopenfilename",
                        return_value=str(path),
                    ) as open_dialog,
                    patch.object(app, "open_ust_with_instrument") as open_ust,
                ):
                    app.open_document()

                open_ust.assert_called_once_with(str(path))
                filetypes = open_dialog.call_args.kwargs["filetypes"]
                default_filter = filetypes[0][1]
                for pattern in ("*.ss", "*.txt", "*.ust", "*.mid", "*.midi"):
                    self.assertIn(pattern, default_filter)
                self.assertTrue(
                    any("*.ust" in pattern for _, pattern in filetypes)
                )
        finally:
            root.destroy()


if __name__ == "__main__":
    unittest.main()
